(() => {
 const id=new URLSearchParams(location.search).get('id'),$=id=>document.getElementById(id);
 $('version').textContent='Passli extension v'+chrome.runtime.getManifest().version;
 const call=async(action,extra={})=>{const result=await chrome.runtime.sendMessage({type:'PASSLI_PASSKEY_UI_V1',id,action,...extra});if(result?.error)throw Error(result.error.message);return result;};
 let busy=false;
 addEventListener('focus',()=>{if(!busy)call('read').then(render).catch(e=>{$('status').textContent=e.message;$('finish').disabled=true;});});
 function render({request:r}){
  $('retry').hidden=!r.unavailable;$('finish').hidden=!!r.unavailable;
  if(r.unavailable){$('title').textContent='Passli is unavailable';$('site').textContent=r.origin;$('status').textContent=r.error+' Open your paired Passli tab and retry, or use another provider.';return;}
  $('title').textContent=r.operation==='create'?'Save passkey in Passli?':'Sign in with Passli';
  $('site').textContent=r.origin+' · RP '+r.rpId;$('account').textContent='Passli account: '+(r.username||'Username unavailable')+(r.account?' · Website account: '+r.account:'');
  $('credential').replaceChildren();for(const c of r.credentials){const o=document.createElement('option');o.value=c.id;o.textContent=c.name===c.userName?c.name:c.name+' ('+c.userName+')';$('credential').append(o);}
  $('choose').hidden=r.operation==='create'||r.credentials.length===0;
  $('finish').textContent=r.operation==='create'?'Save passkey':'Continue';$('finish').disabled=r.operation==='get'&&!r.credentials.length;
  $('status').textContent=r.operation==='get'&&!r.credentials.length?'No matching passkey is saved in this Passli account.':r.verificationRequired?'Complete verification in your signed-in Passli tab after continuing.':'Ready.';
 }
 call('read').then(render).catch(e=>{$('status').textContent=e.message;});
 $('retry').onclick=async()=>{$('retry').disabled=true;try{render(await call('retry'));}catch(e){$('status').textContent=e.message;}finally{$('retry').disabled=false;}};
 $('finish').onclick=async()=>{if(busy)return;busy=true;$('finish').disabled=true;$('fallback').disabled=true;$('status').textContent='Completing request. Check your Passli tab if verification is needed.';try{await call('finish',{credentialId:$('credential').value||undefined});}catch(e){$('status').textContent=e.message;}};
 $('cancel').onclick=()=>call('cancel').catch(e=>{$('status').textContent=e.message;});
 $('fallback').onclick=()=>call('fallback').catch(e=>{$('status').textContent=e.message;});
})();
