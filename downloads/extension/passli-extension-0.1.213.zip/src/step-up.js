// Request-scoped step-up UI. Browser credentials stay in the paired Passli tab;
// only that tab can send authenticated start/status/cancel/sign requests.
globalThis.PassliExtensionStepUp = {
  create({ chrome, now = () => Date.now(), pause = (ms, signal) => new Promise((resolve, reject) => {
    const finish = () => { signal.removeEventListener('abort', abort); resolve(); };
    const timer = setTimeout(finish, ms);
    const abort = () => { clearTimeout(timer); reject(Object.assign(Error('Operation cancelled.'), { code: 4001 })); };
    signal.addEventListener('abort', abort, { once: true });
    if (signal.aborted) abort();
  }) }) {
    const jobs = new Map();
    const cancelled = () => Object.assign(Error('Operation cancelled.'), { code: 4001, noBridgeFallback: true });
    function snapshot(job) { return { id: job.id, origin: job.origin, summary: job.approval.summary, state: job.state, method: job.method, retryable: job.state === 'expired' && now() < job.deadline, error: job.error || '' }; }
    function update(job, state, error) {
      job.state = state; job.error = error || '';
      for (const port of job.ports) { try { port.postMessage(snapshot(job)); } catch {} }
    }
    async function cancel(job) {
      if (job.controller.signal.aborted || ['completing', 'success', 'failed'].includes(job.state)) return;
      job.controller.abort(); job.choosePhone?.reject(cancelled()); job.retry?.reject(cancelled());
      update(job, 'cancelled');
      try { await job.send('cancel', job.approval.id); } catch {}
    }
    chrome.runtime.onConnect.addListener(port => {
      if (port.name !== 'extension-step-up') return;
      let job;
      port.onMessage.addListener(message => {
        if (message?.action === 'open') {
          if (typeof message.id !== 'string' || message.id.length > 128 || port.sender?.url !== chrome.runtime.getURL(`src/step-up.html?id=${encodeURIComponent(message.id)}`)) return;
          const found = jobs.get(message.id);
          if (!found) { port.postMessage({ id: message.id, state: 'failed', error: 'This approval is no longer available. Start a fresh request.' }); return; }
          job = found; job.ports.add(port); port.postMessage(snapshot(job));
        } else if (job && message?.id === job.id && message.action === 'cancel') void cancel(job);
        else if (job && message?.id === job.id && message.action === 'phone') job.choosePhone?.resolve();
        else if (job && message?.id === job.id && message.action === 'retry' && job.state === 'expired' && now() < job.deadline) job.retry?.resolve();
      });
      port.onDisconnect.addListener(() => { job?.ports.delete(port); });
    });
    chrome.windows.onRemoved.addListener(id => {
      for (const job of jobs.values()) if (job.windowId === id) { void cancel(job); jobs.delete(job.id); }
    });
    return {
      async run({ approval, origin, send, complete, refresh, requestDeadline, requestActive }) {
        if (jobs.size >= 3) throw Object.assign(Error('Finish the current extension approvals before starting another request.'), { noBridgeFallback: true });
        if (!approval || typeof approval.id !== 'string' || approval.local) throw Object.assign(Error('This approval requires its originating Passli app.'), { noBridgeFallback: true });
        const id = crypto.randomUUID(), controller = new AbortController();
        // Only a known original provider deadline permits renewal. Reserve time
        // to return the result before the in-page provider stops listening.
        const canRetry = typeof refresh === 'function' && typeof requestActive === 'function' && Number.isFinite(requestDeadline);
        const deadline = Number.isFinite(requestDeadline) ? Math.min(requestDeadline - 5000, now() + 295000) : now() + 120000;
        const job = { id, approval, origin, send, controller, deadline, ports: new Set(), method: approval.method, state: 'starting', windowId: null };
        jobs.set(id, job);
        let expiry;
        const assertActive = () => {
          if (controller.signal.aborted) throw cancelled();
          if (now() >= deadline) throw Error('The signing request expired. Close this window and try again in the requesting site.');
        };
        const assertRequestActive = async () => {
          assertActive();
          if (requestActive && !await requestActive()) throw Error('The requesting page is no longer waiting. Close this window and start again in the requesting site.');
          assertActive();
        };
        try {
          // A separate window avoids racing the initial review popup's close timer.
          const window = await chrome.windows.create({ url: chrome.runtime.getURL(`src/step-up.html?id=${encodeURIComponent(id)}`), type: 'popup', width: 430, height: 480, focused: true });
          job.windowId = window.id;
          await assertRequestActive();
          expiry = setTimeout(() => { job.timedOut = true; void cancel(job); }, Math.max(0, deadline - now()));
          while (true) {
            await assertRequestActive();
            const attemptDeadline = Math.min(now() + 120000, deadline);
            try {
              let state = await send('start', job.approval.id); assertActive();
              job.method = state.method || job.approval.method;
              if (job.method === 'security-key' || state.localKeyStep) {
                const choice = new Promise((resolve, reject) => { job.choosePhone = { resolve, reject }; });
                update(job, 'choose-phone'); await choice; assertActive(); job.choosePhone = null;
                state = await send('mobile-fallback', job.approval.id); assertActive(); job.method = state.method || 'mobile';
              }
              update(job, 'waiting');
              while (state.approved !== true) {
                if (now() >= attemptDeadline) throw Object.assign(Error('Phone approval expired.'), { approvalExpired: true });
                await pause(2000, controller.signal); assertActive();
                await assertRequestActive();
                state = await send('status', job.approval.id); assertActive();
              }
            } catch (error) {
              assertActive();
              // The server uses this exact error for swept approvals. Never retry
              // user rejection, changed-policy errors, or uncertain signing results.
              const expired = error.approvalExpired || (error.status === 403 && error.message === 'Operation approval expired or does not match this device.');
              if (!expired || !canRetry) throw error;
              try { await send('cancel', job.approval.id); } catch {}
              assertActive();
              const choice = new Promise((resolve, reject) => { job.retry = { resolve, reject }; });
              update(job, 'expired', 'Phone approval expired. Retry approval to send a fresh request to your phone.');
              await choice; job.retry = null; await assertRequestActive();
              update(job, 'starting');
              const renewed = await refresh(); assertActive();
              if (renewed.status !== 403 || renewed.body?.code !== 'OPERATION_APPROVAL_REQUIRED' || !renewed.body.approval) {
                // A policy recheck can finish the original operation directly.
                update(job, renewed.status >= 200 && renewed.status < 300 ? 'success' : 'failed', renewed.body?.error);
                if (job.state === 'success') setTimeout(() => { chrome.windows.remove(job.windowId).catch(() => {}); jobs.delete(id); }, 600);
                return renewed;
              }
              const fresh = renewed.body.approval;
              if (typeof fresh.id !== 'string' || fresh.id === job.approval.id || fresh.local) throw Error('Could not renew approval. Start a fresh request in the requesting site.');
              job.approval = fresh; job.method = fresh.method;
              continue;
            }
            await assertRequestActive();
            update(job, 'completing');
            const result = await complete(job.approval.id);
            if (result.status < 200 || result.status >= 300) {
              update(job, 'failed', result.body?.error || 'Signing failed. Start a fresh request.');
              return result;
            }
            update(job, 'success');
            // Close only our popup. The dApp tab was never changed or navigated.
            setTimeout(() => { chrome.windows.remove(job.windowId).catch(() => {}); jobs.delete(id); }, 600);
            return result;
          }
        } catch (error) {
          if (!controller.signal.aborted) { try { await send('cancel', job.approval.id); } catch {} }
          const failure = job.timedOut ? Object.assign(Error('The signing request timed out. Close this window and try again in the requesting site.'), { code: 4001 }) : error;
          update(job, 'failed', failure?.message || 'Step-up approval failed.');
          throw Object.assign(failure, { noBridgeFallback: true });
        } finally { clearTimeout(expiry); }
      }
    };
  }
};
