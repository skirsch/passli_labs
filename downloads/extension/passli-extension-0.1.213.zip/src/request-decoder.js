(function attachRequestDecoder(globalScope) {
  function parseTypedData(value) {
    if (typeof value === "string") {
      return JSON.parse(value);
    }
    return value;
  }

  function chainName(chainId) {
    const value = typeof chainId === "number" ? `0x${chainId.toString(16)}` : String(chainId || "");
    const normalized = value.toLowerCase();
    const names = {
      "0x1": "Ethereum Mainnet",
      "0xa4b1": "Arbitrum One",
      "0x2105": "Base Mainnet",
      "0x3e7": "HyperEVM Mainnet",
      "0x3e6": "HyperEVM Testnet"
    };
    return names[normalized] ? `${names[normalized]} (${value})` : value || "Not chain-specific";
  }

  function requestedChainId(method, params, fallbackChainId = "") {
    if (method === "wallet_switchEthereumChain" && params[0] && params[0].chainId) {
      return params[0].chainId;
    }
    if (method === "wallet_addEthereumChain" && params[0] && params[0].chainId) {
      return params[0].chainId;
    }
    if (method === "eth_sendTransaction" && params[0] && params[0].chainId) {
      return params[0].chainId;
    }
    if (method === "eth_signTypedData" || method === "eth_signTypedData_v3" || method === "eth_signTypedData_v4") {
      try {
        const typedData = parseTypedData(params[1]);
        return typedData && typedData.domain ? typedData.domain.chainId || fallbackChainId : fallbackChainId;
      } catch {
        return fallbackChainId;
      }
    }
    return fallbackChainId;
  }

  function formatTokenAmount(value) {
    if (value === undefined || value === null || value === "") return "";
    if (typeof value === "bigint") return value.toString();
    if (typeof value === "number") return Number.isFinite(value) ? String(value) : "";
    return String(value);
  }

  function risk(level, label, tone, summary) {
    return { level, label, tone, summary };
  }

  function defaultRisk() {
    return risk(40, "Review", "medium", "Review the request details before approving.");
  }

  function hexToText(value) {
    const text = String(value || "");
    if (!/^0x(?:[0-9a-fA-F]{2})+$/.test(text)) return text;
    const bytes = [];
    for (let index = 2; index < text.length; index += 2) {
      bytes.push(Number.parseInt(text.slice(index, index + 2), 16));
    }
    try {
      return new TextDecoder("utf-8", { fatal: true }).decode(new Uint8Array(bytes));
    } catch {
      return text;
    }
  }

  function personalSignMessage(params) {
    if (!Array.isArray(params)) return "";
    const first = String(params[0] || "");
    const second = String(params[1] || "");
    if (/^0x[0-9a-fA-F]{40}$/.test(first) && second) return hexToText(second);
    return hexToText(first);
  }

  function personalSignSigner(params, fallbackAddress) {
    if (!Array.isArray(params)) return fallbackAddress || "n/a";
    const first = String(params[0] || "");
    const second = String(params[1] || "");
    if (/^0x[0-9a-fA-F]{40}$/.test(first)) return first;
    return second || fallbackAddress || "n/a";
  }

  function parseSiweMessage(message) {
    const text = String(message || "");
    const lines = text.split(/\r?\n/);
    const domainLine = lines[0] || "";
    const domainMatch = domainLine.match(/^(.+?) wants you to sign in with your Ethereum account:/i);
    if (!domainMatch) return null;
    const fieldValue = (label) => {
      const prefix = `${label}:`;
      const found = lines.find((line) => line.toLowerCase().startsWith(prefix.toLowerCase()));
      return found ? found.slice(prefix.length).trim() : "";
    };
    const resourcesIndex = lines.findIndex((line) => line.toLowerCase() === "resources:");
    const resources = resourcesIndex >= 0
      ? lines.slice(resourcesIndex + 1).filter((line) => line.trim().startsWith("- ")).map((line) => line.trim().slice(2))
      : [];
    return {
      domain: domainMatch[1],
      address: lines[1] || "",
      statement: lines.slice(3).find((line) => line.trim()) || "",
      uri: fieldValue("URI"),
      version: fieldValue("Version"),
      chainId: fieldValue("Chain ID"),
      nonce: fieldValue("Nonce"),
      issuedAt: fieldValue("Issued At"),
      resources
    };
  }

  function formatRiskValue(value) {
    if (value === undefined || value === null || value === "") return "";
    const numeric = Number(value);
    if (!Number.isFinite(numeric)) return String(value);
    return numeric.toLocaleString(undefined, { maximumFractionDigits: 6 });
  }

  function hyperliquidOrderNotional(action) {
    if (!action || action.type !== "order" || !Array.isArray(action.orders)) return null;
    let total = 0;
    for (const order of action.orders) {
      const price = Number(order && order.p);
      const size = Number(order && order.s);
      if (!Number.isFinite(price) || !Number.isFinite(size)) return null;
      total += Math.abs(price * size);
    }
    return total;
  }

  function findField(object, names) {
    if (!object || typeof object !== "object") return "";
    const entries = Object.entries(object);
    for (const name of names) {
      const found = entries.find(([key]) => key.toLowerCase() === name.toLowerCase());
      if (found) return found[1];
    }
    for (const name of names) {
      const found = entries.find(([key]) => key.toLowerCase().includes(name.toLowerCase()));
      if (found) return found[1];
    }
    return "";
  }

  function blindRisk(reason) {
    return risk(95, "Blind sign: CAUTION", "high", `Blind sign: CAUTION. ${reason} A signature may authorize trading, permissions, or loss of funds. Reject unless you can independently verify the request.`);
  }

  // Exact signed schemas, not dApp-provided names or substring matches.
  const hlSchemas = {
    ApproveAgent: "hyperliquidChain:string agentAddress:address agentName:string nonce:uint64",
    ApproveBuilderFee: "hyperliquidChain:string maxFeeRate:string builder:address nonce:uint64",
    UsdSend: "hyperliquidChain:string destination:string amount:string time:uint64",
    SpotSend: "hyperliquidChain:string destination:string token:string amount:string time:uint64",
    SendAsset: "hyperliquidChain:string destination:string sourceDex:string destinationDex:string token:string amount:string fromSubAccount:string nonce:uint64",
    Withdraw: "hyperliquidChain:string destination:string amount:string time:uint64"
  };
  const hlActionNames = {
    approveAgent: "ApproveAgent", approveBuilderFee: "ApproveBuilderFee",
    usdSend: "UsdSend", spotSend: "SpotSend", sendAsset: "SendAsset", withdraw3: "Withdraw"
  };

  function validHlTypedData(data, name) {
    const domain = data.domain || {};
    const schema = hlSchemas[name];
    const fields = data.types && data.types[data.primaryType];
    const domainFields = data.types && data.types.EIP712Domain;
    if (Object.keys(domain).some(key => !["name", "version", "chainId", "verifyingContract"].includes(key)) ||
        (domainFields !== undefined && (!Array.isArray(domainFields) || domainFields.map(field => `${field.name}:${field.type}`).join(" ") !== "name:string version:string chainId:uint256 verifyingContract:address"))) return false;
    if (!schema || domain.name !== "HyperliquidSignTransaction" || domain.version !== "1" ||
        !/^0x0{40}$/i.test(String(domain.verifyingContract)) ||
        !Number.isSafeInteger(Number(domain.chainId)) || Number(domain.chainId) <= 0 ||
        !Array.isArray(fields) || fields.map(field => `${field.name}:${field.type}`).join(" ") !== schema) return false;
    const message = data.message || {};
    if (Object.keys(message).length !== fields.length) return false;
    return fields.every(field => Object.hasOwn(message, field.name) && (
      field.type === "uint64" ? (typeof message[field.name] !== "number" || Number.isSafeInteger(message[field.name])) && /^(0|[1-9][0-9]*)$/.test(String(message[field.name])) && BigInt(message[field.name]) <= 18446744073709551615n :
      field.type === "address" ? /^0x[0-9a-f]{40}$/i.test(message[field.name]) : typeof message[field.name] === "string"
    ));
  }

  function hlAuthorization(name, message, network, address) {
    const field = (label, value) => ({ label, value: value === "" || value === undefined ? "Not specified" : String(value) });
    const base = { network, securityCritical: true, fields: [] };
    const invalid = () => ({ ...base, requestType: "Signature", subtype: "Unrecognized Hyperliquid authorization", risk: blindRisk("Hyperliquid authorization fields are missing or invalid.") });
    if (!["Mainnet", "Testnet"].includes(message.hyperliquidChain)) return invalid();
    const chain = field("Hyperliquid network", message.hyperliquidChain);
    if (name === "ApproveAgent") {
      if (!/^0x[0-9a-f]{40}$/i.test(message.agentAddress)) return invalid();
      if (/^0x0{40}$/i.test(message.agentAddress)) {
        return { ...base, requestType: "Permission", subtype: "Revoke trading key",
          risk: risk(10, "Low", "low", "Revokes the trading key for the displayed key name on your Hyperliquid account. Removes its trading authority without granting a new key access or moving funds. Automated trading using this key will stop working."),
          fields: [chain, field("Trading key", message.agentAddress), field("Key name (site supplied)", message.agentName || "Unnamed key"), field("Scope", "Remove trading authority for this key name")] };
      }
      return { ...base, requestType: "Permission", subtype: "Authorize trading key",
        risk: risk(85, "High", "high", "Authorizes this trading key to act on your Hyperliquid account without asking for each trade. Trading can lose funds. Review the key address and revoke it when no longer needed."),
        fields: [chain, field("Trading key", message.agentAddress), field("Key name (site supplied)", message.agentName), field("Scope", "Trading authority; no withdrawal permission through this API key"), field("Expiry", "Not independently verified; review and manage the key in Hyperliquid")] };
    }
    if (name === "ApproveBuilderFee") {
      if (!/^0x[0-9a-f]{40}$/i.test(message.builder) || !/^(?:0|[1-9][0-9]*)(?:\.[0-9]+)?%$/.test(message.maxFeeRate)) return invalid();
      return { ...base, requestType: "Permission", subtype: "Authorize trading fees",
        risk: risk(75, "High", "high", `Authorizes builder fees up to ${message.maxFeeRate} on future eligible trade value for this builder, in addition to exchange fees. This is an ongoing rate approval, not a one-time payment. Total future fees are unknown; revoke the approval when no longer needed.`),
        fields: [chain, field("Fee recipient (builder)", message.builder), field("Maximum trading fee rate", message.maxFeeRate), field("Total fee amount", "Unknown; depends on future trades"), field("Duration", "Until changed or revoked")] };
    }
    if (typeof message.amount !== "string" || !/^(?:0|[1-9][0-9]*)(?:\.[0-9]+)?$/.test(message.amount) || !/^0x[0-9a-f]{40}$/i.test(message.destination)) return invalid();
    if (name === "SendAsset" && (typeof message.sourceDex !== "string" || typeof message.destinationDex !== "string" ||
        (message.fromSubAccount && !/^0x[0-9a-f]{40}$/i.test(message.fromSubAccount)))) return invalid();
    const token = name === "UsdSend" || name === "Withdraw" ? "USDC" : message.token;
    if (typeof token !== "string" || !token) return invalid();
    const isHypeSystem = name === "SpotSend" && /^0x2222222222222222222222222222222222222222$/i.test(message.destination);
    const isTokenSystem = name === "SpotSend" && /^0x20000000000000000000000000000000[0-9a-f]{8}$/i.test(message.destination);
    const isEvmSystem = isHypeSystem || isTokenSystem;
    const isWithdrawal = name === "Withdraw" || isEvmSystem;
    const destinationNetwork = name === "Withdraw"
      ? message.hyperliquidChain === "Mainnet" ? "Arbitrum One" : "Arbitrum testnet (verify bridge)"
      : isEvmSystem ? `HyperEVM ${message.hyperliquidChain} system route (verify token link)` : `HyperCore ${message.hyperliquidChain}`;
    return { ...base, requestType: "Value Transfer", subtype: isWithdrawal ? "Authorize withdrawal" : "Authorize HyperCore send",
      risk: isEvmSystem ? blindRisk("A system withdrawal route is requested, but Passli has not verified the token or linked EVM contract. Verify the displayed amount and token. Successful credit cannot be confirmed; bridge fees may apply.") : risk(90, "High", "high", `${isWithdrawal ? "Withdraws" : "Sends"} ${message.amount} ${token} from HyperCore. Verify the amount, asset, destination network, and full address. Transfers can be irreversible. Network or bridge fees may apply.`),
      fields: [chain, field("Amount", message.amount), field("Asset", token), field("Destination network", destinationNetwork), field(isEvmSystem ? "System destination" : "Recipient", message.destination),
        ...(isEvmSystem ? [field("Receiving account on HyperEVM", address || "Sending account; verify signer")] : []),
        ...(name === "SendAsset" ? [field("Source balance", message.sourceDex === "" ? "Default USDC perps" : message.sourceDex), field("Destination balance", message.destinationDex === "" ? "Default USDC perps" : message.destinationDex), field("Source subaccount", message.fromSubAccount || "Main account")] : [])] };
  }

  function decodedFieldsFromObject(object) {
    const token = findField(object, ["token", "asset", "currency", "coin"]);
    const amount = findField(object, ["amount", "amt", "value", "sz", "size"]);
    const recipient = findField(object, ["recipient", "destination", "to", "receiver"]);
    const merchant = findField(object, ["merchant", "payee", "vendor"]);
    const memo = findField(object, ["memo", "note", "description", "orderId"]);
    return [
      token ? { label: "Token", value: token } : null,
      amount ? { label: "Amount", value: formatTokenAmount(amount) } : null,
      recipient ? { label: "Recipient", value: recipient } : null,
      merchant ? { label: "Merchant", value: merchant } : null,
      memo ? { label: "Memo", value: memo } : null
    ].filter(Boolean);
  }

  function analyzeProviderRequest({ origin, method, params, address, fallbackChainId }) {
    const analysis = {
      network: chainName(requestedChainId(method, params, fallbackChainId)),
      requestType: "Request",
      subtype: method,
      fields: [],
      risk: defaultRisk()
    };

    if (method === "eth_requestAccounts" || method === "wallet_requestPermissions") {
      return {
        ...analysis,
        network: "Not chain-specific",
        requestType: "Query",
        subtype: "Share public wallet address",
        securityCritical: true,
        risk: risk(10, "Low", "low", "Shares your wallet address with this site. It does not move funds."),
        fields: [
          { label: "Site", value: origin },
          { label: "Address to provide", value: address || "Selected account" }
        ]
      };
    }

    if (method === "personal_sign") {
      const message = personalSignMessage(params);
      const signer = personalSignSigner(params, address);
      const siwe = parseSiweMessage(message);
      if (siwe) {
        return {
          ...analysis,
          network: siwe.chainId ? chainName(siwe.chainId) : "Not chain-specific",
          requestType: "Sign-In",
          subtype: "Wallet ownership proof",
          risk: risk(8, "Very Low", "low", "Off-chain login signature. It proves wallet ownership and cannot move funds or place orders."),
          fields: [
            { label: "Requested signer", value: signer },
            { label: "Site", value: siwe.domain },
            { label: "URI", value: siwe.uri || "n/a" },
            { label: "Statement", value: siwe.statement || "Proves wallet ownership and logs in." },
            { label: "Chain ID", value: siwe.chainId || "n/a" },
            { label: "Nonce", value: siwe.nonce || "n/a" },
            { label: "Issued at", value: siwe.issuedAt || "n/a" },
            ...(siwe.resources.length ? [{ label: "Resources", value: siwe.resources.join("\n") }] : [])
          ]
        };
      }
      return {
        ...analysis,
        network: "Not chain-specific",
        requestType: "Signature",
        subtype: "Personal message",
        securityCritical: true,
        risk: blindRisk("This message has no recognized authorization format. Its effect cannot be established from the text alone."),
        fields: [
          { label: "Requested signer", value: signer },
          { label: "Message", value: message || "n/a" }
        ]
      };
    }

    if (method === "eth_sign") {
      return {
        ...analysis,
        network: "Not chain-specific",
        requestType: "Signature",
        subtype: "Raw message",
        securityCritical: true,
        risk: blindRisk("The meaning of this raw signature cannot be decoded."),
        fields: [
          { label: "Requested signer", value: params[0] || address || "n/a" },
          { label: "Message", value: String(params[1] || "") }
        ]
      };
    }

    if (method === "eth_signTypedData" || method === "eth_signTypedData_v3" || method === "eth_signTypedData_v4") {
      try {
        const typedData = parseTypedData(params[1]);
        const primaryType = String(typedData.primaryType || "Typed data");
        const message = typedData.message || {};
        const hyperliquidChain = message.hyperliquidChain || "";
        const fields = decodedFieldsFromObject(message);

        const name = primaryType.startsWith("HyperliquidTransaction:") ? primaryType.slice("HyperliquidTransaction:".length) : "";
        if (Object.hasOwn(hlSchemas, name) && validHlTypedData(typedData, name)) {
          return { ...analysis, ...hlAuthorization(name, message, `Hyperliquid ${hyperliquidChain}`, params[0] || address) };
        }

        if (
          primaryType === "Agent" &&
          typedData.domain &&
          typedData.domain.name === "Exchange" &&
          Number(typedData.domain.chainId) === 1337
        ) {
          const connectionId = String(message.connectionId || "");
          const isProbe = /^0x0{64}$/i.test(connectionId);
          return {
            ...analysis,
            network: "Hyperliquid Core",
            requestType: "Signature",
            securityCritical: true,
            subtype: "Hyperliquid L1 action envelope",
            risk: blindRisk("Only a HyperCore action hash is present. The action, amount, fees, and recipient cannot be recovered from it."),
            fields: [
              { label: "Requested signer", value: params[0] || address || "n/a" },
              { label: "Exchange", value: typedData.domain.name || "Exchange" },
              { label: "Source", value: message.source || "unknown" },
              { label: "Connection ID", value: message.connectionId || "unknown" },
              { label: "Envelope", value: "EIP-712 Hyperliquid L1 action envelope" },
              { label: "Important", value: isProbe
                ? "The all-zero hash may be a compatibility probe, but its intent cannot be verified."
                : "The raw Hyperliquid action is not present. To render exact order/cancel details, the dApp must call hyperliquid_authorizeAction." }
            ]
          };
        }

        return {
          ...analysis,
          securityCritical: true,
          requestType: fields.length ? "Value Transfer" : "Signature",
          subtype: primaryType,
          risk: blindRisk("Passli does not recognize this exact typed-data schema. Displayed fields alone do not establish its effect."),
          fields: fields.length ? fields : [
            { label: "Domain", value: typedData.domain && typedData.domain.name ? typedData.domain.name : "Unknown" },
            { label: "Primary type", value: primaryType }
          ]
        };
      } catch {
        return {
          ...analysis,
          requestType: "Signature",
          subtype: "Typed data",
          securityCritical: true,
          risk: blindRisk("Could not decode typed data."),
          fields: [{ label: "Decode", value: "Could not decode typed data." }]
        };
      }
    }

    if (method === "wallet_switchEthereumChain" || method === "wallet_addEthereumChain") {
      return {
        ...analysis,
        requestType: "Network",
        subtype: method === "wallet_switchEthereumChain" ? "Switch chain" : "Add chain",
        risk: risk(18, "Low", "low", "Changes the selected network. It does not move funds."),
        fields: [{ label: "Requested network", value: analysis.network }]
      };
    }

    if (method === "eth_sendTransaction") {
      const tx = params[0] || {};
      const value = tx.value || "0";
      const hasValue = Boolean(value && value !== "0" && value !== "0x0");
      return {
        ...analysis,
        securityCritical: true,
        requestType: "Value Transfer",
        subtype: "EVM transaction",
        risk: tx.data && tx.data !== "0x"
          ? blindRisk("Passli has not decoded this EVM contract call. Its effects and token amounts cannot be confirmed.")
          : hasValue
          ? risk(88, "High", "high", "On-chain transaction that can move funds or interact with contracts.")
          : risk(60, "Medium-High", "high", "On-chain transaction. Even zero-value contract calls can grant permissions or change account state."),
        fields: [
          { label: "Recipient", value: tx.to || "Contract creation" },
          { label: "Value", value }
        ]
      };
    }

    if (method === "hyperliquid_authorizeAction") {
      const request = params[0] || {};
      const action = request.action || {};
      const fields = decodedFieldsFromObject(action);
      const actionType = action.type || "";
      if (Object.hasOwn(hlActionNames, actionType)) {
        return { ...analysis, ...hlAuthorization(hlActionNames[actionType], {
          ...action, hyperliquidChain: action.hyperliquidChain || request.hyperliquidChain
        }, `Hyperliquid ${action.hyperliquidChain || request.hyperliquidChain || "unknown"}`, request.account || address) };
      }
      const isCancelOrder = actionType === "cancel" || actionType === "cancelByCloid";
      const notional = hyperliquidOrderNotional(action);
      const actionRisk = isCancelOrder
        ? risk(5, "Very Low", "low", "Cancels an open order. This reduces resting exposure and does not send funds out.")
        : actionType === "updateLeverage"
          ? risk(8, "Very Low", "low", "Updates leverage settings. This does not place an order or send funds out.")
        : actionType === "order"
          ? risk(
            notional !== null && notional >= 15 ? 90 : notional !== null && notional >= 11 ? 55 : 25,
            notional !== null && notional >= 15 ? "High" : notional !== null && notional >= 11 ? "Medium" : "Low",
            notional !== null && notional >= 15 ? "high" : notional !== null && notional >= 11 ? "medium" : "low",
            notional !== null
              ? `Places or updates an order with about $${formatRiskValue(notional)} notional exposure.`
              : "Places or updates a trading order."
          )
          : blindRisk("Passli has no specific decoder for this Hyperliquid action.");
      return {
        ...analysis,
        securityCritical: !["order", "cancel", "cancelByCloid", "updateLeverage"].includes(actionType),
        network: request.hyperliquidChain ? `Hyperliquid ${request.hyperliquidChain}` : "Hyperliquid Core",
        requestType: isCancelOrder
          ? "Cancel Open Order"
          : request.submitMode === "walletSubmit"
            ? "Submit Action"
            : "Sign Action",
        subtype: actionType || "Hyperliquid action",
        risk: actionRisk,
        fields: [
          { label: "Account", value: request.account || address || "n/a" },
          { label: "Nonce policy", value: request.noncePolicy || "dapp" },
          { label: "Nonce", value: request.nonce || action.nonce || "wallet stamped" },
          ...(notional !== null ? [{ label: "Estimated notional", value: `$${formatRiskValue(notional)}` }] : []),
          ...fields
        ]
      };
    }

    return analysis;
  }

  globalScope.PassliRequestDecoder = {
    analyzeProviderRequest,
    chainName,
    requestedChainId
  };
})(globalThis);
