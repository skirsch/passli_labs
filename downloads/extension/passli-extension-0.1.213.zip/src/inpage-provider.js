(function () {
  function installProvider(currentBridgeToken) {
  if (
    window.__PASSLI_EIP6963_PROVIDER_INSTALLED__ &&
    window.__PASSLI_EIP6963_PROVIDER_TOKEN__ === currentBridgeToken
  ) {
    return;
  }
  if (!window.__PASSLI_EIP6963_PROVIDER_INSTALLED__) {
    Object.defineProperty(window, "__PASSLI_EIP6963_PROVIDER_INSTALLED__", {
      value: true,
      configurable: true,
      enumerable: false,
      writable: false
    });
  }
  Object.defineProperty(window, "__PASSLI_EIP6963_PROVIDER_TOKEN__", {
    value: currentBridgeToken,
    configurable: true,
    enumerable: false,
    writable: false
  });

  const WALLET_NAME = "Passli Safe Wallet";
  const WALLET_RDNS = "app.passli.hyperliquid";
  const WALLET_UUID = "f3dc8a62-3be7-4f83-9a47-62f0f0e69630";
  const WALLET_ICON =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAABmJLR0QA/wD/AP+gvaeTAAAasklEQVR4nO2deZQU1b3Hv99bPT0zDMuMqOwCChocBQ3GJYk4Me4EFRSeSzxBj0ZjTPKi0Wje4705iTEmGIz62DQnGjXRSBIXouKKkcWogwuuERVZRAVGAYWZ6emq3/ujq7pr6+6q6uphaOZ7Tp/puXXr3lu/z69+v1vVtQA96lGPdl9xZw+gHDpq6vLatqrEAZLAAULsS2CIkEMJ7EmyAUANiAYQIGlagVtAtIH4jGSrEB8qYJ2Q75NclUxuf+u5G7/atpM3LXbt+g7QLKrxnRfHKsjXARxJyniQo0FqtLbOhEya3wG44DuXW1Ws75m6BoBVJFYAeIGaWjZ8/VsvL1gwTe/S7Y1Zu6QDHDr12b3SWtVEgicJcRyI/gBNgABIFIbvrGtVKwDfLLSvSwDYKsRijepRQ+GhF2c2ftwFmx+rdhkHOPicJQ1GOnGmgpwl5DEkNQtQnPBpiwjOKAE3fOdywgC4DMR91VryL0t+NXpTmU0Si7q9A4yZsmxCQvESUZwMogYIsneaBXkBojT4PlHC5YQpKlko4PznrxvzJEApn4VKU7d0gMapbyRhbDsbCj8mZFy40GwWsCAgsy0EgB9oflBgHPKWonZjv63qzkdvGd1RNqNFVLdygMapbyQhWy4E+FMA+0Q3emH4MU8Og47jIwh+U61Vz3umeWR7GcwXSd3EAYSNU547G5RfghwBRAzNgNvoCAc/jslhbqx5xrGeVM2Dx4y6Y8E07vQjiJ3uAGOmLD1SgTeBOLzMeXlnTQ7zjeNVBf5oyf+M/mdMpoykneYAh5y+uD6lkr8mcCEI1bV5OR9AawBd5oRC4G4qXLHkZzvnqGGnOMCYKcsmUnAbiUE7OS/DDcgaQtmc0H8bN4lSly27et/74rFwcHWpA4yf1NKrLdE+C+DF3Swv5x9HuSOQcxx/StUalz7/w9HbSrd2MHWZAxw0+bkxBvS/AjywrHkZrrbD5eWd7oQg34Nw2pKrRrxUir2DSnVFJwdNXjrFgP48WQw+Axs9797phu+3PEb4dLWd3wmLw88skv2oZNmEWau/E5f9C6nMEUDYOHnZDAGaaVkmyl4Br9F94cebl6M7oWNd/3EEckLFG/cePPzKch4uls0BmpoWJzbWV90GYvounpd3nhMSoMIDHWntnOcuH1aWn6LL4gDjJ7X0alft94nCxErIyzvLCW1jWJJIpic9efF+W6MRya/YHaBx6uLe6Ez+QyjHdKuTNnC1HYsT2teN1wk920OsSFarEx67cNin4ankV6wOMPaEx+rSdXWPAJhQsXm5C5zQB771/eWU4JtLLx3+WWg4eRTbUcCokx+pTveqewBxwHcYgLl1I8NnUfhkmeG72w4PHyAPTWp8tGn2xt4l4soqHgdoFpWs6XM3yOMcITEqfJ+Q6Ld3BofvGcc2Un0IhfdBvK/ItSC2FXVC+CxHmHEUPjwtAt/6fkSiqv1v4+e3VMWBLhFHIwe+snQmqM4sV0j0g5/twLN3ZtftALiClBaAr0Pwb0PUB+0N+PiN5saU33aM/25LldqreiANNUIT7g/KwaQaL8R4ELWBxhHcCaPABwgIcUIDB84HcEE0YjmxeJXCapy87CIBbo22VyBm+HyHxIOGYFHfL/ouf+aOeH53b2x+I1mvJ44QhZNAnAayMaATZrc7Gnx3HWe5KPz0qenDflPKtpXkAGOmLD2Swn+SSEYLicUM4xMl4GqbqlUod2qG3PninENfKWV7guprP1/VKCLnUfE7IAa6nDBkinBvj23bC8A3PzohpzwxfZ/Ho25LZAfYf9LiPROJ5EskhpUnJPrAd6zLt0nM7L2935/j2tPDqrH5jeQeVclpQl4JYGxXwrf108oqHvr42UPWRdmGiA4gHDN5+UOK+FbIvJw1QAnw31VKzWjZa+x9aKYRbfwxS4Rfv/6900leC+LALoRvNbG0b/WQpiinjCMdBRw4ednFweHTNngvfHo2zg8+AXCbkFd0bE42tswed2+3gQ8ApCy9ZtT9A/fddyyIS0l82lXwzbnA17emP7w60tDDrnDwGUv2NUS9CqJ3MPi5AVvViqcI+7oEKAvTCe3SlbeMWx9lI7taX5357t4JareAmOaNhAgBn646hcqZohhfWXTOsJVhxhrSAYSNU5Y/CeLYPHnZB2DOABHg7yDxoxVzD/19uHF2DzXNWn2WkPMB9C0zfOv/FX05+IgwqSBUCjhoyvJvF4XvGWTYkzZZ+Kt0jYfvqvAB4JnLR95L0caDWFlu+KaNx2/DR5eFGWPgCDDq3H/1rW5P/xtUrsMeF3xE/DEF9uXqqU6qqa/NHRvbOe+dqRNmflyXqkndBcjkcsG3tbm1qko74KHTBnwSZGyBI0B1u/6zeOHnmxyqeztaq06pFPgA8PiVA7c3tQ47k0rmQKGc8AGiX6eu/yLo2AJFgLFT/jVUV8YqEjXZfINS4efqWtVA3vbSwEMu6VYz/Jj1jblrfk3yqpwNERJyvnKHQ+lCjn309EFvFhtPoAig05hRCL7vL2mOgVqj9Vme/cPbKx0+ACz+3vCfgrgRBKiQIRAvfIDQCPw8yHiKOsCYKcuGU+H8QvAzha4NCTA5BLIb9dB+n666qNLhW3r6u8OuUOBdWZtkHSEW+FabU0598JOxxcZS1AESileCrCoZvk+KMP9/Kd1bnbOrP2kjlEhpqN92IchnHTAVABUD/Mx36ppe9OQQCy380uTn+yeqjLUgetEG1jl7t3eac4iA84PNNPTxK249bG1A01WUTv7DR3ulVfolAYb6QkZk+FZ52oCMemTi4DX5xlAwAlRVGReGgu8zuALwhcT03RU+ADx6waBNgDqLRNoXsmIp8AEyoahdWmgM+R2gWZQQF+eHTy98eFNE3skhMHfF3EMfjma6ytET04csA3FdXsjKTA3h4ZtOJBec/Miq6nz953WAg9/817EkRvru2dkcn+sI8MIHfAaYiQir073VVdHNVlmqr9n2SwIrC0JWVkRwlRc/gtizSuszOV/f+SOAhum5nF74F71MlWDwzcnOZStvGLc9or0qTgumNaaUhktASNFfBB0RIdjhI5Tkvc2MfoVjz3u1TtJtnwCoK3DoluvInSIA1wBzZQT/sWLuIZOim6tydcI96+8i+e1QOR8oCN8sT2u6DLn/xIEb3X36RgAjvWMiosL3hCbHcoPCa+IxV+XJ0NR/gehwQi4S9rMRwQ8+rfKEkaRvGvB1AGYufIwGv9DkUMlfWuaNez0OY1Winpw2eK0ibssf3vOVs/hkETjdr0+PAzQ1LU4A6mR3h8Hhwx8+IYD2q5hsVbGixhtApkPBt9fJO1lE0wmPfVzn7s/jAJ8OqT2M5oOUnXnGB26IyaGQT634v7GvxWmsStQjZwxeQ/JvkeDbd0ZvRKiprVHHuPvzSwHfKAof7gH5pwh7GFLE/HhMVPkShXnOqBsSfp6IQCXHuvvycQAeEwd8V4rY3NY/8VBcBqp0LTp94D9BrC4wqw8G3x6hM44wwd2X0wGaRYniUQ642cbtYd+2HD6Dcs0PqLAg3+1YPfIRKQTuoQcyQsJ3r4tDJrVs6GXvyuEAB3+wYn/FzAWMFsRYbtA0+PcymapylcDf4QFYEnyArEro1ePs3TgcQBnGuGztAPAB96B84IOf7+ivPVsGE1W0Hp446CUQH/vuZNHgm8yM/A4A4iDzbzT4sJbn0gWIJT3hP4JIUeST9klgNPh0lCvKQfZuHA5A8Evexku71k8BPXt/VCkude/14eG7HAcc4+jC/o8Q+wb6Ucc9OYTPcquapl6I3zK7h3SDz7uhlgSfgCjuZ+/DGQHIEUXh+80PfKKENQglfLUs1tkNVLd905sgOv3nWAgN3ywfMvU+0aw+sg5w1NTltSD2yA8/G0PCzA82PndjY6xPtdqdtGBaYwrEe26oJcAHiQT2bx1o9ZF1gLa62gH59+ycQ4ScHL5XTgPtDiKY54RQmLODznKdMsBqP/uMIJUw+ou5h2d6Ln65lznCfPABqkgPLeiRTQrrCh3+FYcPT3mC3CPXvCndENsJoAjwHYPItCEiu8Sr07q1yI2FoIaFTxJC9LGazzqAprEOsDcUEr7P/IAat5TXOpUvQrYWhhoOfgaTyv4snHUAgyoRDb610BWaQCiw4t612+VKsK0QfOaBXDBtQJLZ5q0viobKxRVzZdDbAHIdF5scCmS3uNWrvGI6+7s+vPD95gF+TuJIGyq342cdgKIMsd+fFgS+T5Sw4Ge+q1ieZrk7S0ES4oaK6PBBQATZHTPrAIYmHbQa9oVPb2cokiKUOH567FEEUXq5J9o5R3DysMPOBz/DBdk3mOYeFauwnWK1iNLhEyCkoRw22a2kWF807CMEfAJCZu/JsDvAVhg5t3LMMhEevuk42RMOPYomKgwQoGDOd0YEWzrOkw40YfatZFkHSEJrTUOKwg85ORxSDqPsThJgWCD4Lhb5DhNJwIC0Wu1nZ4Nf9E9sBGnEAj/XxqiyWWZ3EblfKPiE48kjbvgEoKpSH1vNZx3gjebGFIlN4eHTCx/Z5fVfa357cFkNVMGa1LKhF4kRoeDbQ77t0vBsFSJ1wMi9s2do3VcEfZCdwAWGj3zwrTqHlM9Ela2qdPVYEFok+Fn7O+BDkeuamXsUj/OCEPBdK307O6OtYVtrReCThCE4olwGqnQR+hGlwHehA0kI5F17H443hiji7UzPLrhwNhw4RWQWHx27ZXYTiVJHe/M/EBQ+XPAzi/iWvQ9nBFB4LTb4ufpfPWHmq5570npUWE2LJUHi2JLgZz/MlSk4bs9zOICuEq/kOqCn4YiTw+q29rrjy2SnitVedZu/BvMezcjw4YIPwDDoeKuKwwFe/u2Ba0h+YpvAeTqJMjk0KGeWx0yVK1E8IzR8+we2sJ/bl9t6be2XPwJkSuS5fPCBXGvOyaF9cD7LgdN60kBwNS2WBJT1rgEEhw/k9kcbfCC7/MVbD2OnvS+/m0OfDQwf1nIbfDjhmzmo947O3tNis1CFa8/61okABniPvEqAT0CRS9x9+UQAPB0OPgrCzyUmKfi8uh7ZZOBS7/yrNPgEQCVPubvyOMALv25cCWKDB242DEWAT4CKh024/n3P7ck9cmpqy6cHQ+H4MPB9c779kyn7/PPt9cvc/fmlAAH4cLbD7IQuB9MNP+jk0CD+O26DVZpEk2tIMgx8wAsfcNYh8diCRnru0fR/SJQm9+d6csGPOjnMrHf8hBt6okA+/ceKzWNITMvtaDHBB0Co+/369HWAz5N4CkBrZPiwljtHYUaGmRAheuSRJHg5FDQoG0zzS8Gwbwv3gLcOyDZpTy3069PXATK3c8t9cd4lbIsMhx9z4wfTS7RVxalpsSSEyB37m4+OzzmCL1gfh/A6iCIW/uFLe33u12+BR8Um/ugI44AnFJUwOZz5zd+933O1kE0D9trSCKLBs5N5f87NCx+u/7M7sPCP+frN6wD/+sX+z4NYWcpdwrD+eCeH/dNQ8yLaqiIlhj7SL98DLvi2lBAEPom1W4f3fSxfv0XeGKLmAO5BWWHBBd9nfuCB70gpOP2Ym9dcFMlaFSgqVeOZ7MELv3C4N+tYNs80PX8B879IsqADpFTvu0C0OuEjEPxMPRf87LrZejdNuPmDQ0NbqxJFbHXDz4Z+G3w/xwCQz0F2VCtV8PmMBR1gRfPgHQLM9u69EeDn9nz7slpN4/3fvK1nPtBJvukLH+HhW2UKuGP20L6tns5sKvrSKD1p3Azyi1w+cjqCb95yTw6tP/4vRRou6cTCptkbe4eyWIXp7wc2rIHCu6HgMz98Ap3UZWaxfos6wAs/G9MK4mbACx/mwIpNDj2O4XhNGgHiK0y03990++qawBarRBF32PaZwjm/eJ075o1s+KBYl4FeHFmVTswk8Wl0+MzWs+35mWfYmo6giOO0tPbApPkbdtvbyWqrOBvEZjdYwAad9jInfFuU2KGpYK+PDeQAzzSP3ELgWk/+L3Jk4D0KyJXnuY79xDZNXzTxT2t2y1vK7hjZsIWUSwv+olccPgBePWdI/0BPZwn88uhPO1OzSf7bmgs44NsjQwD43kmh2Z4CoOHojg5t2bF3rN3PO4rK159H918A4H/9w32mji/83Gfu/GH9bgnaX2AHeKO5MUXFH1q9OUAiPHy64dvraTJGU+qFE/647uSg46sk/Wl0w8+p5AcwXx/jzO0+OT/zXadi87wh/b4fpi8Wr+LU0b95/24S54aH77fXwwvfub4AcoO2R/uMR08Z3eEznIrW+WtaDxRdXU9iIgEFO3xn6H+a4DXzhvUL/VDO0A7QdMO/9zSQfB3EAKA0+P53snrXh1KvUdcvfOzcYbvlU0enr/5sBJU6VQFfJmQICSiRT4R4GQnt4VsH9307atuhHQAAjpn1/iSAD+VmHqXB9xwm+tczCN5Gcsaj0wb1PH0sJkVyAACYMGvNXFIu6SL49vJtoJpVo9pvemDyyG71FLKpb2zsXZM25K5xA0t+KWazSFL7dHsTDDQSxmAdsh3CdaLrTzUPKn58H1SRHeCoWetqk9Sfo8K4OOA75wWB1t9KxflIy5xHzsj/duxyauoLGweiiudBqUkgDgHRxxzrFiFWKKoHjaTcuWC/PbYGbbO5tbVvrSSv0sjLFNCPAAwABgSdAugi6DSwPG3o/33doIbFpW5DZAcAgKZZ60YhYbwIoj4s5MLloZxHV8TjQt6pxHho4aTBO0rZpmKavnh1zef1fU6i4DwoTCJZVWibCGwVys/H7L/H75ptd+X66fpPvhhXlcCDSWJ4AoAyJ30GTPACpCBIGUCnIegU3Lp5fZ/L3Nf6h1FJDgAATbPXnUQx/oHsbczlgB94/R0AnxRwkdL0xQtPHBx5cmTX6S2f7Kck0URNTqTgJCj0CbKtRO6vAhal0umpCxr3/sKvj2s3bT+sl5Jnaoi6JIkqAhpyDpAWQQpAhwjaRdBhAClDkNLxt9pBfaYVc658KtkBAODYOWt+IMDNccEvfpgYYP3M1rUqcgWAlaJhFQysFmVsoKE2V0tV+4LjM6H51KWb+iBh9CIS/WnIIE0Zww1gNDUerMDDhBgQNpVl4VvVMnvzMx2p+hPdV+det21b/2SnerWWGFJLoppEkkDCjAC6CDoBpETQLkCbIdghgpQh6NAFHTpm/HZov2ujsIvFAQDg2DlrZ0LhJ90Cvh0S3OvmhxesXmT41rLf3jWq4Sd22/1q8+e/66X4o14kaknUEqghUWU5AAQdArSLoE0EOwzBDtMROnQDKUPaO2AccNPgPdaG5Rb4TGAxPf29YVeBuD0u+IxhfSv2Fnynrq3NuOBbbdnh5/7Hf56/qvVAy27Nra19NeLiBDIPa0gSqCZRo4heCqhTGaeoJpAkkQCRIKEh88t6Zp7AGqXjsijcYnMAkNK/YdhFJO7JDykkPMIGJvr6OUcoDK9k+LZyN3zkhqqJpi7PAtCTJxGoIUygADQCVchEgV4m+CoTusbsBcP2QAmQvi+HLqb4HADAgmnUG/oNOw/A3cUh5Sv3N3Kp6/tHBK9DFV2/EHygMPzc54zmxZIAAIF8OZKxxVMy+oK3N/XxqVlQsToAkHGCo9cP/Q7IOXHB94bn8Ot7IwJdqcHZZtH1o8DPldWvHb6l0TTZQIF5rC+ADiAtQMrM8dslM/PvFEEagC7WeYGMDwgAkczf2t4YFJZX7A4AAM3NNJ48f+j3Cc4AIXHBiw2+vTwbEbxthoGf+1vwBs1cHWIkAIigIy0ZsGkgc6xvHurtEMF2IzPx6xCgUwSdEKRFoENgCGCIQCAQATo7tPawrMriAJYenz70WpDngmiLA17s8O1tKm+bYeADXviAsw7NAgJQmqoBAB38UBegE4KUiHmcjwx8Ababs/420ylSZnSwzgoapvMYAv2z9obsAyCDqqwOAABPnDfkHtGMCQTXlgaP2fJS188bTcwrk/x/pXS2Wwp8s42tAGDoeEY3wToO9cy9f7shWSdoN9NBSswo4Pws87v7t5jK7gAA8MTZ+7QkyfFQWBQdnhN8qesXjCZZR/B3njwhPTB8EjA6jTcB4J1BvZelBes7DTHhZ/b+HSb47SLYbuTK2gwzHRhA2sjMF8wIsCAKG0ZZKbJEeNKCD38MxesIVscBL3b4fm3Cua4HrKfM6yCusndv3ad+tGWWqzdsuTCheFtCZY7xE7QO9zJ9CzIng9KSOSWctn4LMD8pQ9YkUg0H3DKaoS+a6ZIIkBUpi6YNnaUp7TBoaHHm3W4Kn4jlBk1HHYXb7WZ5b1C/2zsNeTxlmKd3DUG7ubfvMD/teua0b0rP1LE5QLpTl4uiwAe62gFMPTxl4Ou9OwcdSYUrqPCFdRt0WHhdAp+ZMTtA21JCWPiK2IQOY7bdHgtInZ04K6XLSx26dX4/c5q3wzDMvxnw1seEr6eA7/9+3/5PRGXBqCvGpZMfWT9U09WvhTwb1p1lgSE5y8NDLg7fA9aWEpywM9tTpI6AmDZ/aP1f/Wzx3Q0betUZtfMU+W1rLgrkjvWtw75M3pePDEMumD+y/6JS7L/THcDStxZ+dDgTuF7AbwDdDL5tjw4K31Fm/lXCGXP3Kf6r3ffXbT1CUf+xEp4MoK91wscQwIC8quu4t602dctdA0u/8qjbOIClSY99fCyIGQCagPDwuin8Dggvn79PvzlhbPHdFqnigG0j0GkMEsUvOju1dbeP7hPr9ZDdzgEsnfbYx0dIApcDnAygqtvCd9VxwTdILtR0dc2cEX0cT+nuLuq2DmDp1Mc3DWbCuBAK5wMYEeM1hf7w7Q6AwiE9V+a+U4cbSLlTM3Db3OH173eFnaKq2ztAViI89dlNR5M8m5TJpP1RqnBBLe4kkeF7Qn+2TiuJBwn85bNh/Z4q9FSO7qRdxwFsahZRry7feASVdgpgHAfyMGTOoXQlfIPkKxQ8ScijQ0fUL20m011qiBi0SzqAW6cu3dRHq1ZHasSRAhlPyFgojgDBMPDzh3SAxDoCKxXRYlBegHD5HSMbutV9CVFUEQ7gp0ktG3rVaLX7g/pIkPuIJoOUcG/R0I9QfUlJkqiDAiBoV2QbKF8A/ExRNpPcQHI9DazW0p3v5HvOXo961KMe9ahHu6j+HwRmQgPVyM65AAAAAElFTkSuQmCC";

  let nextId = 1;
  let selectedAddress = null;
  let chainId = null;
  const pending = new Map();
  const listeners = new Map();
  const REQUEST_TIMEOUT_MS = 5 * 60 * 1000;
  const BRIDGE_TOKEN = currentBridgeToken;
  const INPAGE_REQUEST_TYPE = "HYPERLIQUID_DEMO_INPAGE_REQUEST_V3";
  const CONTENT_RESPONSE_TYPE = "HYPERLIQUID_DEMO_CONTENT_RESPONSE_V3";
  const PROVIDER_EVENT_TYPE = "HYPERLIQUID_DEMO_PROVIDER_EVENT_V3";

  function emit(eventName, value) {
    const callbacks = listeners.get(eventName);
    if (!callbacks) return;
    for (const callback of callbacks) {
      try {
        callback(value);
      } catch (error) {
        setTimeout(() => {
          throw error;
        });
      }
    }
  }

  function emitDebug(phase, payload, persist = false) {
    window.postMessage(
      {
        type: "HYPERLIQUID_DEMO_INPAGE_DEBUG",
        phase,
        persist,
        ...payload
      },
      window.location.origin
    );
    window.dispatchEvent(
      new CustomEvent("hyperliquid-demo-wallet:debug", {
        detail: {
          phase,
          time: new Date().toISOString(),
          persist,
          ...payload
        }
      })
    );
  }

  function request(args) {
    if (!args || typeof args.method !== "string") {
      return Promise.reject({
        code: -32600,
        message: "Provider request requires a method"
      });
    }

    const id = nextId++;
    emitDebug("request", {
      id,
      method: args.method,
      params: args.params || []
    }, false);
    window.postMessage(
      {
        type: INPAGE_REQUEST_TYPE,
        bridgeToken: BRIDGE_TOKEN,
        id,
        method: args.method,
        deadline: Date.now() + REQUEST_TIMEOUT_MS,
        params: args.params || []
      },
      window.location.origin
    );

    return new Promise((resolve, reject) => {
      const timeout = window.setTimeout(() => {
        pending.delete(id);
        const error = {
          code: -32000,
          message:
            "No response from extension bridge. Refresh this page after reloading the extension."
        };
        emitDebug("timeout", {
          id,
          method: args.method,
          error
        }, true);
        reject(error);
      }, REQUEST_TIMEOUT_MS);

      pending.set(id, { resolve, reject, method: args.method, timeout });
    });
  }

  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    const message = event.data;
    if (!message || message.type !== CONTENT_RESPONSE_TYPE || message.bridgeToken !== BRIDGE_TOKEN) return;

    const entry = pending.get(message.id);
    if (!entry) return;
    pending.delete(message.id);
    window.clearTimeout(entry.timeout);

    const payload = message.response || {};
    emitDebug("response", {
      id: message.id,
      method: entry.method,
      response: payload
    }, false);
    if (payload.error) {
      entry.reject(payload.error);
      return;
    }

    if (entry.method === "eth_requestAccounts" || entry.method === "eth_accounts") {
      const previousAddress = selectedAddress;
      selectedAddress = Array.isArray(payload.result) ? payload.result[0] || null : null;
      if (entry.method === "eth_requestAccounts") {
        if (previousAddress !== selectedAddress) {
          emit("accountsChanged", payload.result || []);
        }
        emit("connect", { chainId });
        request({ method: "eth_chainId" })
          .then((latestChainId) => emit("connect", { chainId: latestChainId }))
          .catch(() => {});
      }
    }

    if (entry.method === "eth_chainId") {
      chainId = payload.result;
    }

    if (entry.method === "wallet_switchEthereumChain") {
      request({ method: "eth_chainId" })
        .then((chainId) => emit("chainChanged", chainId))
        .catch(() => {});
    }

    entry.resolve(payload.result);
  });

  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    const message = event.data;
    if (!message || message.type !== PROVIDER_EVENT_TYPE || message.bridgeToken !== BRIDGE_TOKEN) return;

    if (message.eventName === "accountsChanged") {
      selectedAddress = Array.isArray(message.payload) ? message.payload[0] || null : null;
    }
    if (message.eventName === "chainChanged") {
      chainId = message.payload;
    }
    emit(message.eventName, message.payload);
    emitDebug("providerEvent", {
      method: message.eventName,
      result: message.payload
    }, true);
  });

  const provider = {
    isHyperliquidDemo: true,
    isPassli: true,
    isPassliSafeWallet: true,
    isMetaMask: false,
    isConnected() {
      return true;
    },
    get selectedAddress() {
      return selectedAddress;
    },
    get chainId() {
      return chainId;
    },
    request,
    enable() {
      return request({ method: "eth_requestAccounts" });
    },
    send(methodOrPayload, callbackOrParams) {
      if (typeof methodOrPayload === "string") {
        return request({ method: methodOrPayload, params: callbackOrParams || [] });
      }

      const payload = methodOrPayload || {};
      const run = request({ method: payload.method, params: payload.params || [] })
        .then((result) => ({
          id: payload.id,
          jsonrpc: payload.jsonrpc || "2.0",
          result
        }))
        .catch((error) => ({
          id: payload.id,
          jsonrpc: payload.jsonrpc || "2.0",
          error
        }));

      if (typeof callbackOrParams === "function") {
        run.then((response) => callbackOrParams(response.error || null, response));
        return undefined;
      }

      return run;
    },
    sendAsync(payload, callback) {
      const runOne = (item) =>
        request({ method: item.method, params: item.params || [] })
          .then((result) => ({
            id: item.id,
            jsonrpc: item.jsonrpc || "2.0",
            result
          }))
          .catch((error) => ({
            id: item.id,
            jsonrpc: item.jsonrpc || "2.0",
            error
          }));

      const run = Array.isArray(payload)
        ? Promise.all(payload.map(runOne))
        : runOne(payload || {});

      run.then((response) => callback(null, response)).catch((error) => callback(error));
    },
    on(eventName, callback) {
      if (typeof callback !== "function") return this;
      if (!listeners.has(eventName)) listeners.set(eventName, new Set());
      listeners.get(eventName).add(callback);
      return this;
    },
    addListener(eventName, callback) {
      return this.on(eventName, callback);
    },
    removeListener(eventName, callback) {
      const callbacks = listeners.get(eventName);
      if (callbacks) callbacks.delete(callback);
      return this;
    },
    off(eventName, callback) {
      return this.removeListener(eventName, callback);
    },
    removeAllListeners(eventName) {
      if (eventName) {
        listeners.delete(eventName);
      } else {
        listeners.clear();
      }
      return this;
    }
  };

  const detail = Object.freeze({
    info: Object.freeze({
      uuid: WALLET_UUID,
      name: WALLET_NAME,
      icon: WALLET_ICON,
      rdns: WALLET_RDNS
    }),
    provider: Object.freeze(provider)
  });

  function announceProvider(event) {
    const requestedByPage = Boolean(event);
    emitDebug("announceProvider", {
      method: "eip6963:announceProvider",
      params: requestedByPage ? ["eip6963:requestProvider"] : [],
      result: {
        name: WALLET_NAME,
        rdns: WALLET_RDNS,
        uuid: WALLET_UUID
      }
    }, true);
    window.dispatchEvent(
      new CustomEvent("eip6963:announceProvider", {
        detail
      })
    );
  }

  window.addEventListener("eip6963:requestProvider", announceProvider);
  announceProvider();

  function defineProviderGlobal(name, configurable = true, writable = false) {
    try {
      Object.defineProperty(window, name, {
        value: provider,
        configurable,
        enumerable: false,
        writable
      });
    } catch {
      // Older builds defined some provider globals as non-configurable. A page
      // reload replaces those stale objects; EIP-6963 still receives this provider.
    }
  }

  if (!window.hyperliquidDemoWallet || window.__PASSLI_EIP6963_PROVIDER_TOKEN__ === BRIDGE_TOKEN) {
    defineProviderGlobal("hyperliquidDemoWallet");
  }

  if (!window.passliSafeWallet || window.__PASSLI_EIP6963_PROVIDER_TOKEN__ === BRIDGE_TOKEN) {
    defineProviderGlobal("passliSafeWallet");
  }

  if (!window.ethereum) {
    defineProviderGlobal("ethereum", true, true);
  }
  }

  // An unpacked extension can retain the old registered content script until
  // reload while serving this newer resource. Honor its existing DOM token so
  // that a mixed-version tab does not wait forever for a handshake it never sends.
  const legacyScript = document.currentScript;
  if (legacyScript?.src) {
    const legacyUrl = new URL(legacyScript.src);
    const legacyToken = legacyUrl.searchParams.get("bridgeToken");
    if (legacyUrl.protocol === "chrome-extension:" && legacyUrl.pathname === "/src/inpage-provider.js" && legacyToken) {
      installProvider(legacyToken);
      return;
    }
  }

  // Either content-script world may start first. The initial message plus READY
  // reply handle both orders without DOM script tags, timers or privileged APIs.
  function initialize(event) {
    if (event.source !== window || event.origin !== window.location.origin) return;
    const message = event.data;
    if (message?.type !== "PASSLI_PROVIDER_BRIDGE_INIT" || typeof message.bridgeToken !== "string" || !message.bridgeToken) return;
    window.removeEventListener("message", initialize);
    installProvider(message.bridgeToken);
    window.postMessage({ type: "PASSLI_PROVIDER_BRIDGE_INITIALIZED", bridgeToken: message.bridgeToken }, window.location.origin);
  }
  window.addEventListener("message", initialize);
  window.postMessage({ type: "PASSLI_PROVIDER_BRIDGE_READY" }, window.location.origin);
})();
