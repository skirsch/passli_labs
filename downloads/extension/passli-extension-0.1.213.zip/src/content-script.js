const BRIDGE_TOKEN = `${Date.now()}-${Math.random().toString(16).slice(2)}`;
const INPAGE_REQUEST_TYPE = "HYPERLIQUID_DEMO_INPAGE_REQUEST_V3";
const CONTENT_RESPONSE_TYPE = "HYPERLIQUID_DEMO_CONTENT_RESPONSE_V3";
const PROVIDER_EVENT_TYPE = "HYPERLIQUID_DEMO_PROVIDER_EVENT_V3";
const PASSLI_BRIDGE_REQUEST_TYPE = "passli.extension.request.v1";
const PASSLI_BRIDGE_APPROVAL_TYPE = "passli.extension.approval.v1";
const PASSLI_BRIDGE_RESPONSE_TYPE = "passli.extension.response.v1";
const PASSLI_PROVISION_OPERATIONAL_KEYS_TYPE = "passli.extension.provisionOperationalKeys.v1";
const PASSLI_PROVISION_OPERATIONAL_KEYS_RESULT_TYPE = "passli.extension.provisionOperationalKeysResult.v1";
const PASSLI_EXTENSION_AUTH_STATUS_TYPE = "PASSLI_EXTENSION_AUTH_STATUS";
const PASSLI_EXTENSION_ADDRESSES_UPDATED_TYPE = "passli.extension.addressesUpdated.v1";
const PASSLI_EXTENSION_SELECTED_ADDRESS_STATUS_TYPE = "PASSLI_EXTENSION_SELECTED_ADDRESS_STATUS";
const PASSLI_EXTENSION_RUNTIME_STATUS_TYPE = "PASSLI_EXTENSION_RUNTIME_STATUS";
const PASSLI_EXTENSION_VERSION_MISMATCH_TYPE = "PASSLI_EXTENSION_VERSION_MISMATCH";
const PASSLI_EXTERNAL_AUTHORITY_WALLETS_TYPE = "PASSLI_EXTENSION_EXTERNAL_AUTHORITY_WALLETS";
const PASSLI_EXTENSION_DAPP_CONNECTIONS_REQUEST_TYPE = "PASSLI_EXTENSION_DAPP_CONNECTIONS_REQUEST";
const PASSLI_EXTENSION_DAPP_CONNECTIONS_RESPONSE_TYPE = "PASSLI_EXTENSION_DAPP_CONNECTIONS_RESPONSE";
const PASSLI_EXTENSION_REVOKE_DAPP_CONNECTION_TYPE = "PASSLI_EXTENSION_REVOKE_DAPP_CONNECTION";
const PASSLI_REQUIRED_WEB_VERSION = "0.1.88";
const PASSLI_EXTENSION_PROTOCOL_VERSION = 1;
const PASSLI_AUTH_ORIGINS = new Set([
  "https://passli.app",
  "http://localhost:5173",
  "http://localhost:8081",
  "http://127.0.0.1:8081"
]);
const shownVersionMismatchAlerts = new Set();

// Chrome loads the provider in MAIN directly. Do not insert an extension URL
// into the page: page resource policies can reject that load before JS can catch it.
// This public token correlates messages; origin/grant/approval checks in the
// background remain the authority boundary, just as with the former DOM token.
function initializeProviderBridge() {
  postToPage({ type: "PASSLI_PROVIDER_BRIDGE_INIT", bridgeToken: BRIDGE_TOKEN });
}
let providerReadyLogged = false;
window.addEventListener("message", (event) => {
  if (event.source !== window || event.origin !== window.location.origin) return;
  if (event.data?.type === "PASSLI_PROVIDER_BRIDGE_READY") initializeProviderBridge();
  if (event.data?.type === "PASSLI_PROVIDER_BRIDGE_INITIALIZED" && event.data.bridgeToken === BRIDGE_TOKEN && !providerReadyLogged) {
    providerReadyLogged = true;
    appendDebugLog({ persist: true, phase: "content-script:provider-initialized", method: "initializeProviderBridge" });
  }
});
initializeProviderBridge();

function postToPage(message) {
  try {
    window.postMessage(message, "*");
  } catch {
    // Stale content scripts can outlive an unpacked extension reload.
  }
}

function extensionRuntimeStatusPayload() {
  return {
    extensionProtocolVersion: PASSLI_EXTENSION_PROTOCOL_VERSION,
    extensionVersion: chrome.runtime.getManifest().version || "unknown",
    requiredWebVersion: PASSLI_REQUIRED_WEB_VERSION,
    source: "passli-extension",
    type: PASSLI_EXTENSION_RUNTIME_STATUS_TYPE
  };
}

function notifyPageVersionMismatch(error, showLegacyAlert = false) {
  const errorMessage = error && error.message ? error.message : String(error || "Passli extension version mismatch.");
  postToPage({
    ...extensionRuntimeStatusPayload(),
    error: errorMessage,
    type: PASSLI_EXTENSION_VERSION_MISMATCH_TYPE
  });
  if (showLegacyAlert && !shownVersionMismatchAlerts.has(errorMessage)) {
    shownVersionMismatchAlerts.add(errorMessage);
    setTimeout(() => window.alert(errorMessage), 0);
  }
}

postToPage(extensionRuntimeStatusPayload());
setTimeout(() => {
  try { postToPage(extensionRuntimeStatusPayload()); }
  catch { /* An extension reload can retire this document's runtime before the delayed status. */ }
}, 500);

function appendDebugLog(entry) {
  if (!entry || (!entry.enabled && !entry.persist)) return;
  const { enabled, persist, ...debugEntry } = entry;
  postToPage({
    type: "HYPERLIQUID_DEMO_CONTENT_DEBUG",
    ...debugEntry
  });

  if (!persist) return;

  try {
    chrome.runtime.sendMessage({
      type: "HYPERLIQUID_DEMO_DEBUG",
      action: "appendContentDebugLog",
      origin: window.location.origin,
      ...debugEntry
    });
  } catch {
    // Stale content scripts can outlive an unpacked extension reload.
  }
}

window.addEventListener("message", (event) => {
  try {
    if (event.source !== window) return;
    const message = event.data;
    if (message && message.type === "HYPERLIQUID_DEMO_INPAGE_DEBUG") {
      appendDebugLog({
        enabled: message.enabled,
        persist: message.persist,
        phase: message.phase,
        method: message.method || "inpage",
        params: message.params,
        error: message.error,
        result: message.result
      });
      return;
    }

    if (message && message.type === "PASSLI_EXTENSION_LOGIN_COMPLETE") {
      chrome.runtime.sendMessage({
        type: "PASSLI_EXTENSION_LOGIN_COMPLETE",
        appVersion: message.appVersion || "",
        origin: window.location.origin,
        requiredExtensionVersion: message.requiredExtensionVersion || "",
        requestId: message.requestId,
        session: message.session || null,
        selectedAddress: message.selectedAddress || null,
        selectedAddressId: message.selectedAddressId || "",
        selectedWallet: message.selectedWallet || null
      }, (response) => {
        if (response && response.error) notifyPageVersionMismatch(new Error(response.error.message || "Passli extension login failed."), !message.appVersion);
      });
      return;
    }

    if (message && message.type === PASSLI_EXTENSION_AUTH_STATUS_TYPE) {
      chrome.runtime.sendMessage({
        type: PASSLI_EXTENSION_AUTH_STATUS_TYPE,
        appVersion: message.appVersion || "",
        origin: window.location.origin,
        requiredExtensionVersion: message.requiredExtensionVersion || "",
        status: message.status || "",
        session: message.session || null,
        selectedAddress: message.selectedAddress || null,
        selectedAddressId: message.selectedAddressId || "",
        selectedWallet: message.selectedWallet || null,
        source: message.source || "passli.app"
      }, (response) => {
        if (response && response.error) notifyPageVersionMismatch(new Error(response.error.message || "Passli extension auth sync failed."), !message.appVersion);
      });
      return;
    }

    if (message && message.type === PASSLI_EXTERNAL_AUTHORITY_WALLETS_TYPE) {
      chrome.runtime.sendMessage({
        type: PASSLI_EXTERNAL_AUTHORITY_WALLETS_TYPE,
        accountId: message.accountId || "",
        appVersion: message.appVersion || "",
        origin: window.location.origin,
        requiredExtensionVersion: message.requiredExtensionVersion || "",
        source: message.source || "passli.app",
        wallets: Array.isArray(message.wallets) ? message.wallets : []
      }, (response) => {
        if (response && response.error) notifyPageVersionMismatch(new Error(response.error.message || "Passli authority wallet sync failed."), !message.appVersion);
      });
      return;
    }

    if (message && message.type === PASSLI_EXTENSION_ADDRESSES_UPDATED_TYPE) {
      chrome.runtime.sendMessage({
        type: PASSLI_EXTENSION_ADDRESSES_UPDATED_TYPE,
        accountId: message.accountId || "",
        addresses: Array.isArray(message.addresses) ? message.addresses : [],
        alias: message.alias || "",
        appVersion: message.appVersion || "",
        createdAt: message.createdAt || "",
        origin: window.location.origin,
        requestId: message.requestId || "",
        requiredExtensionVersion: message.requiredExtensionVersion || "",
        selectedAddressId: message.selectedAddressId || "",
        source: message.source || "passli.app",
        version: message.version || 1
      }, (response) => {
        if (response && response.error) notifyPageVersionMismatch(new Error(response.error.message || "Passli address sync failed."), !message.appVersion);
      });
      return;
    }

    if (message && message.type === PASSLI_EXTENSION_DAPP_CONNECTIONS_REQUEST_TYPE) {
      if (!PASSLI_AUTH_ORIGINS.has(window.location.origin)) return;
      chrome.runtime.sendMessage({
        type: "HYPERLIQUID_DEMO_DEBUG",
        action: "getConnections"
      }, (response) => {
        postToPage({
          error: response && response.error ? response.error : null,
          requestId: message.requestId || "",
          result: response && response.result ? response.result : null,
          source: "passli-extension",
          type: PASSLI_EXTENSION_DAPP_CONNECTIONS_RESPONSE_TYPE
        });
      });
      return;
    }

    if (message && message.type === PASSLI_EXTENSION_REVOKE_DAPP_CONNECTION_TYPE) {
      if (!PASSLI_AUTH_ORIGINS.has(window.location.origin)) return;
      chrome.runtime.sendMessage({
        type: "HYPERLIQUID_DEMO_DEBUG",
        action: "revokeDappConnection",
        connectionKey: message.connectionKey || "",
        origin: message.origin || ""
      }, (response) => {
        postToPage({
          error: response && response.error ? response.error : null,
          requestId: message.requestId || "",
          result: response && response.result ? response.result : null,
          source: "passli-extension",
          type: PASSLI_EXTENSION_DAPP_CONNECTIONS_RESPONSE_TYPE
        });
      });
      return;
    }

    if (message && message.type === PASSLI_BRIDGE_RESPONSE_TYPE) {
      chrome.runtime.sendMessage({
        type: "PASSLI_EXTENSION_BRIDGE_RESPONSE",
        origin: window.location.origin,
        response: message
      });
      return;
    }

    if (message && message.type === PASSLI_PROVISION_OPERATIONAL_KEYS_TYPE) {
      chrome.runtime.sendMessage(
        {
          type: "PASSLI_EXTENSION_PROVISION_OPERATIONAL_KEYS",
          origin: window.location.origin,
          payload: message
        },
        (response) => {
          let runtimeErrorMessage = "";
          try {
            runtimeErrorMessage = chrome.runtime.lastError ? chrome.runtime.lastError.message : "";
          } catch (error) {
            runtimeErrorMessage = error && error.message ? error.message : "Extension context invalidated.";
          }
          postToPage({
            type: PASSLI_PROVISION_OPERATIONAL_KEYS_RESULT_TYPE,
            extensionProtocolVersion: PASSLI_EXTENSION_PROTOCOL_VERSION,
            extensionVersion: chrome.runtime.getManifest().version || "unknown",
            requestId: message.requestId,
            requiredWebVersion: PASSLI_REQUIRED_WEB_VERSION,
            status: response && response.result && response.result.status ? response.result.status : "",
            keyRecordId: response && response.result && response.result.keyRecordId ? response.result.keyRecordId : "",
            error: runtimeErrorMessage
              ? { code: -32603, message: runtimeErrorMessage }
              : response && response.error
                ? response.error
                : null
          });
          if (response && response.error) {
            notifyPageVersionMismatch(new Error(response.error.message || "Passli extension provisioning failed."), !message.appVersion);
          }
        }
      );
      return;
    }

    if (!message || message.type !== INPAGE_REQUEST_TYPE || message.bridgeToken !== BRIDGE_TOKEN) return;

    appendDebugLog({
      enabled: message.debug === true,
      persist: true,
      type: "HYPERLIQUID_DEMO_CONTENT_DEBUG",
      phase: "content-script:request",
      id: message.id,
      method: message.method,
      params: message.params || []
    });

    try {
      pendingProviderRequests.set(message.id, Math.min(Number(message.deadline) || Date.now(), Date.now() + 5 * 60 * 1000));
      chrome.runtime.sendMessage(
        {
          type: "HYPERLIQUID_DEMO_PROVIDER_REQUEST",
          id: message.id,
          method: message.method,
          deadline: Math.min(Number(message.deadline) || Date.now(), Date.now() + 5 * 60 * 1000),
          params: message.params
        },
        (response) => {
          pendingProviderRequests.delete(message.id);
          let runtimeErrorMessage = "";
          try {
            runtimeErrorMessage = chrome.runtime.lastError ? chrome.runtime.lastError.message : "";
          } catch (error) {
            runtimeErrorMessage = error && error.message ? error.message : "Extension context invalidated.";
          }

          if (runtimeErrorMessage) {
            response = {
              error: {
                code: -32603,
                message: runtimeErrorMessage
              }
            };
          }
          appendDebugLog({
            enabled: message.debug === true,
            persist: true,
            phase: "content-script:response",
            id: message.id,
            method: message.method,
            response: response || null
          });
          postToPage(
            {
              type: CONTENT_RESPONSE_TYPE,
              bridgeToken: BRIDGE_TOKEN,
              id: message.id,
              response: response || {
                error: {
                  code: -32603,
                  message: runtimeErrorMessage || "No response from extension"
                }
              }
            }
          );
        }
      );
    } catch (error) {
      pendingProviderRequests.delete(message.id);
      postToPage(
        {
          type: CONTENT_RESPONSE_TYPE,
          bridgeToken: BRIDGE_TOKEN,
          id: message.id,
          response: {
            error: {
              code: -32603,
              message: error && error.message ? error.message : "Extension context unavailable"
            }
          }
        }
      );
    }
  } catch {
    // Do not let stale page listeners surface extension reload noise.
  }
});

chrome.runtime.onMessage.addListener((message) => {
  if (!message || message.type !== "HYPERLIQUID_DEMO_PROVIDER_EVENT") return false;
  postToPage({
    type: PROVIDER_EVENT_TYPE,
    bridgeToken: BRIDGE_TOKEN,
    eventName: message.eventName,
    payload: message.payload
  });
  return false;
});

chrome.runtime.onMessage.addListener((message) => {
  if (!message || message.type !== "PASSLI_EXTENSION_BRIDGE_TO_PAGE") return false;
  const payload = message.payload || {};
  if (payload.type !== PASSLI_BRIDGE_REQUEST_TYPE && payload.type !== PASSLI_BRIDGE_APPROVAL_TYPE) {
    return false;
  }
  window.postMessage(payload, window.location.origin);
  return false;
});

chrome.runtime.onMessage.addListener((message) => {
  if (message && message.type === "PASSLI_EXTENSION_REQUEST_AUTH_STATUS") {
    window.postMessage({
      type: "PASSLI_EXTENSION_AUTH_STATUS_REQUEST",
      extensionVersion: chrome.runtime.getManifest().version || "unknown",
      requestId: message.requestId || `${Date.now()}-${Math.random().toString(16).slice(2)}`,
      requiredWebVersion: PASSLI_REQUIRED_WEB_VERSION,
      source: "passli.extension"
    }, window.location.origin);
    return false;
  }

  if (!message || message.type !== "PASSLI_EXTENSION_STATUS_TO_PAGE") return false;
  const payload = message.payload || {};
  if (
    payload.type !== "PASSLI_EXTENSION_SELECTED_WALLET_STATUS" &&
    payload.type !== PASSLI_EXTENSION_SELECTED_ADDRESS_STATUS_TYPE &&
    payload.type !== PASSLI_EXTENSION_RUNTIME_STATUS_TYPE &&
    payload.type !== PASSLI_EXTENSION_VERSION_MISMATCH_TYPE
  ) return false;
  window.postMessage(payload, window.location.origin);
  return false;
});


const pendingProviderRequests = new Map();
window.addEventListener('pagehide', () => pendingProviderRequests.clear());
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
 if (message?.type !== 'PASSLI_PROVIDER_REQUEST_PENDING') return false;
 sendResponse({ pending: (pendingProviderRequests.get(message.id) || 0) > Date.now() });
 return false;
});

chrome.runtime.onMessage.addListener((message,sender,sendResponse)=>{
 const probe=message?.type==='PASSLI_SIGNED_CLOUD_PROBE';
 if(!probe&&message?.type!=='PASSLI_SIGNED_CLOUD_REQUEST')return false;
 if(!PASSLI_AUTH_ORIGINS.has(window.location.origin))return false;
 const requestId=crypto.randomUUID();
 const responseType=probe?'PASSLI_SIGNED_CLOUD_PROBE_RESPONSE':'PASSLI_SIGNED_CLOUD_RESPONSE';
 const timer=setTimeout(()=>{window.removeEventListener('message',receive);sendResponse({status:probe?503:504,body:{error:probe?'Refresh Passli and log in to enable cloud signing.':'Passli did not finish signing within five minutes. Check the approval in the Passli tab before starting a new request.',code:probe?'PASSLI_TAB_UNAVAILABLE':'PASSLI_SIGNING_TIMEOUT'}})},probe?1500:5*60*1000);
 function receive(event){if(event.source!==window||event.origin!==window.location.origin||event.data?.type!==responseType||event.data.requestId!==requestId)return;clearTimeout(timer);window.removeEventListener('message',receive);sendResponse(event.data)}
 window.addEventListener('message',receive);
 window.postMessage({...message,requestId},window.location.origin);
 return true;
});
