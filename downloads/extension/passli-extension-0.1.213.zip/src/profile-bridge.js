globalThis.PassliExtensionProfiles={install({chrome,selectPairedTab}){
 chrome.runtime.onMessage.addListener((message,sender,sendResponse)=>{
  if(message?.type==='PASSLI_EXTENSION_PROFILES'){
    (async()=>{
      if(sender.id!==chrome.runtime.id||sender.url!==chrome.runtime.getURL('src/popup.html'))throw Error('Open profiles from the Passli extension.');
      if(!['list','select','manage'].includes(message.action))throw Error('Unsupported profile action.');
      const stored=await chrome.storage.local.get(['passliExtensionLoggedIn','passliExtensionAccountId','passliExtensionDeviceId']);
      if(!stored.passliExtensionLoggedIn||!message.accountId||message.accountId!==stored.passliExtensionAccountId||!message.deviceId||message.deviceId!==stored.passliExtensionDeviceId)throw Error('The attached Passli account changed. Reopen the extension.');
      if(message.action==='select'&&(!Number.isSafeInteger(message.roleId)||message.roleId<0))throw Error('Choose a valid profile.');
      const {selectedTab}=await selectPairedTab({userId:message.accountId,deviceId:message.deviceId});
      const result=await chrome.tabs.sendMessage(selectedTab.id,{type:'PASSLI_SIGNED_CLOUD_REQUEST',path:'/api/roles',payload:{userId:message.accountId,deviceId:message.deviceId,action:message.action,...(message.action==='select'?{roleId:message.roleId}:{})}});
      if(result?.status!==200)throw Error(result?.body?.error||'Could not load profiles. Update your signed-in Passli tab.');
      if(message.action==='manage'){await chrome.tabs.update(selectedTab.id,{active:true});if(Number.isInteger(selectedTab.windowId))await chrome.windows.update(selectedTab.windowId,{focused:true});}
      return result.body;
    })().then(sendResponse,error=>sendResponse({error:{message:error.message}}));
    return true;
  }
 return false;
 });
}};
