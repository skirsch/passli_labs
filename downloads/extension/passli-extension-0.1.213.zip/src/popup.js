const DEFAULT_PRIVATE_KEY = "";
const DEFAULT_ADDRESS = "0x3b0322eD10Cd526681E3eB91e45176522AC9Db30";
const DEFAULT_CHAIN_ID = "0x3e7";
const DEFAULT_HYPERLIQUID_CHAIN = "Mainnet";
const DEFAULT_SIGNATURE_CHAIN_ID = "0xa4b1";
const PASSLI_AUTH_URL = "https://passli.app";
const PASSLI_API_URL = PASSLI_AUTH_URL;
const PASSLI_AUTH_ORIGINS = new Set([
  "https://passli.app",
  "http://localhost:5173",
  "http://localhost:8081",
  "http://127.0.0.1:8081"
]);

const authView = document.querySelector("#authView");
const walletView = document.querySelector("#walletView");
const loginPassliButton = document.querySelector("#loginPassli");
const logoutPassliButton = document.querySelector("#logoutPassli");
const authStatus = document.querySelector("#authStatus");
const loggedInAs = document.querySelector("#loggedInAs");
const signingModeSelect = document.querySelector("#signingMode");
const signingModeButton = document.querySelector("#signingModeButton");
const signingModeList = document.querySelector("#signingModeList");
const copySignerButton = document.querySelector("#copySigner");
const multisigSection = document.querySelector(".multisigSection");
const hyperliquidMultisigModeInput = document.querySelector("#hyperliquidMultisigMode");
const hyperliquidMultisigThresholdInput = document.querySelector("#hyperliquidMultisigThreshold");
const hyperliquidMultisigVaultSignerRow = document.querySelector("#hyperliquidMultisigVaultSignerRow");
const hyperliquidMultisigVaultSignerText = document.querySelector("#hyperliquidMultisigVaultSignerText");
const hyperliquidMultisigBrowserSignerInput = document.querySelector("#hyperliquidMultisigBrowserSigner");
const hyperliquidMultisigBrowserSignerText = document.querySelector("#hyperliquidMultisigBrowserSignerText");
const hyperliquidMultisigAuthoritySignerEnabledInput = document.querySelector("#hyperliquidMultisigAuthoritySignerEnabled");
const hyperliquidMultisigAuthoritySignerInput = document.querySelector("#hyperliquidMultisigAuthoritySigner");
const hyperliquidMultisigAuthoritySignerRow = document.querySelector("#hyperliquidMultisigAuthoritySignerRow");
const multisigStatus = document.querySelector("#multisigStatus");
const convertSingleButton = document.querySelector("#convertSingleSignature");
const multisigDetails = document.querySelector("#multisigDetails");
const autoApproveSafeRequestsInput = document.querySelector("#autoApproveSafeRequests");
const notifyDappsOnDefaultAccountChangeInput = document.querySelector("#notifyDappsOnDefaultAccountChange");
const verboseKeyVaultLogsInput = document.querySelector("#verboseKeyVaultLogs");
const extensionOrigin = document.querySelector("#extensionOrigin");
const walletConnectLabelRow = document.querySelector("#walletConnectLabelRow");
const walletConnectLabelInput = document.querySelector("#walletConnectLabel");
const connectWalletConnectButton = document.querySelector("#connectWalletConnect");
const walletConnectStatus = document.querySelector("#walletConnectStatus");
const toggleConnectionsButton = document.querySelector("#toggleConnections");
const connectionsPanel = document.querySelector("#connectionsPanel");
const dappConnections = document.querySelector("#dappConnections");
const backendConnections = document.querySelector("#backendConnections");
const statusText = document.querySelector("#status");
const refreshLogButton = document.querySelector("#refreshLog");
const copyLogButton = document.querySelector("#copyLog");
const clearLogButton = document.querySelector("#clearLog");
const debugLog = document.querySelector("#debugLog");
const extensionVersionLabels = document.querySelectorAll(".extensionVersion");
let walletConnectStatusInFlight = false;
let currentSignerAddress = "";
let currentSignerShowsHyperliquidMultisig = false;
let signerOptionsSignature = "";
let loadStateRun = 0;
let signerChangeInFlight = false;
let pendingLoadAfterSignerChange = false;
let backgroundPopupSyncStarted = false;
let logRefreshQueued = false;
let multisigStatusInFlight = false;

function closeSignerMenu() {
  signingModeList.classList.add("hidden");
  signingModeButton.setAttribute("aria-expanded", "false");
}

function toggleSignerMenu() {
  const isOpen = !signingModeList.classList.contains("hidden");
  signingModeList.classList.toggle("hidden", isOpen);
  signingModeButton.setAttribute("aria-expanded", isOpen ? "false" : "true");
}

function renderSignerMenuOptions(options, selectedValue) {
  const selectedOption = options.find((option) => option.value === selectedValue) ||
    options.find((option) => !option.disabled) ||
    options[0] ||
    null;
  signingModeButton.textContent = selectedOption ? selectedOption.label : "No address available";
  signingModeButton.disabled = !options.some((option) => !option.disabled);
  signingModeList.innerHTML = "";
  for (const option of options) {
    const element = document.createElement("button");
    element.type = "button";
    element.className = "signerMenuOption";
    element.textContent = option.label;
    element.disabled = option.disabled;
    element.dataset.value = option.value;
    element.setAttribute("role", "option");
    element.setAttribute("aria-selected", option.value === selectedValue ? "true" : "false");
    element.classList.toggle("isSelected", option.value === selectedValue);
    if (!option.disabled) {
      element.addEventListener("click", async () => {
        signingModeSelect.value = option.value;
        signingModeButton.textContent = option.label;
        for (const nextElement of signingModeList.querySelectorAll(".signerMenuOption")) {
          const isSelected = nextElement.dataset.value === option.value;
          nextElement.classList.toggle("isSelected", isSelected);
          nextElement.setAttribute("aria-selected", isSelected ? "true" : "false");
        }
        closeSignerMenu();
        await changeSigner();
      });
    }
    signingModeList.appendChild(element);
  }
}

function setAuthStatus(message, type = "info") {
  authStatus.textContent = message || "";
  authStatus.classList.toggle("isError", type === "error");
}

function renderExtensionVersion() {
  const version = chrome.runtime.getManifest().version || "unknown";
  for (const label of extensionVersionLabels) {
    label.textContent = version;
  }
}

function setStatus(message, type = "info") {
  statusText.textContent = message || "";
  statusText.classList.toggle("isError", type === "error");
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function isPassliAuthTabUrl(url) {
  try {
    return PASSLI_AUTH_ORIGINS.has(new URL(url || "").origin);
  } catch {
    return false;
  }
}

async function requestPassliAuthStatusFromOpenTabs() {
  const tabs = await chrome.tabs.query({});
  const authTabs = tabs.filter((tab) => tab.id !== undefined && isPassliAuthTabUrl(tab.url));
  if (!authTabs.length) return false;
  const requestId = crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`;
  await Promise.all(authTabs.map((tab) => chrome.tabs.sendMessage(tab.id, {
    type: "PASSLI_EXTENSION_REQUEST_AUTH_STATUS",
    requestId
  }).catch(() => null)));
  await sleep(250);
  return true;
}

async function loadPassliServerSession() {
  // Session metadata comes from an open Passli tab, never a public global
  // server session. This local mirror is display state, not signing authority.
  await requestPassliAuthStatusFromOpenTabs();

  const local = await chrome.storage.local.get({
    passliExtensionAccountId: "",
    passliExtensionAlias: ""
  });
  const localSession = local.passliExtensionAlias && local.passliExtensionAccountId
    ? { accountId: local.passliExtensionAccountId, alias: local.passliExtensionAlias }
    : null;
  if (localSession) {
    loggedInAs.textContent = localSession.alias;
    return localSession;
  }

  loggedInAs.textContent = "Not attached";
  return null;
}

async function passliApiGet(path) {
  const response = await fetch(new URL(path, PASSLI_API_URL).toString(), {
    headers: { Accept: "application/json" }
  });
  const text = await response.text();
  let payload = {};
  if (text) {
    try {
      payload = JSON.parse(text);
    } catch {
      payload = {};
    }
  }
  if (!response.ok) {
    throw new Error(payload.error || `Passli request failed: ${response.status}`);
  }
  return payload;
}

async function passliApiPost(path, body = {}, options = {}) {
  const controller = options.timeoutMs ? new AbortController() : null;
  const timeoutId = controller && options.timeoutMs
    ? setTimeout(() => controller.abort(), options.timeoutMs)
    : 0;
  try {
    const response = await fetch(new URL(path, PASSLI_API_URL).toString(), {
      body: JSON.stringify(body),
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json"
      },
      method: "POST",
      signal: controller?.signal
    });
    const text = await response.text();
    let payload = {};
    if (text) {
      try {
        payload = JSON.parse(text);
      } catch {
        payload = {};
      }
    }
    if (!response.ok) {
      throw new Error(payload.error || `Passli request failed: ${response.status}`);
    }
    return payload;
  } catch (error) {
    if (controller?.signal.aborted) {
      throw new Error(`Request timed out after ${Math.round((options.timeoutMs || 0) / 1000)} seconds.`);
    }
    throw error;
  } finally {
    if (timeoutId) clearTimeout(timeoutId);
  }
}

async function clearExtensionSessionCache(authOrigin = "") {
  await chrome.storage.local.set({
    passliExtensionLoggedIn: false,
    passliExtensionAccountId: "",
    passliExtensionAlias: "",
    passliExtensionCredentialId: "",
    passliExtensionLoginAt: "",
    passliExtensionAuthOrigin: authOrigin,
    passliExtensionLoginRequestId: "",
    passliExtensionLoginRequestCreatedAt: ""
  });
}

function selectedWalletFromSession(session) {
  if (session.selectedWallet && session.selectedWallet.address) {
    return {
      accountId: String(session.selectedWallet.accountId || session.accountId),
      address: String(session.selectedWallet.address),
      chainId: String(session.selectedWallet.chainId || DEFAULT_CHAIN_ID),
      label: String(session.selectedWallet.label || `${session.alias || "Passli"} Default`),
      type: "passli-account",
      walletId: session.selectedWallet.walletId || 1,
      walletName: session.selectedWallet.walletName || "Default"
    };
  }
  const wallet = Array.isArray(session.wallets)
    ? session.wallets.find((nextWallet) => Number(nextWallet.walletId) === 1) || session.wallets[0]
    : null;
  if (!wallet || !wallet.address) return null;
  return {
    accountId: String(session.accountId),
    address: String(wallet.address),
    chainId: String(wallet.chainId || DEFAULT_CHAIN_ID),
    label: `${session.alias || "Passli"} ${wallet.name || "Default"}`,
    type: "passli-account",
    walletId: wallet.walletId || 1,
    walletName: wallet.name || "Default"
  };
}

async function attachExtensionSession(session, authOrigin = PASSLI_AUTH_URL) {
  if (!session || !session.alias || !session.accountId) return false;
  const patch = {
    passliExtensionLoggedIn: true,
    passliExtensionAccountId: String(session.accountId),
    passliExtensionAlias: String(session.alias),
    passliExtensionCredentialId: String(session.credentialId || ""),
    passliExtensionDeviceId: String(session.deviceId || ""),
    passliExtensionLoginAt: new Date().toISOString(),
    passliExtensionAuthOrigin: authOrigin,
    passliExtensionLoginRequestId: "",
    passliExtensionLoginRequestCreatedAt: ""
  };
  const selectedWallet = selectedWalletFromSession(session);
  if (selectedWallet) patch.passliSelectedWallet = selectedWallet;
  await chrome.storage.local.set(patch);
  await refreshVaultCryptoAddresses(session).catch(() => {});
  return true;
}

async function refreshVaultCryptoAddresses(session) {
  if (!session || !session.accountId) return [];
  const response = await walletConnectDebug("refreshVaultCryptoAddresses");
  if (response?.error) throw new Error(response.error.message || "Could not sync vault addresses.");
  const addresses = normalizePassliCryptoAddresses(response?.result, session.accountId);
  const stored = await chrome.storage.local.get({
    selectedPassliAddressId: "",
    passliExtensionAccountId: "",
    passliExtensionCloudSignerAddress: "",
    passliExtensionHlMultisigSignerAddress: "",
    passliSelectedWallet: null,
    passliCryptoAddressLastUsedAt: {}
  });
  const selectionState = passliSelectionStateForSync(stored, addresses, session);
  const selectableAddresses = passliCryptoAddressesForState(selectionState);
  const selected = selectedSyncedPassliAddress(selectableAddresses, stored);
  await chrome.storage.local.set({
    passliCryptoAddresses: addresses,
    selectedPassliAddressId: selected ? selected.id : "",
    passliSelectedWallet: selected
      ? {
        accountId: session.accountId,
        address: selected.address,
        chainId: selected.chainId,
        label: passliAddressOptionLabel(selected),
        signerType: "local",
        type: "passli-vault-address",
        walletId: 1,
        walletName: selected.chainName || "Vault address"
      }
      : null
  });
  return addresses;
}

function needsDemoMigration(state) {
  return (
    !state.privateKey ||
    state.address === "0x0000000000000000000000000000000000000abc" ||
    state.chainId === "0x3e9"
  );
}

function shortAddress(address) {
  const value = String(address || "");
  return value.length > 12 ? `${value.slice(0, 6)}...${value.slice(-4)}` : value;
}

function labelHyperliquidMultisigSigner(address, status, stored) {
  const value = String(address || "").toLowerCase();
  if (!value) return "";
  if (value === String(stored.passliExtensionCloudSignerAddress || "").toLowerCase()) return "vault";
  if (value === String(status.localSignerAddress || stored.passliExtensionHlMultisigSignerAddress || "").toLowerCase()) return "browser";
  return "recovery";
}

function hyperliquidMultisigSummary(status, stored) {
  const signers = Array.isArray(status.authorizedUsers) ? status.authorizedUsers : [];
  if (!signers.length) return "";
  const labels = signers
    .map((signer) => labelHyperliquidMultisigSigner(signer, status, stored))
    .filter(Boolean);
  const uniqueLabels = Array.from(new Set(labels));
  const signerText = `${signers.length} signer${signers.length === 1 ? "" : "s"} registered`;
  const labelText = uniqueLabels.length ? ` (${uniqueLabels.join(", ")})` : "";
  const threshold = Number(status.threshold || 0) || "unknown";
  return `${signerText}${labelText}. ${threshold} signature${threshold === 1 ? "" : "s"} required.`;
}

function passliAddressId(address) {
  if (!address || typeof address !== "object") return "";
  const chainId = String(address.chainId || "").trim();
  const value = String(address.address || "").trim();
  if (!chainId || !value) return "";
  return `${chainId}:${value}`.toLowerCase();
}

function normalizePassliCryptoAddress(address, fallbackAccountId = "") {
  if (!address || typeof address !== "object" || !address.address || !address.chainId) return null;
  const sourceChainId = String(address.chainId || "").trim();
  const sourceChainName = String(address.chainName || address.chain || "Chain").trim();
  const sourceRole = String(address.sourceRole || "");
  const isHyperliquid = sourceChainId.toLowerCase() === "hyperliquid:core:mainnet" ||
    sourceChainId.toLowerCase() === "0x3e7" ||
    /^hyperliquid\s+(core|evm)$/i.test(sourceChainName);
  const normalized = {
    accountId: String(address.accountId || fallbackAccountId || ""),
    address: String(address.address || "").trim(),
    chainId: isHyperliquid ? "0x3e7" : sourceChainId,
    chainName: sourceRole ? sourceChainName : isHyperliquid ? "Hyperliquid" : sourceChainName
  };
  return {
    ...address,
    ...normalized,
    hyperliquidMultisigEligible: address.hyperliquidMultisigEligible !== false,
    sourceRole,
    id: String(address.id || passliAddressId(normalized))
  };
}

function normalizePassliCryptoAddresses(addresses, fallbackAccountId = "") {
  const seen = new Set();
  const result = [];
  for (const address of Array.isArray(addresses) ? addresses : []) {
    const normalized = normalizePassliCryptoAddress(address, fallbackAccountId);
    if (!normalized || !normalized.id || seen.has(normalized.id)) continue;
    seen.add(normalized.id);
    result.push(normalized);
  }
  return result;
}

function passliSignerCryptoAddressesForState(state) {
  const accountId = state.passliExtensionAccountId || "";
  return normalizePassliCryptoAddresses([
    {
      accountId,
      address: state.passliExtensionCloudSignerAddress || state.passliSelectedWallet?.cloudSignerAddress || "",
      chainId: "0x3e7",
      chainName: "HyperLiq MS Vault Signer",
      hyperliquidMultisigEligible: false,
      sourceRole: "vault-signer"
    },
    {
      accountId,
      address: state.passliExtensionHlMultisigSignerAddress || state.passliSelectedWallet?.hlMultisigSignerAddress || "",
      chainId: "0x3e7",
      chainName: "HyperLiq MS User Signer",
      hyperliquidMultisigEligible: false,
      sourceRole: "user-signer"
    }
  ], accountId);
}

function passliCryptoAddressesForState(state) {
  return normalizePassliCryptoAddresses([
    ...normalizePassliCryptoAddresses(state.passliCryptoAddresses, state.passliExtensionAccountId),
    // Multisig signer addresses remain internal; only wallet addresses are selectable.
  ], state.passliExtensionAccountId);
}

function popupIsEvmProviderChainId(chainId) {
  return ["0x1", "0xa4b1", "0x2105", "0x3e7"].includes(String(chainId || "").toLowerCase());
}

function selectedSyncedPassliAddress(addresses, state, incomingSelectedId = "") {
  const normalizedAddresses = (Array.isArray(addresses) ? addresses : []).filter((address) => address.sourceRole !== "vault-signer" && address.sourceRole !== "user-signer");
  const currentSelectedId = String(state && state.selectedPassliAddressId || "");
  const incomingId = String(incomingSelectedId || "");
  const preferred = normalizedAddresses.find((address) => String(address.chainId || "") === "0x3e7") ||
    normalizedAddresses.find((address) => popupIsEvmProviderChainId(address.chainId)) ||
    normalizedAddresses[0] ||
    null;
  return normalizedAddresses.find((address) => address.id === currentSelectedId) ||
    normalizedAddresses.find((address) => address.id === incomingId) ||
    preferred;
}

function passliSelectionStateForSync(state, addresses, sessionOrAccountId = "") {
  const session = sessionOrAccountId && typeof sessionOrAccountId === "object"
    ? sessionOrAccountId
    : {};
  const accountId = String(session.accountId || sessionOrAccountId || state.passliExtensionAccountId || "");
  return {
    ...state,
    passliCryptoAddresses: addresses,
    passliExtensionAccountId: accountId,
    passliExtensionCloudSignerAddress: String(
      state.passliExtensionCloudSignerAddress ||
      session.cloudSignerAddress ||
      session.selectedWallet?.cloudSignerAddress ||
      ""
    ),
    passliExtensionHlMultisigSignerAddress: String(
      state.passliExtensionHlMultisigSignerAddress ||
      session.hlMultisigSignerAddress ||
      session.selectedWallet?.hlMultisigSignerAddress ||
      ""
    ),
    passliSelectedWallet: state.passliSelectedWallet || session.selectedWallet || null
  };
}

function passliAddressOptionValue(address) {
  return `passliAddress:${encodeURIComponent(String(address?.id || passliAddressId(address) || ""))}`;
}

function passliAddressOptionLabel(address) {
  return `${address.chainName || "Chain"}: ${shortAddress(address.address)}`;
}

function passliAddressIsHyperliquid(address) {
  if (!address) return false;
  if (address.hyperliquidMultisigEligible === false) return false;
  const chainId = String(address.chainId || "").trim().toLowerCase();
  const chainName = String(address.chainName || address.chain || "").trim().toLowerCase();
  return chainId === "0x3e7" || chainName === "hyperliquid";
}

function setMultisigSectionVisible(isVisible) {
  currentSignerShowsHyperliquidMultisig = false; // Conversion controls are temporarily unavailable.
  multisigSection.classList.toggle("hidden", !currentSignerShowsHyperliquidMultisig);
}

function sortPassliAddressesByRecentUse(addresses, lastUsedAt = {}) {
  return [...addresses].sort((left, right) => {
    const leftTime = Date.parse(lastUsedAt[left.id] || "") || 0;
    const rightTime = Date.parse(lastUsedAt[right.id] || "") || 0;
    if (leftTime !== rightTime) return rightTime - leftTime;
    return String(left.chainName || "").localeCompare(String(right.chainName || ""));
  });
}

function walletMetadataName(wallet) {
  return wallet && wallet.name ? wallet.name.trim() : "";
}

function walletConnectDisplayName(state) {
  return walletMetadataName(state.walletConnectWallet) ||
    String(state.walletConnectLabel || "").trim() ||
    "WalletConnect";
}

function walletConnectAccountDisplayName(account, state) {
  return walletMetadataName(account && account.wallet) || walletConnectDisplayName(state);
}

function walletConnectOptionValue(account) {
  const topic = encodeURIComponent(String(account?.topic || ""));
  const address = String(account?.address || "").toLowerCase();
  return `walletconnect:${topic}:${address}`;
}

function externalAuthorityOptionValue(wallet) {
  return `externalAuthority:${encodeURIComponent(String(wallet?.id || ""))}`;
}

function parseSignerOption(value) {
  const raw = String(value || "");
  if (raw.startsWith("passliAddress:")) {
    return {
      signingMode: "local",
      selectedPassliAddressId: decodeURIComponent(raw.slice("passliAddress:".length)),
      externalAuthorityWalletId: "",
      walletConnectAddress: "",
      walletConnectTopic: ""
    };
  }
  if (raw.startsWith("externalAuthority:")) {
    return {
      signingMode: "externalAuthority",
      selectedPassliAddressId: "",
      externalAuthorityWalletId: decodeURIComponent(raw.slice("externalAuthority:".length)),
      walletConnectAddress: "",
      walletConnectTopic: ""
    };
  }
  if (raw.startsWith("walletconnect:")) {
    const rest = raw.slice("walletconnect:".length);
    const separatorIndex = rest.indexOf(":");
    const encodedTopic = separatorIndex >= 0 ? rest.slice(0, separatorIndex) : "";
    const address = separatorIndex >= 0 ? rest.slice(separatorIndex + 1) : rest;
    return {
      signingMode: "walletconnect",
      selectedPassliAddressId: "",
      walletConnectAddress: address,
      walletConnectTopic: encodedTopic ? decodeURIComponent(encodedTopic) : ""
    };
  }
  return { signingMode: "local", selectedPassliAddressId: "", externalAuthorityWalletId: "", walletConnectAddress: "", walletConnectTopic: "" };
}

function uniqueWalletConnectAccounts(accounts) {
  const seen = new Set();
  const result = [];
  for (const account of accounts || []) {
    if (!account || !account.address) continue;
    const key = `${String(account.topic || "").toLowerCase()}:${String(account.address).toLowerCase()}`;
    if (seen.has(key)) continue;
    seen.add(key);
    result.push(account);
  }
  return result;
}

function renderSignerOptions(state, walletConnectAccounts = [], walletConnectConnected = false) {
  const signingMode = state.signingMode === "walletconnect"
    ? "walletconnect"
    : state.signingMode === "externalAuthority"
      ? "externalAuthority"
      : "local";
  const selectedWalletConnectAddress = String(state.selectedWalletConnectAddress || state.walletConnectAccount?.address || "").toLowerCase();
  const selectedWalletConnectTopic = String(state.selectedWalletConnectTopic || state.walletConnectAccount?.topic || "");
  const selectedExternalAuthorityWalletId = String(state.selectedExternalAuthorityWalletId || "");
  const externalAuthorityWallets = Array.isArray(state.externalAuthorityWallets) ? state.externalAuthorityWallets : [];
  const passliLoggedIn = state.passliExtensionLoggedIn !== false;
  const syncedVaultAddresses = normalizePassliCryptoAddresses(state.passliCryptoAddresses, state.passliExtensionAccountId);
  const passliAddresses = sortPassliAddressesByRecentUse(
    passliCryptoAddressesForState(state),
    state.passliCryptoAddressLastUsedAt || {}
  );
  const selectedPassliAddress = selectedSyncedPassliAddress(passliAddresses, state);
  const passliWallet = state.passliSelectedWallet && state.passliSelectedWallet.address
    ? state.passliSelectedWallet
    : null;
  const localAddress = passliWallet && passliWallet.address ? passliWallet.address : "";
  const options = [];

  for (const address of passliAddresses) {
    options.push({
      value: passliAddressOptionValue(address),
      label: passliAddressOptionLabel(address),
      disabled: false
    });
  }

  if (!passliAddresses.length) {
    const localLabel = passliWallet
      ? `${passliWallet.label || state.passliExtensionAlias || "Passli default wallet"} (${shortAddress(localAddress)})`
      : passliLoggedIn
        ? "Unlock vault to show addresses"
        : "No Passli wallet selected";
    options.push({
      value: "local",
      label: localLabel,
      disabled: !localAddress
    });
  }

  for (const wallet of externalAuthorityWallets) {
    if (!wallet || !wallet.address) continue;
    options.push({
      value: externalAuthorityOptionValue(wallet),
      label: `${wallet.label || "External wallet"} (${shortAddress(wallet.address)})`,
      disabled: false
    });
  }

  const accounts = uniqueWalletConnectAccounts(walletConnectAccounts);
  if (walletConnectConnected && accounts.length) {
    for (const account of accounts) {
      options.push({
        value: walletConnectOptionValue(account),
        label: `${walletConnectAccountDisplayName(account, state)} (${shortAddress(account.address)})`,
        disabled: false
      });
    }
  } else if (signingMode === "walletconnect") {
    options.push({
      value: selectedWalletConnectAddress
        ? walletConnectOptionValue({ address: selectedWalletConnectAddress, topic: selectedWalletConnectTopic })
        : "walletconnect",
      label: "WalletConnect (not connected)",
      disabled: true
    });
  }

  if (passliLoggedIn && !syncedVaultAddresses.length && passliAddresses.length) {
    options.push({
      value: "vaultLockedMore",
      label: "Unlock vault to see more...",
      disabled: true
    });
  }

  const selectedValue = signingMode === "walletconnect" && selectedWalletConnectAddress
    ? walletConnectOptionValue({ address: selectedWalletConnectAddress, topic: selectedWalletConnectTopic })
    : signingMode === "externalAuthority" && selectedExternalAuthorityWalletId
      ? externalAuthorityOptionValue({ id: selectedExternalAuthorityWalletId })
      : selectedPassliAddress
        ? passliAddressOptionValue(selectedPassliAddress)
        : signingMode;
  const nextValue = options.some((option) => option.value === selectedValue)
    ? selectedValue
    : "local";
  const nextSignature = JSON.stringify({ options, value: nextValue });
  if (nextSignature !== signerOptionsSignature) {
    signerOptionsSignature = nextSignature;
  }
  signingModeSelect.value = nextValue;
  const selectedRenderedOption = options.find((option) => option.value === signingModeSelect.value);
  if (selectedRenderedOption?.disabled) {
    signingModeSelect.value = options.find((option) => !option.disabled)?.value || "local";
  }
  renderSignerMenuOptions(options, signingModeSelect.value);

  const parsed = parseSignerOption(signingModeSelect.value);
  if (parsed.signingMode === "externalAuthority") {
    const selectedWallet = externalAuthorityWallets.find((wallet) => String(wallet.id || "") === parsed.externalAuthorityWalletId);
    currentSignerAddress = selectedWallet?.address || "";
  } else if (parsed.signingMode === "walletconnect") {
    const selectedAccount = accounts.find((account) =>
      String(account.topic || "") === parsed.walletConnectTopic &&
      String(account.address || "").toLowerCase() === parsed.walletConnectAddress
    );
    currentSignerAddress = selectedAccount?.address || parsed.walletConnectAddress;
  } else {
    const selectedAddress = passliAddresses.find((address) => address.id === parsed.selectedPassliAddressId) || selectedPassliAddress;
    currentSignerAddress = selectedAddress?.address || localAddress;
    setMultisigSectionVisible(passliAddresses.some(passliAddressIsHyperliquid));
    return;
  }
  setMultisigSectionVisible(passliAddresses.some(passliAddressIsHyperliquid));
}

function multisigAuthoritySignerOptions(state, walletConnectAccounts = [], walletConnectConnected = false) {
  const options = [];
  const externalAuthorityWallets = Array.isArray(state.externalAuthorityWallets) ? state.externalAuthorityWallets : [];
  for (const wallet of externalAuthorityWallets) {
    if (!wallet || !wallet.address) continue;
    options.push({
      value: externalAuthorityOptionValue(wallet),
      label: `${wallet.label || "Connected wallet"} (${shortAddress(wallet.address)})`
    });
  }

  const accounts = uniqueWalletConnectAccounts(walletConnectAccounts);
  if (walletConnectConnected && accounts.length) {
    for (const account of accounts) {
      options.push({
        value: walletConnectOptionValue(account),
        label: `${walletConnectAccountDisplayName(account, state)} (${shortAddress(account.address)})`
      });
    }
  }
  return options;
}

function renderMultisigSignerOptions(state, walletConnectAccounts = [], walletConnectConnected = false) {
  const options = multisigAuthoritySignerOptions(state, walletConnectAccounts, walletConnectConnected);
  const vaultSignerAddress = String(state.passliExtensionCloudSignerAddress || "").trim();
  const userSignerAddress = String(state.passliExtensionHlMultisigSignerAddress || "").trim();
  hyperliquidMultisigVaultSignerRow.classList.toggle("hidden", !vaultSignerAddress);
  hyperliquidMultisigVaultSignerText.textContent = vaultSignerAddress
    ? `Always included: ${shortAddress(vaultSignerAddress)}`
    : "Always included for Passli-managed multisig.";
  hyperliquidMultisigBrowserSignerText.textContent = userSignerAddress
    ? `This browser can co-sign threshold-2 actions: ${shortAddress(userSignerAddress)}`
    : "This browser can co-sign threshold-2 Hyperliquid actions.";
  hyperliquidMultisigBrowserSignerInput.checked = state.hyperliquidMultisigIncludeBrowserSigner !== false;
  hyperliquidMultisigAuthoritySignerEnabledInput.checked = state.hyperliquidMultisigIncludeAuthoritySigner === true && options.length > 0;
  hyperliquidMultisigAuthoritySignerRow.classList.toggle("hidden", !options.length);
  hyperliquidMultisigAuthoritySignerInput.innerHTML = "";

  const selectedValue = options.some((option) => option.value === state.hyperliquidMultisigAuthoritySigner)
    ? state.hyperliquidMultisigAuthoritySigner
    : options[0]?.value || "";
  for (const option of options) {
    const element = document.createElement("option");
    element.value = option.value;
    element.textContent = option.label;
    hyperliquidMultisigAuthoritySignerInput.appendChild(element);
  }
  hyperliquidMultisigAuthoritySignerInput.value = selectedValue;
  hyperliquidMultisigAuthoritySignerInput.disabled = !hyperliquidMultisigAuthoritySignerEnabledInput.checked || !options.length;
}

async function loadState() {
  const run = ++loadStateRun;
  let state = await chrome.storage.local.get({
    privateKey: DEFAULT_PRIVATE_KEY,
    address: DEFAULT_ADDRESS,
    chainId: DEFAULT_CHAIN_ID,
    hyperliquidChain: DEFAULT_HYPERLIQUID_CHAIN,
    signatureChainId: DEFAULT_SIGNATURE_CHAIN_ID,
    signingMode: "local",
    walletConnectProjectId: "",
    walletConnectUri: "",
    walletConnectAccount: null,
    walletConnectWallet: null,
    walletConnectLabel: "",
    selectedWalletConnectAddress: "",
    selectedWalletConnectTopic: "",
    externalAuthorityWallets: [],
    selectedExternalAuthorityWalletId: "",
    passliExtensionLoggedIn: true,
    passliExtensionAccountId: "",
    passliExtensionAlias: "",
    passliExtensionCloudSignerAddress: "",
    passliExtensionDeviceId: "",
    passliExtensionHlMultisigSignerAddress: "",
    passliCryptoAddresses: [],
    passliCryptoAddressLastUsedAt: {},
    passliSelectedWallet: null,
    selectedPassliAddressId: "",
    autoApproveSafeRequests: true,
    offerAllConnectedWalletsToDapps: false,
    notifyDappsOnDefaultAccountChange: false,
    passliVerboseKeyVaultLogs: false,
    hyperliquidMultisigThreshold: 1,
    hyperliquidMultisigIncludeBrowserSigner: true,
    hyperliquidMultisigIncludeAuthoritySigner: false,
    hyperliquidMultisigAuthoritySigner: ""
  });
  if (run !== loadStateRun) return;

  if (!state.passliExtensionLoggedIn) {
    void globalThis.PassliPopupProfiles.load({accountId:'',deviceId:''});
    renderAuthState(false);
    setAuthStatus("Open passli.app to sign in and sync the extension wallet.");
    scheduleBackgroundPopupSync(run);
    return;
  }

  renderAuthState(true);
  void globalThis.PassliPopupProfiles.load({accountId:state.passliExtensionAccountId,deviceId:state.passliExtensionDeviceId});
  loggedInAs.textContent = state.passliExtensionAlias
    ? state.passliExtensionAlias
    : "Not attached";
  autoApproveSafeRequestsInput.checked = state.autoApproveSafeRequests !== false;
  notifyDappsOnDefaultAccountChangeInput.checked = state.notifyDappsOnDefaultAccountChange === true;
  verboseKeyVaultLogsInput.checked = state.passliVerboseKeyVaultLogs === true;
  hyperliquidMultisigThresholdInput.value = Number(state.hyperliquidMultisigThreshold || 1) === 2 ? "2" : "1";
  renderSignerOptions(state, state.walletConnectAccount ? [state.walletConnectAccount] : [], state.signingMode === "walletconnect");
  renderMultisigSignerOptions(state, state.walletConnectAccount ? [state.walletConnectAccount] : [], state.signingMode === "walletconnect");
  if (currentSignerShowsHyperliquidMultisig) {
    renderMultisigStatus(state);
  }
  extensionOrigin.textContent = "WalletConnect pairing origin: https://passli.app";
  const externalAuthorityWallets = Array.isArray(state.externalAuthorityWallets) ? state.externalAuthorityWallets : [];
  walletConnectStatus.textContent = externalAuthorityWallets.length
    ? `${externalAuthorityWallets.length} passli.app authority wallet${externalAuthorityWallets.length === 1 ? "" : "s"} synced.`
    : "Connect Tangem from passli.app so WalletConnect verifies the Passli domain.";
  connectWalletConnectButton.disabled = false;
  scheduleBackgroundPopupSync(run);
}

function scheduleBackgroundPopupSync(run) {
  if (backgroundPopupSyncStarted) return;
  backgroundPopupSyncStarted = true;
  setTimeout(() => {
    backgroundPopupSync(run).catch((error) => {
      setStatus(error && error.message ? error.message : "Could not refresh extension state.", "error");
    });
  }, 0);
}

async function backgroundPopupSync(run) {
  await requestPassliAuthStatusFromOpenTabs().catch(() => false);
  if (run !== loadStateRun) return;
  const config = await getExtensionConfig();
  if (run !== loadStateRun) return;
  const configuredDemoAddress = config.demoAccountAddress || config.demoAccountPublicKey || DEFAULT_ADDRESS;
  const configuredDemoPrivateKey = config.demoAccountPrivateKey || DEFAULT_PRIVATE_KEY;
  const state = await chrome.storage.local.get({
    privateKey: configuredDemoPrivateKey,
    address: configuredDemoAddress,
    chainId: DEFAULT_CHAIN_ID,
    passliCryptoAddresses: []
  });
  if (needsDemoMigration(state)) {
    await chrome.storage.local.set({
      privateKey: configuredDemoPrivateKey,
      address: configuredDemoAddress,
      chainId: DEFAULT_CHAIN_ID
    });
  }
  if (run !== loadStateRun) return;
  const session = await loadPassliServerSession();
  if (run !== loadStateRun) return;
  if (!session) {
    await chrome.storage.local.set({
      passliExtensionLoggedIn: false,
      passliExtensionAccountId: "",
      passliExtensionAlias: "",
      passliExtensionLoginAt: "",
      passliExtensionAuthOrigin: ""
    });
    if (run === loadStateRun) loadState();
    return;
  }
  if (!state.passliCryptoAddresses.length) {
    await refreshVaultCryptoAddresses(session).catch((error) => {
      setStatus(error && error.message ? error.message : "Could not sync vault addresses.", "error");
    });
  }
  if (run !== loadStateRun) return;
  await renderWalletConnectStatus();
}

function renderAuthState(isLoggedIn) {
  authView.classList.toggle("hidden", isLoggedIn);
  walletView.classList.toggle("hidden", !isLoggedIn);
  if (!isLoggedIn) {
    setAuthStatus("");
  }
}

async function openPassliAuthorityWallets() {
  await openPassliAuth("/", {
    authorityWallets: "1",
    extensionId: chrome.runtime.id
  });
}

async function openPassliAuth(path, params = {}) {
  const url = new URL(path, PASSLI_AUTH_URL);
  for (const [key, value] of Object.entries(params)) {
    if (value !== undefined && value !== null && value !== "") {
      url.searchParams.set(key, String(value));
    }
  }
  const stored = await chrome.storage.local.get({ passliAuthTabId: 0 });
  let tab = null;
  if (stored.passliAuthTabId) {
    try {
      const candidate = await chrome.tabs.get(stored.passliAuthTabId);
      if (candidate && candidate.id !== undefined && new URL(candidate.url || PASSLI_AUTH_URL).origin === PASSLI_AUTH_URL) {
        tab = candidate;
      }
    } catch {
      tab = null;
    }
  }

  if (!tab) {
    const tabs = await chrome.tabs.query({});
    tab = tabs.find((candidate) => {
      try {
        return candidate.id !== undefined && new URL(candidate.url || "").origin === PASSLI_AUTH_URL;
      } catch {
        return false;
      }
    }) || null;
  }

  if (tab && tab.id !== undefined) {
    const updated = await chrome.tabs.update(tab.id, { active: true, url: url.toString() });
    if (updated && updated.windowId !== undefined) {
      await chrome.windows.update(updated.windowId, { focused: true }).catch(() => {});
    }
    await chrome.storage.local.set({ passliAuthTabId: tab.id });
    return;
  }

  const created = await chrome.tabs.create({ active: true, url: url.toString() });
  if (created && created.id !== undefined) {
    await chrome.storage.local.set({ passliAuthTabId: created.id });
  }
}

async function loginPassli() {
  setAuthStatus("Opening passli.app...");
  try {
    await chrome.storage.local.set({
      passliExtensionLoginRequestId: "",
      passliExtensionLoginRequestCreatedAt: ""
    });
    await openPassliAuth("/");
    setAuthStatus("Sign in on passli.app, then reopen this extension.");
  } catch (error) {
    setAuthStatus(error && error.message ? error.message : "Could not open passli.app.", "error");
  }
}

async function logoutPassli() {
  logoutPassliButton.disabled = true;
  setStatus("Logging out of Passli...");
  try {
    await clearExtensionSessionCache("");
    renderAuthState(false);
    setAuthStatus("Logged out of the extension. passli.app is clearing its session too.");
    setStatus("Logged out of Passli.");

    passliApiPost("/api/logout", {}, { timeoutMs: 3000 }).catch(() => {
      setAuthStatus("Logged out locally, but the API logout did not return within 3 seconds. Please try again if passli.app still shows a server session.", "error");
    });
    openPassliAuth("/", {
      extensionLogout: "1",
      extensionId: chrome.runtime.id
    }).catch((error) => {
      setAuthStatus(
        error && error.message
          ? `Logged out of the extension. Open passli.app to finish web logout: ${error.message}`
          : "Logged out of the extension. Open passli.app to finish web logout.",
        "error"
      );
    });
  } catch (error) {
    setStatus(error && error.message ? error.message : "Could not log out.", "error");
  } finally {
    logoutPassliButton.disabled = false;
  }
}

async function walletConnectDebug(action, extra = {}) {
  return chrome.runtime.sendMessage({
    type: "HYPERLIQUID_DEMO_DEBUG",
    action,
    ...extra
  });
}

async function getExtensionConfig() {
  const response = await walletConnectDebug("getConfig");
  if (response && response.result) {
    return response.result;
  }
  return { walletConnectProjectId: "" };
}

async function renderWalletConnectStatus(state = null) {
  if (walletConnectStatusInFlight) return;
  walletConnectStatusInFlight = true;

  try {
    const config = await getExtensionConfig();
    const stored = state || await chrome.storage.local.get({
      signingMode: "local",
      walletConnectProjectId: "",
      walletConnectUri: "",
      walletConnectAccount: null,
      walletConnectWallet: null,
      walletConnectLabel: "",
      selectedWalletConnectAddress: "",
      selectedWalletConnectTopic: "",
      externalAuthorityWallets: [],
      hyperliquidMultisigIncludeBrowserSigner: true,
      hyperliquidMultisigIncludeAuthoritySigner: false,
      hyperliquidMultisigAuthoritySigner: ""
    });
    stored.walletConnectProjectId = config.walletConnectProjectId || stored.walletConnectProjectId || "";

    let status = null;
    if (stored.walletConnectProjectId) {
      const response = await walletConnectDebug("walletConnectStatus");
      status = response && response.result ? response.result : null;
    }

    const accounts = status && Array.isArray(status.accounts) && status.accounts.length
      ? status.accounts
      : stored.walletConnectAccount
        ? [stored.walletConnectAccount]
        : [];
    const account = status && status.account ? status.account : stored.walletConnectAccount;
    stored.walletConnectWallet = status && status.wallet ? status.wallet : stored.walletConnectWallet;
    stored.selectedWalletConnectAddress = stored.selectedWalletConnectAddress || account?.address || "";
    stored.selectedWalletConnectTopic = stored.selectedWalletConnectTopic || account?.topic || "";
    renderMultisigSignerOptions(stored, accounts, Boolean(status && status.connected && account));
    updateWalletConnectLabelField(stored, Boolean(status && status.connected && account));
    if (status && status.connected && account) {
      walletConnectStatus.textContent = `Legacy extension WalletConnect connected: ${walletConnectDisplayName(stored)} ${account.address} (${account.chainId}). Prefer reconnecting from passli.app.`;
      connectWalletConnectButton.disabled = false;
      await chrome.storage.local.set({
        walletConnectUri: "",
        walletConnectAccount: account,
        walletConnectWallet: stored.walletConnectWallet || null,
        selectedWalletConnectAddress: account.address || "",
        selectedWalletConnectTopic: account.topic || ""
      });
    } else if (stored.walletConnectUri) {
      walletConnectStatus.textContent = "Legacy extension WalletConnect pairing is pending. Open passli.app to replace it.";
      connectWalletConnectButton.disabled = false;
    } else {
      const externalAuthorityWallets = Array.isArray(stored.externalAuthorityWallets) ? stored.externalAuthorityWallets : [];
      walletConnectStatus.textContent = externalAuthorityWallets.length
        ? `${externalAuthorityWallets.length} passli.app authority wallet${externalAuthorityWallets.length === 1 ? "" : "s"} synced.`
        : "Connect Tangem from passli.app so WalletConnect verifies the Passli domain.";
      connectWalletConnectButton.disabled = false;
    }

  } finally {
    walletConnectStatusInFlight = false;
  }
}

async function connectWalletConnect() {
  setStatus("Opening passli.app authority wallets...");
  try {
    await openPassliAuthorityWallets();
    setStatus("Connect Tangem from passli.app, then return here after it syncs.");
  } catch (error) {
    setStatus(error && error.message ? error.message : "Could not open passli.app.", "error");
  }
}

async function disconnectWalletConnect() {
  setStatus("Disconnecting WalletConnect...");
  const response = await walletConnectDebug("walletConnectDisconnect");
  if (response && response.error) {
    setStatus(response.error.message, "error");
    return;
  }
  await chrome.storage.local.set({
    signingMode: "local",
    walletConnectUri: "",
    walletConnectAccount: null,
    walletConnectWallet: null,
    walletConnectLabel: "",
    selectedWalletConnectAddress: "",
    selectedWalletConnectTopic: ""
  });
  await renderWalletConnectStatus();
  await renderConnectionsIfOpen();
  setStatus("WalletConnect disconnected.");
}

async function copySignerAddress() {
  if (!currentSignerAddress) {
    setStatus("No Passli wallet address is synced yet.", "error");
    return;
  }
  try {
    await navigator.clipboard.writeText(currentSignerAddress);
    setStatus("Signer address copied.");
  } catch (error) {
    setStatus(error && error.message ? error.message : "Could not copy signer address.", "error");
  }
}

async function promptForWalletConnectLabelIfNeeded(result) {
  if (!result || !result.account || walletMetadataName(result.wallet)) return;
  const current = walletConnectLabelInput.value.trim();
  const label = window.prompt("Name this WalletConnect wallet", current || "Hardware wallet");
  if (label && label.trim()) {
    await chrome.storage.local.set({ walletConnectLabel: label.trim() });
  }
}

function updateWalletConnectLabelField(state, connected) {
  const hasMetadataName = Boolean(walletMetadataName(state.walletConnectWallet));
  walletConnectLabelRow.classList.toggle("hidden", !connected || hasMetadataName);
  walletConnectLabelInput.value = state.walletConnectLabel || "";
}

async function saveWalletConnectLabel() {
  await chrome.storage.local.set({
    walletConnectLabel: walletConnectLabelInput.value.trim()
  });
  await renderWalletConnectStatus();
}

async function changeAutoApproveSafeRequests() {
  await chrome.storage.local.set({
    autoApproveSafeRequests: autoApproveSafeRequestsInput.checked
  });
  setStatus(autoApproveSafeRequestsInput.checked
    ? "Safe dApp reads will be answered automatically."
    : "Safe dApp reads will ask for approval.");
}

async function changeNotifyDappsOnDefaultAccountChange() {
  await chrome.storage.local.set({
    notifyDappsOnDefaultAccountChange: notifyDappsOnDefaultAccountChangeInput.checked
  });
  setStatus(notifyDappsOnDefaultAccountChangeInput.checked
    ? "Connected dApps will be notified when the address changes."
    : "Address changes will stay local until dApps reconnect.");
}

async function changeVerboseKeyVaultLogs() {
  await chrome.storage.local.set({
    passliVerboseKeyVaultLogs: verboseKeyVaultLogsInput.checked
  });
  setStatus(verboseKeyVaultLogsInput.checked
    ? "Verbose key vault provisioning logs are enabled."
    : "Verbose key vault provisioning logs are disabled.");
}

function clearElement(element) {
  while (element.firstChild) {
    element.firstChild.remove();
  }
}

function emptyConnection(message) {
  const empty = document.createElement("div");
  empty.className = "connectionEmpty";
  empty.textContent = message;
  return empty;
}

function createConnectionRow({ title, meta, actionLabel, action }) {
  const row = document.createElement("div");
  row.className = "connectionRow";

  const content = document.createElement("div");
  const titleElement = document.createElement("div");
  titleElement.className = "connectionTitle";
  titleElement.textContent = title;
  content.appendChild(titleElement);

  if (meta) {
    const metaElement = document.createElement("div");
    metaElement.className = "connectionMeta";
    metaElement.textContent = meta;
    content.appendChild(metaElement);
  }

  const button = document.createElement("button");
  button.type = "button";
  button.textContent = actionLabel;
  button.addEventListener("click", action);

  row.append(content, button);
  return row;
}

async function getConnections() {
  const response = await walletConnectDebug("getConnections");
  if (response && response.error) {
    throw new Error(response.error.message || "Could not load connections.");
  }
  return response && response.result ? response.result : { dapps: [], walletConnect: null };
}

async function renderConnections() {
  clearElement(dappConnections);
  clearElement(backendConnections);

  let connections;
  try {
    connections = await getConnections();
  } catch (error) {
    dappConnections.appendChild(emptyConnection(error.message));
    backendConnections.appendChild(emptyConnection(error.message));
    return;
  }

  const dapps = Array.isArray(connections.dapps) ? connections.dapps : [];
  const activeAddress = connections.activeAccount && connections.activeAccount.address
    ? connections.activeAccount.address
    : "";
  if (dapps.length) {
    for (const connection of dapps) {
      const origin = typeof connection === "string" ? connection : connection.origin;
      const connectionKey = typeof connection === "string" ? "" : connection.key;
      const tabLabel = connection && Number.isInteger(connection.tabId)
        ? `Tab ${connection.tabId}. `
        : "";
      const trustLabel = connection && connection.trusted
        ? "Trusted site. Will reconnect without approval."
        : "Connected now.";
      dappConnections.appendChild(createConnectionRow({
        title: origin,
        meta: `${tabLabel}${trustLabel} Can read ${shortAddress(activeAddress)} after connecting.`,
        actionLabel: "Delete",
        action: () => revokeDappConnection(origin, connectionKey)
      }));
    }
  } else {
    dappConnections.appendChild(emptyConnection(
      activeAddress
        ? `No dApps are connected to ${shortAddress(activeAddress)}.`
        : "No dApps are connected to the selected wallet."
    ));
  }

  const walletConnect = connections.walletConnect || {};
  if (connections.signerType !== "walletconnect") {
    backendConnections.appendChild(emptyConnection("Shown only when Address is a WalletConnect account."));
  } else if (walletConnect.connected && Array.isArray(walletConnect.accounts) && walletConnect.accounts.length) {
    for (const account of uniqueWalletConnectAccounts(walletConnect.accounts)) {
      const state = {
        walletConnectWallet: account.wallet || walletConnect.wallet || null,
        walletConnectLabel: walletConnect.label || ""
      };
      backendConnections.appendChild(createConnectionRow({
        title: walletConnectAccountDisplayName(account, state),
        meta: `${account.address} (${account.chainId || "unknown chain"})`,
        actionLabel: "Delete",
        action: disconnectWalletConnect
      }));
    }
  } else if (walletConnect.uri) {
    backendConnections.appendChild(createConnectionRow({
      title: "WalletConnect pending",
      meta: "A pairing URI is waiting for approval.",
      actionLabel: "Delete",
      action: disconnectWalletConnect
    }));
  } else {
    backendConnections.appendChild(emptyConnection("No backend wallets are connected."));
  }

  if (walletConnect.error) {
    backendConnections.appendChild(emptyConnection(`WalletConnect status error: ${walletConnect.error}`));
  }
}

async function renderConnectionsIfOpen() {
  if (!connectionsPanel.classList.contains("hidden")) {
    await renderConnections();
  }
}

async function toggleConnections() {
  const isHidden = connectionsPanel.classList.toggle("hidden");
  toggleConnectionsButton.textContent = isHidden ? "Manage Connections" : "Hide Connections";
  if (!isHidden) {
    await renderConnections();
  }
}

async function revokeDappConnection(origin, connectionKey = "") {
  const response = await walletConnectDebug("revokeDappConnection", { origin, connectionKey });
  if (response && response.error) {
    setStatus(response.error.message || "Could not delete connection.", "error");
    return;
  }
  setStatus(`Deleted dApp connection for ${origin}.`);
  await renderConnections();
}

function formatLogEntry(entry) {
  const time = new Date(entry.time).toLocaleTimeString();
  const label = logLabel(entry);
  const lines = [
    `[${time}] ${label}${entry.method ? ` ${entry.method}` : ""}`,
    `origin: ${entry.origin || "extension"}`
  ];

  if (entry.durationMs !== undefined) lines.push(`duration: ${entry.durationMs}ms`);
  if (entry.count !== undefined && Number(entry.count) > 1) lines.push(`repeated: ${entry.count} times`);
  if (entry.params !== undefined) lines.push(`params: ${JSON.stringify(entry.params, null, 2)}`);
  if (entry.result !== undefined) lines.push(`result: ${JSON.stringify(entry.result, null, 2)}`);
  if (entry.error !== undefined) lines.push(`error: ${JSON.stringify(entry.error, null, 2)}`);

  return lines.join("\n");
}

function logLabel(entry) {
  if (entry.phase?.startsWith("passkey:")) return `Passkey ${entry.phase.slice(8).replace(/-/g, " ")}:`;
  if (entry.phase === "request") return "Got:";
  if (entry.phase === "response") return "Sent:";
  if (entry.phase === "error" || entry.phase === "throw") return "Sent error:";
  if (entry.phase === "message:incoming") return "Incoming:";
  if (entry.phase === "message:reply") return "Outgoing:";
  if (entry.phase === "message:reply-error") return "Outgoing error:";
  if (entry.phase === "timeout" || entry.phase === "approval:timeout") return "Our timeout:";
  return `${entry.phase || "log"}:`;
}

async function requestDebug(action) {
  return chrome.runtime.sendMessage({
    type: "HYPERLIQUID_DEMO_DEBUG",
    action
  });
}

async function loadLog() {
  const response = await requestDebug("getLog");
  const entries = response && response.result ? response.result : [];
  debugLog.textContent = entries.length
    ? entries.map(formatLogEntry).join("\n\n")
    : "No requests yet.";
  debugLog.scrollTop = debugLog.scrollHeight;
}

async function renderMultisigStatus(state = null) {
  if (multisigStatusInFlight) return;
  multisigStatusInFlight = true;
  try {
    const stored = state || await chrome.storage.local.get({
      passliExtensionCloudSignerAddress: "",
      passliExtensionHlMultisigSignerAddress: "",
      hyperliquidMultisigThreshold: 1,
      hyperliquidMultisigIncludeBrowserSigner: true,
      hyperliquidMultisigIncludeAuthoritySigner: false,
      hyperliquidMultisigAuthoritySigner: "",
      selectedPassliAddressId: "",
      passliCryptoAddresses: []
    });
    convertSingleButton.disabled = true;
    hyperliquidMultisigModeInput.disabled = true;
    multisigStatus.textContent = "Checking Hyperliquid account mode...";
    multisigDetails.textContent = "";
    const response = await walletConnectDebug("hyperliquidMultisigStatus");
    if (response && response.error) {
      hyperliquidMultisigModeInput.checked = false;
      multisigStatus.textContent = response.error.message || "Could not check Hyperliquid multisig mode.";
      multisigDetails.textContent = "The account can still connect as a normal Hyperliquid EVM provider.";
      return;
    }
    const status = response && response.result ? response.result : {};
    const isMulti = status.mode === "multiSig";
    const accountPreflight = status.accountPreflight && typeof status.accountPreflight === "object" ? status.accountPreflight : null;
    const accountNeedsFunding = !isMulti && accountPreflight && accountPreflight.needsFunding;
    convertSingleButton.classList.toggle("hidden", !isMulti);
    convertSingleButton.disabled = !isMulti;
    hyperliquidMultisigModeInput.checked = isMulti;
    hyperliquidMultisigThresholdInput.value = Number(status.threshold || stored.hyperliquidMultisigThreshold || 1) === 2 ? "2" : "1";
    hyperliquidMultisigModeInput.disabled = Boolean(accountNeedsFunding);
    hyperliquidMultisigThresholdInput.disabled = Boolean(accountNeedsFunding);
    hyperliquidMultisigBrowserSignerInput.disabled = Boolean(accountNeedsFunding || isMulti);
    hyperliquidMultisigAuthoritySignerEnabledInput.disabled = Boolean(accountNeedsFunding || isMulti);
    hyperliquidMultisigAuthoritySignerInput.disabled = Boolean(
      accountNeedsFunding ||
      isMulti ||
      !hyperliquidMultisigAuthoritySignerEnabledInput.checked ||
      hyperliquidMultisigAuthoritySignerRow.classList.contains("hidden")
    );
    multisigStatus.textContent = accountNeedsFunding
      ? "Initialize this Hyperliquid account before enabling multisig."
      : isMulti
      ? "Hyperliquid multisig is enabled."
      : "Enable multisig to increase Hyperliquid security and recoverability.";
    const accountFundingDetail = accountNeedsFunding
      ? `Selected account ${shortAddress(status.account || "")} does not appear to exist on HyperCore yet. Deposit or receive a Core transfer to initialize it, then refresh.`
      : "";
    const multisigDetail = isMulti ? hyperliquidMultisigSummary(status, stored) : "";
    const defaultDetail = accountFundingDetail || multisigDetail || (isMulti
      ? "Passli can approve decoded Hyperliquid L1 actions, and recovery signers can protect access if Passli is unavailable."
      : "Passli will see decoded Hyperliquid L1 requests before approving them, while recovery signers help prevent lockout.");
    multisigDetails.textContent = `Wallet account: ${status.account || "unknown"}. ${defaultDetail}`;
  } catch (error) {
    hyperliquidMultisigModeInput.checked = false;
    hyperliquidMultisigModeInput.disabled = false;
    hyperliquidMultisigThresholdInput.disabled = false;
    hyperliquidMultisigBrowserSignerInput.disabled = false;
    hyperliquidMultisigAuthoritySignerEnabledInput.disabled = false;
    hyperliquidMultisigAuthoritySignerInput.disabled = !hyperliquidMultisigAuthoritySignerEnabledInput.checked;
    multisigStatus.textContent = error && error.message ? error.message : "Could not check Hyperliquid multisig mode.";
    multisigDetails.textContent = "";
  } finally {
    multisigStatusInFlight = false;
  }
}

async function changeHyperliquidMultisigMode() {
  const target = hyperliquidMultisigModeInput.checked ? "multi" : "single";
  const threshold = Number(hyperliquidMultisigThresholdInput.value || 1) === 2 ? 2 : 1;
  const includeBrowserSigner = hyperliquidMultisigBrowserSignerInput.checked;
  const includeAuthoritySigner = !hyperliquidMultisigAuthoritySignerRow.classList.contains("hidden") &&
    hyperliquidMultisigAuthoritySignerEnabledInput.checked;
  const authoritySigner = includeAuthoritySigner ? hyperliquidMultisigAuthoritySignerInput.value || "" : "";
  if (target === "multi" && threshold === 2 && !includeBrowserSigner && !includeAuthoritySigner) {
    hyperliquidMultisigModeInput.checked = false;
    setStatus("Threshold 2 requires Browser or a connected wallet as an additional signer.", "error");
    return;
  }
  convertSingleButton.disabled = true;
  hyperliquidMultisigModeInput.disabled = true;
  hyperliquidMultisigThresholdInput.disabled = true;
  hyperliquidMultisigBrowserSignerInput.disabled = true;
  hyperliquidMultisigAuthoritySignerEnabledInput.disabled = true;
  hyperliquidMultisigAuthoritySignerInput.disabled = true;
  multisigStatus.textContent = target === "multi"
    ? "Requesting Hyperliquid multisig mode..."
    : "Requesting Hyperliquid single-signature mode...";
  try {
    const response = await walletConnectDebug("setHyperliquidMultisigMode", {
      authoritySigner,
      includeAuthoritySigner,
      includeBrowserSigner,
      target,
      threshold
    });
    if (response && response.error) {
      setStatus(response.error.message || "Could not change Hyperliquid account mode.", "error");
    } else {
      setStatus(response.result?.message || "Hyperliquid account mode updated.");
    }
  } catch (error) {
    setStatus(error && error.message ? error.message : "Could not change Hyperliquid account mode.", "error");
  } finally {
    await renderMultisigStatus();
  }
}

async function changeHyperliquidMultisigThreshold() {
  const threshold = Number(hyperliquidMultisigThresholdInput.value || 1) === 2 ? 2 : 1;
  await chrome.storage.local.set({ hyperliquidMultisigThreshold: threshold });
  setStatus(threshold === 2
    ? "Hyperliquid multisig will require one selected additional signer when enabled."
    : "Hyperliquid multisig will allow one approved signer when enabled.");
}

async function changeHyperliquidMultisigSignerOptions() {
  hyperliquidMultisigAuthoritySignerInput.disabled = !hyperliquidMultisigAuthoritySignerEnabledInput.checked ||
    hyperliquidMultisigAuthoritySignerRow.classList.contains("hidden");
  await chrome.storage.local.set({
    hyperliquidMultisigAuthoritySigner: hyperliquidMultisigAuthoritySignerInput.value || "",
    hyperliquidMultisigIncludeAuthoritySigner: !hyperliquidMultisigAuthoritySignerRow.classList.contains("hidden") &&
      hyperliquidMultisigAuthoritySignerEnabledInput.checked,
    hyperliquidMultisigIncludeBrowserSigner: hyperliquidMultisigBrowserSignerInput.checked
  });
}

function queueLoadLog() {
  if (logRefreshQueued) return;
  logRefreshQueued = true;
  setTimeout(() => {
    logRefreshQueued = false;
    loadLog().catch(() => {});
  }, 100);
}

async function clearLog() {
  await requestDebug("clearLog");
  await loadLog();
}

async function copyLog() {
  try {
    await navigator.clipboard.writeText(debugLog.textContent || "");
    setStatus("Log copied.");
  } catch (error) {
    setStatus(error && error.message ? error.message : "Could not copy log.", "error");
  }
}

async function changeSigner() {
  signerChangeInFlight = true;
  const selectedSource = parseSignerOption(signingModeSelect.value);
  try {
    const response = await walletConnectDebug("setDefaultAccountSource", {
      signingMode: selectedSource.signingMode,
      selectedPassliAddressId: selectedSource.selectedPassliAddressId,
      externalAuthorityWalletId: selectedSource.externalAuthorityWalletId,
      walletConnectAddress: selectedSource.walletConnectAddress,
      walletConnectTopic: selectedSource.walletConnectTopic
    });
    if (response && response.error) {
      setStatus(response.error.message || "Could not change the default account source.", "error");
      return;
    }
    const notified = response && response.result ? Number(response.result.notifiedConnections || 0) : 0;
    setStatus(selectedSource.signingMode === "walletconnect"
      ? `Signing with WalletConnect.${notified ? ` Notified ${notified} dApp connection${notified === 1 ? "" : "s"}.` : ""}`
      : selectedSource.signingMode === "externalAuthority"
        ? `Using the selected external authority wallet.${notified ? ` Notified ${notified} dApp connection${notified === 1 ? "" : "s"}.` : ""}`
        : `Using the selected Passli address.${notified ? ` Notified ${notified} dApp connection${notified === 1 ? "" : "s"}.` : ""}`);
  } finally {
    signerChangeInFlight = false;
    pendingLoadAfterSignerChange = false;
    await loadState();
    await renderConnectionsIfOpen();
  }
}

loginPassliButton.addEventListener("click", loginPassli);
logoutPassliButton.addEventListener("click", logoutPassli);
signingModeButton.addEventListener("click", toggleSignerMenu);
document.addEventListener("click", (event) => {
  if (!event.target.closest(".signerMenu")) closeSignerMenu();
});
document.addEventListener("keydown", (event) => {
  if (event.key === "Escape") closeSignerMenu();
});
copySignerButton.addEventListener("click", copySignerAddress);
autoApproveSafeRequestsInput.addEventListener("change", changeAutoApproveSafeRequests);
notifyDappsOnDefaultAccountChangeInput.addEventListener("change", changeNotifyDappsOnDefaultAccountChange);
verboseKeyVaultLogsInput.addEventListener("change", changeVerboseKeyVaultLogs);
convertSingleButton.addEventListener("click", () => {
  hyperliquidMultisigModeInput.checked = false;
  changeHyperliquidMultisigMode();
});
hyperliquidMultisigModeInput.addEventListener("change", changeHyperliquidMultisigMode);
hyperliquidMultisigThresholdInput.addEventListener("change", changeHyperliquidMultisigThreshold);
hyperliquidMultisigBrowserSignerInput.addEventListener("change", changeHyperliquidMultisigSignerOptions);
hyperliquidMultisigAuthoritySignerEnabledInput.addEventListener("change", changeHyperliquidMultisigSignerOptions);
hyperliquidMultisigAuthoritySignerInput.addEventListener("change", changeHyperliquidMultisigSignerOptions);
connectWalletConnectButton.addEventListener("click", connectWalletConnect);
toggleConnectionsButton.addEventListener("click", toggleConnections);
walletConnectLabelInput.addEventListener("change", saveWalletConnectLabel);
refreshLogButton.addEventListener("click", loadLog);
copyLogButton.addEventListener("click", copyLog);
clearLogButton.addEventListener("click", clearLog);
chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName !== "local") return;

  if (changes.debugLog) {
    queueLoadLog();
  }

  if (
    changes.passliExtensionLoggedIn ||
    changes.passliExtensionAlias ||
    changes.passliExtensionAccountId ||
    changes.passliExtensionDeviceId ||
    changes.passliExtensionLoginRequestId
  ) {
    loadState();
    return;
  }

  if (
    changes.walletConnectUri ||
    changes.walletConnectAccount ||
    changes.walletConnectWallet ||
    changes.walletConnectLabel ||
    changes.selectedWalletConnectAddress ||
    changes.selectedWalletConnectTopic ||
    changes.externalAuthorityWallets ||
    changes.selectedExternalAuthorityWalletId ||
    changes.selectedPassliAddressId ||
    changes.passliCryptoAddresses ||
    changes.passliCryptoAddressLastUsedAt ||
    changes.signingMode ||
    changes.offerAllConnectedWalletsToDapps ||
    changes.notifyDappsOnDefaultAccountChange ||
    changes.passliVerboseKeyVaultLogs ||
    changes.hyperliquidMultisigThreshold ||
    changes.hyperliquidMultisigIncludeBrowserSigner ||
    changes.hyperliquidMultisigIncludeAuthoritySigner ||
    changes.hyperliquidMultisigAuthoritySigner ||
    changes.address ||
    changes.passliSelectedWallet ||
    changes.connectedOrigins
  ) {
    if (signerChangeInFlight) {
      pendingLoadAfterSignerChange = true;
      return;
    }
    loadState();
    renderConnectionsIfOpen();
  }

});

renderExtensionVersion();
loadState();
queueLoadLog();
