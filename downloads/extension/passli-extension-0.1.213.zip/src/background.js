importScripts(
  "vendor/ethers.umd.min.js",
  "vendor/walletconnect-bridge.js",
  "vendor/hyperliquid.js",
  "request-decoder.js",
  "step-up.js",
  "profile-bridge.js",
  "passkeys/worker.js",
  "passkeys/reconnect.js"
);

const Ethers = globalThis.ethers;
const WalletConnectBridge = globalThis.HyperliquidWalletConnectBridge;
const HyperliquidBridge = globalThis.PassliHyperliquidBridge;
const RequestDecoder = globalThis.PassliRequestDecoder;

const DEFAULT_STATE = {
  privateKey: "",
  address: "0x3b0322eD10Cd526681E3eB91e45176522AC9Db30",
  chainId: "0x3e7",
  hyperliquidChain: "Mainnet",
  signatureChainId: "0xa4b1",
  networkMode: "hyperliquid-mainnet",
  signingMode: "local",
  walletConnectProjectId: "",
  walletConnectUri: "",
  walletConnectAccount: null,
  walletConnectWallet: null,
  walletConnectLabel: "",
  selectedWalletConnectAddress: "",
  selectedWalletConnectTopic: "",
  externalAuthorityWallets: [],
  selectedExternalAuthorityWalletId: "",
  autoApproveSafeRequests: true,
  connectedOrigins: {},
  trustedDappOrigins: {},
  notifyDappsOnDefaultAccountChange: false,
  passliVerboseKeyVaultLogs: false,
  passliAccountDisabled: false,
  passliAccountDisabledAt: "",
  passliAccountDisabledReason: "",
  passliAccountDisabledRequestId: "",
  passliExtensionDeviceId: "",
  passliCryptoAddresses: [],
  passliCryptoAddressLastUsedAt: {},
  selectedPassliAddressId: "",
  hyperliquidMultisigThreshold: 1,
  hyperliquidMultisigIncludeBrowserSigner: true,
  hyperliquidMultisigIncludeAuthoritySigner: false,
  hyperliquidMultisigAuthoritySigner: "",
  offerAllConnectedWalletsToDapps: false
};

const RPC_URLS = {
  "0x1": "https://ethereum-rpc.publicnode.com",
  "0xa4b1": "https://arb1.arbitrum.io/rpc",
  "0x2105": "https://mainnet.base.org",
  "0x3e7": "https://rpc.hyperliquid.xyz/evm",
  "0x3e6": "https://rpc.hyperliquid-testnet.xyz/evm"
};

function normalizeChainIdHex(chainId) {
  if (typeof chainId === "number" && Number.isFinite(chainId)) {
    return `0x${chainId.toString(16)}`;
  }
  if (typeof chainId === "bigint") {
    return `0x${chainId.toString(16)}`;
  }
  const value = String(chainId || "").trim();
  if (/^0x[0-9a-fA-F]+$/.test(value)) {
    return `0x${BigInt(value).toString(16)}`;
  }
  if (/^[0-9]+$/.test(value)) {
    return `0x${BigInt(value).toString(16)}`;
  }
  return value;
}

function evmProviderChainId(chainId, fallback = DEFAULT_STATE.chainId) {
  const value = String(chainId || "").trim();
  if (/^0x[0-9a-fA-F]+$/.test(value) || /^[0-9]+$/.test(value)) {
    return normalizeChainIdHex(value);
  }
  return normalizeChainIdHex(fallback || DEFAULT_STATE.chainId);
}

function isEvmProviderChainId(chainId) {
  return /^0x[0-9a-fA-F]+$/.test(String(chainId || "").trim());
}

function isHyperliquidCoreChainId(chainId) {
  return String(chainId || "").trim().toLowerCase() === "hyperliquid:core:mainnet";
}

function isEvmProviderAddress(address) {
  return /^0x[a-fA-F0-9]{40}$/.test(String(address || "").trim());
}

function evmProviderCompatibleAccount(account, state) {
  if (!account || !account.address) return null;
  if (
    account.signerType === "externalAuthority" ||
    account.signerType === "walletconnect" ||
    account.type === "external-authority" ||
    account.type === "walletconnect"
  ) {
    return {
      ...account,
      chainId: evmProviderChainId("", state.chainId),
      sourceChainId: account.chainId || ""
    };
  }
  const chainId = account.chainId || state.chainId;
  if (isEvmProviderChainId(chainId)) {
    return {
      ...account,
      chainId: evmProviderChainId(chainId, state.chainId)
    };
  }
  if (isHyperliquidCoreChainId(chainId) && isEvmProviderAddress(account.address)) {
    return {
      ...account,
      chainId: evmProviderChainId("", state.chainId),
      chainName: account.chainName || account.chain || "Hyperliquid",
      providerChainId: evmProviderChainId("", state.chainId),
      sourceChainId: chainId
    };
  }
  return null;
}

function evmProviderAccountError(account, method) {
  if (!account || !account.address) {
    return {
      error: {
        code: 4900,
        message: `${method} requires a selected wallet. Open Passli Safe Wallet and choose a synced Passli address or reconnect the selected external wallet.`
      }
    };
  }
  const chain = account && (account.chainName || account.chain || account.label || account.chainId);
  return {
    error: {
      code: 4900,
      message: `${method} is an EVM provider request, but the selected Passli address${chain ? ` is on ${chain}` : ""}. Choose an EVM address such as Hyperliquid, Ethereum, Arbitrum, or Base.`
    }
  };
}

function evmProviderAccountCompatibilityError(account, state, method) {
  if (evmProviderCompatibleAccount(account, state)) return null;
  const chainId = account && account.chainId ? account.chainId : state.chainId;
  return evmProviderAccountError({ ...account, chainId }, method);
}

function evmProviderAccounts(accounts, state) {
  return (Array.isArray(accounts) ? accounts : [])
    .map((account) => evmProviderCompatibleAccount(account, state))
    .filter(Boolean);
}

const MAX_LOG_ENTRIES = 100;
const LOG_COALESCE_WINDOW_MS = 2000;
const PASSLI_AUTH_ORIGINS = new Set([
  "https://passli.app",
  "http://localhost:5173",
  "http://localhost:8081",
  "http://127.0.0.1:8081"
]);
const PASSLI_AUTH_URL = "https://passli.app";
const PASSLI_DEV_AUTH_URL = "http://localhost:5173";
const PASSLI_API_URL = "https://api.passli.app";
const PASSLI_DECODER_URL = "https://decoder.passli.app";
const PASSLI_BRIDGE_REQUEST_TYPE = "passli.extension.request.v1";
const PASSLI_BRIDGE_APPROVAL_TYPE = "passli.extension.approval.v1";
const PASSLI_BRIDGE_RESPONSE_TYPE = "passli.extension.response.v1";
const PASSLI_PROVISION_OPERATIONAL_KEYS_TYPE = "passli.extension.provisionOperationalKeys.v1";
const PASSLI_CAPABILITY_CHALLENGE_TYPE = "passli.extension.capabilityChallenge.v1";
const PASSLI_CAPABILITY_GRANT_TYPE = "passli.extension.capabilityGrant.v1";
const PASSLI_SIGN_CLIENT_REQUEST_TYPE = "passli.extension.signClientRequest.v1";
const PASSLI_EXTENSION_AUTH_STATUS_TYPE = "PASSLI_EXTENSION_AUTH_STATUS";
const PASSLI_EXTENSION_ADDRESSES_UPDATED_TYPE = "passli.extension.addressesUpdated.v1";
const PASSLI_EXTENSION_SELECTED_ADDRESS_STATUS_TYPE = "PASSLI_EXTENSION_SELECTED_ADDRESS_STATUS";
const PASSLI_EXTERNAL_AUTHORITY_WALLETS_TYPE = "PASSLI_EXTENSION_EXTERNAL_AUTHORITY_WALLETS";
const PASSLI_BRIDGE_TIMEOUT_MS = 5 * 60 * 1000;
const EXTENSION_VAULT_REQUIRED_METHODS = new Set([
  "personal_sign",
  "eth_sign",
  "eth_signTypedData",
  "eth_signTypedData_v3",
  "eth_signTypedData_v4",
  "eth_sendTransaction",
  "hyperliquid_authorizeAction"
]);
const PASSLI_KEY_VAULT_DB_NAME = "passli.extension.key-vault.v1";
const PASSLI_KEY_VAULT_DB_VERSION = 1;
const PASSLI_KEY_VAULT_RECORD_STORE = "operationalKeyRecords";
const PASSLI_KEY_VAULT_WRAP_STORE = "wrappingKeys";
const HYPERLIQUID_MULTISIG_USER_SIGNER_SECRET_ID = "hyperliquid_multisig_user_signer_private_key_v1";
const HYPERLIQUID_AUTHORIZE_ACTION_CAPABILITY = {
  version: 1,
  status: "supported",
  submitModes: ["returnSignedAction", "walletSubmit"],
  nonceModes: ["dapp", "wallet"],
  defaultNoncePolicy: "dapp"
};

function requestedCapabilityChains(params, activeChainId, fallbackChainId) {
  const requested = [];
  if (Array.isArray(params)) {
    if (Array.isArray(params[1])) {
      requested.push(...params[1]);
    } else if (Array.isArray(params[0])) {
      requested.push(...params[0]);
    } else if (params[0] && typeof params[0] === "object") {
      const request = params[0];
      if (Array.isArray(request.chainIds)) requested.push(...request.chainIds);
      if (Array.isArray(request.chains)) requested.push(...request.chains);
    }
  }
  if (!requested.length) {
    requested.push(activeChainId || fallbackChainId, "0x3e7", "0xa4b1", "0x3e6");
  }
  return Array.from(new Set(requested.map(normalizeChainIdHex).filter(Boolean)));
}

const PASSLI_REQUIRED_WEB_VERSION = "0.1.102";
const PASSLI_EXTENSION_PROTOCOL_VERSION = 1;
const pendingApprovals = new Map();
const pendingBridgeRequests = new Map();
const approvalStatusPorts = new Map();
const walletConnectSigningPorts = new Map();
let approvalWindowId = null;
let extensionConfigPromise = null;

function passliBridgeErrorResponse(requestId, error, status = "failed") {
  return {
    error: {
      code: error && error.code ? error.code : 4001,
      message: error && error.message ? error.message : String(error || "Passli bridge request failed.")
    },
    requestId,
    status,
    type: PASSLI_BRIDGE_RESPONSE_TYPE
  };
}

function bytesToBase64(bytes) {
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary);
}

function base64ToBytes(value) {
  const binary = atob(String(value || ""));
  const bytes = new Uint8Array(binary.length);
  for (let index = 0; index < binary.length; index += 1) {
    bytes[index] = binary.charCodeAt(index);
  }
  return bytes;
}

function openPassliKeyVaultDatabase() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(PASSLI_KEY_VAULT_DB_NAME, PASSLI_KEY_VAULT_DB_VERSION);
    request.onerror = () => reject(request.error || new Error("Could not open Passli extension key vault."));
    request.onsuccess = () => resolve(request.result);
    request.onupgradeneeded = () => {
      const database = request.result;
      if (!database.objectStoreNames.contains(PASSLI_KEY_VAULT_RECORD_STORE)) {
        database.createObjectStore(PASSLI_KEY_VAULT_RECORD_STORE, { keyPath: "id" });
      }
      if (!database.objectStoreNames.contains(PASSLI_KEY_VAULT_WRAP_STORE)) {
        database.createObjectStore(PASSLI_KEY_VAULT_WRAP_STORE, { keyPath: "accountId" });
      }
    };
  });
}

async function withPassliKeyVaultStore(storeName, mode, run) {
  const database = await openPassliKeyVaultDatabase();
  return new Promise((resolve, reject) => {
    const transaction = database.transaction(storeName, mode);
    const request = run(transaction.objectStore(storeName));
    request.onerror = () => reject(request.error || new Error("Could not update Passli extension key vault."));
    request.onsuccess = () => resolve(request.result);
    transaction.oncomplete = () => database.close();
    transaction.onerror = () => {
      database.close();
      reject(transaction.error || new Error("Could not complete Passli extension key vault update."));
    };
  });
}

async function getOrCreateVaultWrappingKey(accountId) {
  const existing = await withPassliKeyVaultStore(PASSLI_KEY_VAULT_WRAP_STORE, "readonly", (store) => store.get(accountId));
  if (existing && existing.key) return existing.key;

  const key = await crypto.subtle.generateKey(
    { name: "AES-GCM", length: 256 },
    false,
    ["encrypt", "decrypt"]
  );
  await withPassliKeyVaultStore(PASSLI_KEY_VAULT_WRAP_STORE, "readwrite", (store) => store.put({
    accountId,
    createdAt: new Date().toISOString(),
    key,
    version: 1
  }));
  return key;
}

async function encryptVaultPayload(accountId, payload) {
  const key = await getOrCreateVaultWrappingKey(accountId);
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const plaintext = new TextEncoder().encode(JSON.stringify(payload));
  const ciphertext = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, plaintext);
  return {
    ciphertext: bytesToBase64(new Uint8Array(ciphertext)),
    iv: bytesToBase64(iv)
  };
}

async function decryptVaultPayload(record) {
  const key = await getOrCreateVaultWrappingKey(record.accountId);
  const plaintext = await crypto.subtle.decrypt(
    { name: "AES-GCM", iv: base64ToBytes(record.encrypted.iv) },
    key,
    base64ToBytes(record.encrypted.ciphertext)
  );
  return JSON.parse(new TextDecoder().decode(plaintext));
}

function assertAllowedPassliOrigin(origin) {
  if (!PASSLI_AUTH_ORIGINS.has(String(origin || ""))) {
    const error = new Error("Passli extension key-vault messages are allowed only from passli.app.");
    error.code = 4100;
    throw error;
  }
}

function assertProvisionPayload(payload) {
  if (!payload || payload.type !== PASSLI_PROVISION_OPERATIONAL_KEYS_TYPE || payload.version !== 1) {
    throw new Error("Unsupported Passli extension provisioning protocol.");
  }
  assertCompatibleWebVersion(payload);
  for (const field of ["requestId", "accountId", "alias", "credentialId", "createdAt"]) {
    if (!payload[field] || typeof payload[field] !== "string") {
      throw new Error(`Provisioning message is missing ${field}.`);
    }
  }
  if (!payload.keyMaterial || typeof payload.keyMaterial !== "object") {
    throw new Error("Provisioning message is missing key material.");
  }
  const wrappedSecrets = payload.keyMaterial.wrappedSecrets && typeof payload.keyMaterial.wrappedSecrets === "object"
    ? payload.keyMaterial.wrappedSecrets
    : {};
  const hlMultisigSignerPrivateKey = wrappedSecrets[HYPERLIQUID_MULTISIG_USER_SIGNER_SECRET_ID] ||
    payload.keyMaterial.hlMultisigSignerPrivateKey;
  normalizeHexPrivateKey(hlMultisigSignerPrivateKey);
  const wallets = Array.isArray(payload.keyMaterial.wallets) ? payload.keyMaterial.wallets : [];
  for (const wallet of wallets) {
    normalizeAddress(wallet.address);
    normalizeHexPrivateKey(wallet.singleSigPrivateKey);
  }
}

function semverParts(version) {
  return String(version || "")
    .trim()
    .split(".")
    .map((part) => Number.parseInt(part, 10))
    .map((part) => (Number.isFinite(part) ? part : 0));
}

function compareSemver(left, right) {
  const leftParts = semverParts(left);
  const rightParts = semverParts(right);
  const length = Math.max(leftParts.length, rightParts.length, 3);
  for (let index = 0; index < length; index += 1) {
    const leftPart = leftParts[index] || 0;
    const rightPart = rightParts[index] || 0;
    if (leftPart > rightPart) return 1;
    if (leftPart < rightPart) return -1;
  }
  return 0;
}

function extensionVersion() {
  return chrome.runtime.getManifest().version || "unknown";
}

function assertCompatibleWebVersion(message) {
  const appVersion = String(message && message.appVersion ? message.appVersion : "").trim();
  if (!appVersion || compareSemver(appVersion, PASSLI_REQUIRED_WEB_VERSION) < 0) {
    const error = new Error(`passli.app version ${appVersion || "unknown"} is too old for extension ${extensionVersion()}. Refresh passli.app and use version ${PASSLI_REQUIRED_WEB_VERSION} or newer.`);
    error.code = 426;
    error.versionMismatch = true;
    throw error;
  }

  const requiredExtensionVersion = String(message && message.requiredExtensionVersion ? message.requiredExtensionVersion : "").trim();
  if (requiredExtensionVersion && compareSemver(extensionVersion(), requiredExtensionVersion) >= 0) return;
  const error = new Error(`Passli extension ${extensionVersion()} is too old for passli.app ${appVersion}. Reload the unpacked extension and use extension ${requiredExtensionVersion || "unknown"} or newer.`);
  error.code = 426;
  error.versionMismatch = true;
  throw error;
}

function publicWalletMetadata(wallet, chainId) {
  return {
    address: normalizeAddress(wallet.address),
    chainId: wallet.chainId || chainId,
    label: wallet.label || wallet.name || "Passli wallet",
    name: wallet.name || wallet.walletName || "Default",
    signerType: "local",
    type: "passli-account",
    walletId: Number(wallet.walletId || 0)
  };
}

function externalAuthorityWalletId(wallet) {
  return String(wallet && wallet.id ? wallet.id : [
    String(wallet && wallet.connectorId ? wallet.connectorId : "external"),
    normalizeChainIdHex(wallet && wallet.chainId ? wallet.chainId : ""),
    String(wallet && wallet.address ? wallet.address : "").toLowerCase()
  ].join(":"));
}

function normalizeExternalAuthorityWallet(wallet) {
  if (!wallet || !wallet.address) return null;
  const label = String(wallet.label || wallet.connectorName || "External wallet").trim();
  return {
    address: normalizeAddress(wallet.address),
    chainId: normalizeChainIdHex(wallet.chainId || DEFAULT_STATE.signatureChainId),
    connectorId: String(wallet.connectorId || ""),
    id: externalAuthorityWalletId(wallet),
    label: label || "External wallet",
    lastConnectedAt: String(wallet.lastConnectedAt || ""),
    signerType: "externalAuthority",
    type: "external-authority"
  };
}

function externalAuthorityWalletsForState(state) {
  return (Array.isArray(state.externalAuthorityWallets) ? state.externalAuthorityWallets : [])
    .map(normalizeExternalAuthorityWallet)
    .filter(Boolean);
}

function selectedExternalAuthorityWalletForState(state) {
  const wallets = externalAuthorityWalletsForState(state);
  if (!wallets.length) return null;
  const selectedId = String(state.selectedExternalAuthorityWalletId || "");
  return wallets.find((wallet) => wallet.id === selectedId) || wallets[0];
}

function externalAuthorityWalletForAddress(state, address) {
  if (!address) return null;
  return externalAuthorityWalletsForState(state).find((wallet) => sameAddress(wallet.address, address)) || null;
}

function parseConnectedSignerSelection(value) {
  const raw = String(value || "");
  if (raw.startsWith("externalAuthority:")) {
    return {
      type: "externalAuthority",
      id: decodeURIComponent(raw.slice("externalAuthority:".length))
    };
  }
  if (raw.startsWith("walletconnect:")) {
    const rest = raw.slice("walletconnect:".length);
    const separatorIndex = rest.indexOf(":");
    const encodedTopic = separatorIndex >= 0 ? rest.slice(0, separatorIndex) : "";
    const address = separatorIndex >= 0 ? rest.slice(separatorIndex + 1) : rest;
    return {
      type: "walletconnect",
      address,
      topic: encodedTopic ? decodeURIComponent(encodedTopic) : ""
    };
  }
  return { type: "", id: "", address: "", topic: "" };
}

function connectedSignerForSelection(state, selectionValue) {
  const selection = parseConnectedSignerSelection(selectionValue);
  if (selection.type === "externalAuthority") {
    return externalAuthorityWalletsForState(state).find((wallet) => wallet.id === selection.id) || null;
  }
  if (selection.type === "walletconnect") {
    const account = state.walletConnectAccount && state.walletConnectAccount.address ? state.walletConnectAccount : null;
    if (!account) return null;
    const topicMatches = !selection.topic || String(account.topic || "") === selection.topic;
    const addressMatches = !selection.address || sameAddress(account.address, selection.address);
    return topicMatches && addressMatches ? account : null;
  }
  return null;
}

async function saveProvisionedOperationalKeys(message, sender) {
  const origin = message.origin || originFromSender(sender);
  await appendKeyVaultVerboseLog({
    phase: "extension-vault:provision-received",
    origin,
    method: PASSLI_PROVISION_OPERATIONAL_KEYS_TYPE,
    result: {
      payloadType: message && message.payload ? message.payload.type || "" : "",
      requestId: message && message.payload ? message.payload.requestId || "" : "",
      senderOrigin: originFromSender(sender)
    }
  });
  assertAllowedPassliOrigin(origin);
  const payload = message.payload || {};
  await appendKeyVaultVerboseLog({
    phase: "extension-vault:provision-origin-accepted",
    origin,
    method: PASSLI_PROVISION_OPERATIONAL_KEYS_TYPE,
    result: {
      requestId: payload.requestId || "",
      version: payload.version || null
    }
  });
  assertProvisionPayload(payload);
  await appendKeyVaultVerboseLog({
    phase: "extension-vault:provision-payload-accepted",
    origin,
    method: PASSLI_PROVISION_OPERATIONAL_KEYS_TYPE,
    result: {
      accountId: payload.accountId,
      alias: payload.alias,
      appVersion: payload.appVersion || "",
      credentialIdPresent: Boolean(payload.credentialId),
      hlMultisigSignerAddress: payload.hlMultisigSignerAddress || "",
      selectedWallet: payload.selectedWallet && payload.selectedWallet.address ? payload.selectedWallet.address : "",
      walletCount: Array.isArray(payload.keyMaterial.wallets) ? payload.keyMaterial.wallets.length : 0
    }
  });

  const now = new Date().toISOString();
  const state = await getState();
  const keyMaterialWallets = Array.isArray(payload.keyMaterial.wallets) ? payload.keyMaterial.wallets : [];
  const incomingWrappedSecrets = payload.keyMaterial.wrappedSecrets && typeof payload.keyMaterial.wrappedSecrets === "object"
    ? payload.keyMaterial.wrappedSecrets
    : {};
  const hlMultisigSignerPrivateKey = normalizeHexPrivateKey(
    incomingWrappedSecrets[HYPERLIQUID_MULTISIG_USER_SIGNER_SECRET_ID] ||
    payload.keyMaterial.hlMultisigSignerPrivateKey
  );
  const wrappedSecrets = {
    ...incomingWrappedSecrets,
    [HYPERLIQUID_MULTISIG_USER_SIGNER_SECRET_ID]: hlMultisigSignerPrivateKey
  };
  const privatePayload = {
    hlMultisigSignerPrivateKey,
    wrappedSecrets,
    wallets: keyMaterialWallets.map((wallet) => ({
      address: normalizeAddress(wallet.address),
      name: String(wallet.name || "Default"),
      singleSigPrivateKey: normalizeHexPrivateKey(wallet.singleSigPrivateKey),
      walletId: Number(wallet.walletId || 0)
    }))
  };
  const publicWallets = privatePayload.wallets.map((wallet) => publicWalletMetadata(wallet, state.chainId));
  const selectedWalletInput = payload.selectedWallet && payload.selectedWallet.address
    ? payload.selectedWallet
    : publicWallets[0];
  const selectedWallet = selectedWalletInput
    ? {
      ...publicWalletMetadata(selectedWalletInput, state.chainId),
      accountId: payload.accountId,
      cloudSignerAddress: String(payload.cloudSignerAddress || ""),
      hlMultisigSignerAddress: normalizeAddress(payload.hlMultisigSignerAddress),
      label: selectedWalletInput.label || `${payload.alias} ${selectedWalletInput.walletName || selectedWalletInput.name || "Default"}`,
      walletName: selectedWalletInput.walletName || selectedWalletInput.name || "Default"
    }
    : null;

  const encrypted = await encryptVaultPayload(payload.accountId, privatePayload);
  await appendKeyVaultVerboseLog({
    phase: "extension-vault:provision-encrypted",
    origin,
    method: PASSLI_PROVISION_OPERATIONAL_KEYS_TYPE,
    result: {
      accountId: payload.accountId,
      ciphertextBytes: encrypted && encrypted.ciphertext ? encrypted.ciphertext.length : 0,
      walletCount: publicWallets.length
    }
  });
  const keyRecordId = payload.accountId;
  await withPassliKeyVaultStore(PASSLI_KEY_VAULT_RECORD_STORE, "readwrite", (store) => store.put({
    accountId: payload.accountId,
    alias: payload.alias,
    createdAt: payload.createdAt,
    credentialId: payload.credentialId,
    encrypted,
    hlMultisigSignerAddress: normalizeAddress(payload.hlMultisigSignerAddress),
    id: keyRecordId,
    publicWallets,
    updatedAt: now,
    version: 1
  }));
  await appendKeyVaultVerboseLog({
    phase: "extension-vault:provision-indexeddb-written",
    origin,
    method: PASSLI_PROVISION_OPERATIONAL_KEYS_TYPE,
    result: {
      accountId: payload.accountId,
      keyRecordId,
      walletCount: publicWallets.length
    }
  });

  await setState({
    passliExtensionAccountId: payload.accountId,
    passliExtensionAlias: payload.alias,
    passliExtensionAuthOrigin: origin,
    passliExtensionCloudSignerAddress: String(payload.cloudSignerAddress || ""),
    passliExtensionCredentialId: payload.credentialId,
    passliExtensionHlMultisigSignerAddress: normalizeAddress(payload.hlMultisigSignerAddress),
    passliExtensionKeyRecordId: keyRecordId,
    passliExtensionKeyVaultReady: true,
    passliExtensionKeyVaultUpdatedAt: now,
    passliExtensionLoggedIn: true,
    passliExtensionWallets: publicWallets,
    passliSelectedWallet: selectedWallet
  });
  await appendKeyVaultVerboseLog({
    phase: "extension-vault:provision-state-written",
    origin,
    method: PASSLI_PROVISION_OPERATIONAL_KEYS_TYPE,
    result: {
      accountId: payload.accountId,
      keyRecordId,
      keyVaultReady: true,
      selectedWallet: selectedWallet && selectedWallet.address ? selectedWallet.address : ""
    }
  });

  await appendLog({
    phase: "extension-vault:provisioned",
    origin,
    method: PASSLI_PROVISION_OPERATIONAL_KEYS_TYPE,
    result: {
      accountId: payload.accountId,
      keyRecordId,
      wallets: publicWallets.map((wallet) => wallet.address)
    }
  });
  await broadcastExtensionWalletStatusToPassli(await getState()).catch(() => {});
  return {
    keyRecordId,
    extensionProtocolVersion: PASSLI_EXTENSION_PROTOCOL_VERSION,
    extensionVersion: extensionVersion(),
    protocol: {
      capabilityChallengeType: PASSLI_CAPABILITY_CHALLENGE_TYPE,
      capabilityGrantType: PASSLI_CAPABILITY_GRANT_TYPE,
      signClientRequestType: PASSLI_SIGN_CLIENT_REQUEST_TYPE
    },
    requiredWebVersion: PASSLI_REQUIRED_WEB_VERSION,
    status: "stored"
  };
}

async function getDecryptedVaultRecord(state) {
  const accountId = state.passliExtensionKeyRecordId || state.passliExtensionAccountId || "";
  if (!accountId) {
    await appendKeyVaultVerboseLog({
      phase: "extension-vault:record-missing",
      origin: "extension",
      method: "getDecryptedVaultRecord",
      result: keyVaultStateSummary(state),
      error: "No passliExtensionKeyRecordId or passliExtensionAccountId is set."
    });
    return null;
  }
  const record = await withPassliKeyVaultStore(PASSLI_KEY_VAULT_RECORD_STORE, "readonly", (store) => store.get(accountId));
  if (!record || !record.encrypted) {
    await appendKeyVaultVerboseLog({
      phase: "extension-vault:record-missing",
      origin: "extension",
      method: "getDecryptedVaultRecord",
      result: {
        ...keyVaultStateSummary(state),
        lookupAccountId: accountId,
        recordFound: Boolean(record),
        encryptedFound: Boolean(record && record.encrypted)
      },
      error: "No encrypted key vault record exists for the active account."
    });
    return null;
  }
  const privatePayload = await decryptVaultPayload(record);
  await appendKeyVaultVerboseLog({
    phase: "extension-vault:record-decrypted",
    origin: "extension",
    method: "getDecryptedVaultRecord",
    result: {
      accountId: record.accountId || accountId,
      hlMultisigSignerAddress: record.hlMultisigSignerAddress || "",
      publicWalletCount: Array.isArray(record.publicWallets) ? record.publicWallets.length : 0,
      privateWalletCount: privatePayload && Array.isArray(privatePayload.wallets) ? privatePayload.wallets.length : 0
    }
  });
  return {
    ...record,
    privatePayload
  };
}

async function keyVaultVerboseLogsEnabled() {
  const stored = await chrome.storage.local.get({ passliVerboseKeyVaultLogs: false });
  return stored.passliVerboseKeyVaultLogs === true;
}

async function appendKeyVaultVerboseLog(entry) {
  if (!(await keyVaultVerboseLogsEnabled())) return;
  await appendLog(entry);
}

function keyVaultStateSummary(state) {
  return {
    accountId: state.passliExtensionAccountId || "",
    alias: state.passliExtensionAlias || "",
    authOrigin: state.passliExtensionAuthOrigin || "",
    credentialIdPresent: Boolean(state.passliExtensionCredentialId),
    keyRecordId: state.passliExtensionKeyRecordId || "",
    keyVaultReady: state.passliExtensionKeyVaultReady === true,
    keyVaultUpdatedAt: state.passliExtensionKeyVaultUpdatedAt || "",
    loggedIn: state.passliExtensionLoggedIn === true,
    selectedWallet: state.passliSelectedWallet && state.passliSelectedWallet.address ? state.passliSelectedWallet.address : "",
    walletCount: Array.isArray(state.passliExtensionWallets) ? state.passliExtensionWallets.length : 0
  };
}

function vaultWalletByAddress(vaultRecord, address) {
  if (!vaultRecord || !vaultRecord.privatePayload) return null;
  const wallets = Array.isArray(vaultRecord.privatePayload.wallets) ? vaultRecord.privatePayload.wallets : [];
  if (address) {
    return wallets.find((wallet) => sameAddress(wallet.address, address)) || null;
  }
  return wallets[0] || null;
}

function hyperliquidSingleSigPrivateKeyForVaultAccount(vaultRecord, state, address) {
  const baseWallet = vaultWalletByAddress(vaultRecord, address);
  if (baseWallet && baseWallet.singleSigPrivateKey) return baseWallet.singleSigPrivateKey;
  const userSignerAddress = vaultRecord?.hlMultisigSignerAddress ||
    state.passliExtensionHlMultisigSignerAddress ||
    state.passliSelectedWallet?.hlMultisigSignerAddress ||
    "";
  if (
    userSignerAddress &&
    sameAddress(userSignerAddress, address) &&
    hyperliquidMultisigUserSignerPrivateKey(vaultRecord)
  ) {
    return hyperliquidMultisigUserSignerPrivateKey(vaultRecord);
  }
  return "";
}

function hyperliquidMultisigUserSignerPrivateKey(vaultRecord) {
  const wrappedSecrets = vaultRecord?.privatePayload?.wrappedSecrets &&
    typeof vaultRecord.privatePayload.wrappedSecrets === "object"
    ? vaultRecord.privatePayload.wrappedSecrets
    : {};
  return wrappedSecrets[HYPERLIQUID_MULTISIG_USER_SIGNER_SECRET_ID] ||
    vaultRecord?.privatePayload?.hlMultisigSignerPrivateKey ||
    "";
}

function localUserMultisigSignerPrivateKeyForAddress(vaultRecord, state, address) {
  const userSignerAddress = vaultRecord?.hlMultisigSignerAddress ||
    state.passliExtensionHlMultisigSignerAddress ||
    state.passliSelectedWallet?.hlMultisigSignerAddress ||
    "";
  if (
    userSignerAddress &&
    sameAddress(userSignerAddress, address) &&
    hyperliquidMultisigUserSignerPrivateKey(vaultRecord)
  ) {
    return hyperliquidMultisigUserSignerPrivateKey(vaultRecord);
  }
  return "";
}

async function signMethodWithWallet({ wallet, method, params }) {
  if (method === "personal_sign") {
    return wallet.signMessage(messageForPersonalSign(params[0]));
  }
  if (method === "eth_sign") {
    return wallet.signMessage(messageForPersonalSign(params[1]));
  }
  if (method === "eth_signTypedData" || method === "eth_signTypedData_v3" || method === "eth_signTypedData_v4") {
    const parts = typedDataParts(params[1]);
    return wallet.signTypedData(parts.domain, parts.types, parts.message);
  }
  throw new Error(`${method} is not supported by extension vault signing.`);
}

async function canSignWithExtensionVault(state, address) {
  if (!address) return false;
  try {
    const vaultRecord = await getDecryptedVaultRecord(state);
    return Boolean(vaultWalletByAddress(vaultRecord, address));
  } catch {
    return false;
  }
}

async function localAccountIsDappSignable(state, account) {
  if (!account || !account.address) return false;
  if ((account.signerType || "local") !== "local") return true;
  if (externalAuthorityWalletForAddress(state, account.address)) return true;
  if (localPassliAddressIsVaultControlled(state, account.address)) return true;
  return canSignWithExtensionVault(state, account.address);
}

async function connectionIsDappSignable(state, connection) {
  if (!connection || !connection.account || !connection.account.address) return false;
  if ((connection.signerType || connection.account.signerType || "local") !== "local") return true;
  if (externalAuthorityWalletForAddress(state, connection.account.address)) return true;
  if (localPassliAddressIsVaultControlled(state, connection.account.address)) return true;
  return canSignWithExtensionVault(state, connection.account.address);
}

function accountWithAvailableSigner(state, account) {
  if (!account || !account.address) return account;
  if ((account.signerType || "local") !== "local") return account;
  const authorityWallet = externalAuthorityWalletForAddress(state, account.address);
  if (!authorityWallet) return account;
  return {
    ...account,
    chainId: state.chainId,
    label: account.label || authorityWallet.label || "External wallet",
    sourceChainId: account.chainId || authorityWallet.chainId || "",
    signerType: "externalAuthority",
    type: account.type || "external-authority"
  };
}

function connectionWithAvailableSigner(state, connection) {
  if (!connection || !connection.account || !connection.account.address) return connection;
  const account = accountWithAvailableSigner(state, {
    ...connection.account,
    signerType: connection.account.signerType || connection.signerType || "local"
  });
  if (!account || account.signerType === (connection.signerType || connection.account.signerType || "local")) {
    return connection;
  }
  return {
    ...connection,
    signerType: account.signerType,
    account,
    accounts: Array.isArray(connection.accounts)
      ? connection.accounts.map((connectedAccount) => accountWithAvailableSigner(state, connectedAccount))
      : connection.accounts
  };
}

async function vaultBridgeFallback(context, error) {
  if (error?.noBridgeFallback) throw error;
  if (EXTENSION_VAULT_REQUIRED_METHODS.has(context.method)) {
    if (isVaultLockedError(error)) {
      await requestVaultUnlockNotice(context, error);
    }
    const message = `${context.method} requires Passli vault signing and cannot use the legacy passli.app bridge. Sign in with Passli, make sure the vault is unlocked, then retry.`;
    await appendLog({
      phase: "legacy-bridge:blocked",
      origin: context.origin,
      method: context.method,
      result: {
        address: context.address || "",
        blockedMethod: context.method,
        reason: error && error.message ? error.message : String(error || "vault signing unavailable")
      },
      error: message
    });
    const blocked = new Error(message);
    blocked.code = 4100;
    blocked.noBridgeFallback = true;
    throw blocked;
  }
  await appendLog({
    phase: "extension-vault:fallback-to-web-bridge",
    origin: context.origin,
    method: context.method,
    result: {
      address: context.address || "",
      fallbackSummary: context.fallbackSummary || "",
      reason: error && error.message ? error.message : String(error || "missing extension key vault")
    }
  });
  return bridgeThroughPassli(context);
}

function isVaultLockedError(error) {
  const message = String(error && error.message ? error.message : error || "");
  return (
    message.includes("vaultUnlockSecret is required") ||
    message.toLowerCase().includes("vault is locked") ||
    message.toLowerCase().includes("unlock the vault")
  );
}

if (WalletConnectBridge.onStatusChange) {
  WalletConnectBridge.onStatusChange((status) => {
    const patch = {
      walletConnectUri: "",
      walletConnectAccount: status.account || null,
      walletConnectWallet: status.wallet || null
    };

    setState(patch).catch(() => {});
    appendLog({
      phase: status.connected ? "walletconnect:session" : "walletconnect:session-ended",
      origin: "extension",
      method: "walletConnectStatusChange",
      result: status
    }).catch(() => {});
  });
}

if (WalletConnectBridge.onDebug) {
  WalletConnectBridge.onDebug((entry) => {
    appendLog({
      phase: entry.phase || "walletconnect-bridge",
      origin: "extension",
      method: entry.method || "WalletConnectBridge",
      result: entry
    }).catch(() => {});
  });
}

function parseSimpleYaml(text) {
  const result = {};
  for (const line of text.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const match = /^([A-Za-z0-9_-]+):\s*(.*)$/.exec(trimmed);
    if (!match) continue;
    result[match[1]] = match[2].replace(/^["']|["']$/g, "").trim();
  }
  return result;
}

function configString(config, key, fallback = "") {
  return String(config && config[key] !== undefined ? config[key] : fallback).trim();
}

function normalizeHyperliquidChain(value, fallback = DEFAULT_STATE.hyperliquidChain) {
  const normalized = String(value || fallback || "").trim().toLowerCase();
  return normalized === "testnet" ? "Testnet" : "Mainnet";
}

function signatureChainIdForHyperliquidChain(hyperliquidChain) {
  return normalizeHyperliquidChain(hyperliquidChain) === "Testnet" ? "0x3e6" : "0xa4b1";
}

function passliSessionSignerMetadata(session) {
  return {
    cloudSignerAddress: String(session?.cloudSignerAddress || "").trim(),
    hlMultisigSignerAddress: String(session?.hlMultisigSignerAddress || "").trim()
  };
}

function enrichPassliSelectedWallet(selectedWallet, session) {
  const metadata = passliSessionSignerMetadata(session);
  const base = selectedWallet && typeof selectedWallet === "object"
    ? selectedWallet
    : {};
  return {
    ...base,
    accountId: String(base.accountId || session?.accountId || ""),
    cloudSignerAddress: String(base.cloudSignerAddress || metadata.cloudSignerAddress || ""),
    hlMultisigSignerAddress: String(base.hlMultisigSignerAddress || metadata.hlMultisigSignerAddress || ""),
    label: String(base.label || session?.alias || "Passli"),
    type: base.type || "passli-account"
  };
}

function passliAddressId(address) {
  if (!address || typeof address !== "object") return "";
  const chainId = String(address.chainId || "").trim();
  const value = String(address.address || "").trim();
  if (!chainId || !value) return "";
  return `${chainId}:${value}`.toLowerCase();
}

function normalizePassliCryptoAddress(address, fallbackAccountId = "") {
  if (!address || typeof address !== "object" || !address.address || !address.chainId) return null;
  const sourceChainId = String(address.chainId || "").trim();
  const sourceChainName = String(address.chainName || address.chain || "Chain").trim();
  const sourceRole = String(address.sourceRole || "");
  const isHyperliquid = sourceChainId.toLowerCase() === "hyperliquid:core:mainnet" ||
    sourceChainId.toLowerCase() === "0x3e7" ||
    /^hyperliquid\s+(core|evm)$/i.test(sourceChainName);
  const normalized = {
    accountId: String(address.accountId || fallbackAccountId || ""),
    address: String(address.address || "").trim(),
    chainId: isHyperliquid ? "0x3e7" : sourceChainId,
    chainName: sourceRole ? sourceChainName : isHyperliquid ? "Hyperliquid" : sourceChainName
  };
  return {
    ...address,
    ...normalized,
    hyperliquidMultisigEligible: address.hyperliquidMultisigEligible !== false,
    sourceRole,
    id: String(address.id || passliAddressId(normalized))
  };
}

function normalizePassliCryptoAddresses(addresses, fallbackAccountId = "") {
  const seen = new Set();
  const result = [];
  for (const address of Array.isArray(addresses) ? addresses : []) {
    const normalized = normalizePassliCryptoAddress(address, fallbackAccountId);
    if (!normalized || !normalized.id || seen.has(normalized.id)) continue;
    seen.add(normalized.id);
    result.push(normalized);
  }
  return result;
}

function passliSignerCryptoAddressesForState(state) {
  const accountId = state.passliExtensionAccountId || "";
  return normalizePassliCryptoAddresses([
    {
      accountId,
      address: state.passliExtensionCloudSignerAddress || state.passliSelectedWallet?.cloudSignerAddress || "",
      chainId: "0x3e7",
      chainName: "HyperLiq MS Vault Signer",
      hyperliquidMultisigEligible: false,
      sourceRole: "vault-signer"
    },
    {
      accountId,
      address: state.passliExtensionHlMultisigSignerAddress || state.passliSelectedWallet?.hlMultisigSignerAddress || "",
      chainId: "0x3e7",
      chainName: "HyperLiq MS User Signer",
      hyperliquidMultisigEligible: false,
      sourceRole: "user-signer"
    }
  ], accountId);
}

function passliCryptoAddressesForState(state) {
  return normalizePassliCryptoAddresses([
    ...normalizePassliCryptoAddresses(state.passliCryptoAddresses, state.passliExtensionAccountId),
    ...passliSignerCryptoAddressesForState(state)
  ], state.passliExtensionAccountId);
}

function selectedPassliAddressForState(state) {
  return selectedSyncedPassliAddress(passliCryptoAddressesForState(state), state);
}

function passliAddressIsHyperliquid(address) {
  if (!address) return false;
  if (address.hyperliquidMultisigEligible === false) return false;
  const chainId = String(address.chainId || "").trim().toLowerCase();
  const chainName = String(address.chainName || address.chain || "").trim().toLowerCase();
  return chainId === "0x3e7" || chainName === "hyperliquid";
}

function passliWalletFromCryptoAddress(address, state) {
  if (!address) return null;
  return {
    accountId: address.accountId || state.passliExtensionAccountId || "",
    address: address.address,
    chainId: address.chainId,
    label: `${address.chainName || "Chain"} ${shortAddress(address.address)}`,
    signerType: "local",
    type: "passli-vault-address",
    walletId: 1,
    walletName: address.chainName || "Vault address"
  };
}

function passliAddressOptionLabel(address) {
  return `${address.chainName || "Chain"} ${shortAddress(address.address)}`;
}

function selectedSyncedPassliAddress(addresses, state, incomingSelectedId = "") {
  const normalizedAddresses = (Array.isArray(addresses) ? addresses : []).filter((address) => address.sourceRole !== "vault-signer" && address.sourceRole !== "user-signer");
  const currentSelectedId = String(state && state.selectedPassliAddressId || "");
  const incomingId = String(incomingSelectedId || "");
  const preferred = normalizedAddresses.find((address) => String(address.chainId || "") === "0x3e7") ||
    normalizedAddresses.find((address) => isEvmProviderChainId(address.chainId)) ||
    normalizedAddresses[0] ||
    null;
  return normalizedAddresses.find((address) => address.id === currentSelectedId) ||
    normalizedAddresses.find((address) => address.id === incomingId) ||
    preferred;
}

function passliSelectionStateForSync(state, addresses, sessionOrAccountId = "") {
  const session = sessionOrAccountId && typeof sessionOrAccountId === "object"
    ? sessionOrAccountId
    : {};
  const accountId = String(session.accountId || sessionOrAccountId || state.passliExtensionAccountId || "");
  return {
    ...state,
    passliCryptoAddresses: addresses,
    passliExtensionAccountId: accountId,
    passliExtensionCloudSignerAddress: String(
      state.passliExtensionCloudSignerAddress ||
      session.cloudSignerAddress ||
      session.selectedWallet?.cloudSignerAddress ||
      ""
    ),
    passliExtensionHlMultisigSignerAddress: String(
      state.passliExtensionHlMultisigSignerAddress ||
      session.hlMultisigSignerAddress ||
      session.selectedWallet?.hlMultisigSignerAddress ||
      ""
    ),
    passliSelectedWallet: state.passliSelectedWallet || session.selectedWallet || null
  };
}

function localPassliAddressIsVaultControlled(state, address) {
  if (!address) return false;
  return passliCryptoAddressesForState(state)
    .some((entry) => sameAddressOrExact(entry.address, address));
}

function sameAddressOrExact(left, right) {
  const leftValue = String(left || "");
  const rightValue = String(right || "");
  if (!leftValue || !rightValue) return false;
  if (/^0x[a-fA-F0-9]{40}$/.test(leftValue) && /^0x[a-fA-F0-9]{40}$/.test(rightValue)) {
    return leftValue.toLowerCase() === rightValue.toLowerCase();
  }
  return leftValue === rightValue;
}

function shortAddress(address) {
  const value = String(address || "");
  return value.length > 14 ? `${value.slice(0, 8)}...${value.slice(-6)}` : value;
}

async function refreshVaultCryptoAddressesForSession(session, selectedAddressId = "") {
  if (!session || !session.accountId) return [];
  const url = new URL("/vault/v1/crypto_addresses", PASSLI_API_URL);
  const response = await fetch(url.toString(), { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ userId: session.accountId }) });
  const text = await response.text();
  let payload = {};
  if (text) {
    try {
      payload = JSON.parse(text);
    } catch {
      payload = {};
    }
  }
  if (!response.ok) {
    throw new Error(payload.error || `Vault address sync failed: ${response.status}`);
  }
  const addresses = normalizePassliCryptoAddresses(payload.addresses && payload.addresses.crypto_addresses, session.accountId);
  const stored = await chrome.storage.local.get({
    selectedPassliAddressId: "",
    passliExtensionAccountId: "",
    passliExtensionCloudSignerAddress: "",
    passliExtensionHlMultisigSignerAddress: "",
    passliSelectedWallet: null
  });
  const selectionState = passliSelectionStateForSync(stored, addresses, session);
  const selectableAddresses = passliCryptoAddressesForState(selectionState);
  const selected = selectedSyncedPassliAddress(selectableAddresses, stored, selectedAddressId);
  await setState({
    passliCryptoAddresses: addresses,
    passliSelectedWallet: passliWalletFromCryptoAddress(selected, {
      ...selectionState,
      passliExtensionAccountId: session.accountId
    }),
    selectedPassliAddressId: selected ? selected.id : ""
  });
  return addresses;
}

async function clearPassliVaultAddressSelection() {
  await setState({
    passliCryptoAddresses: [],
    passliSelectedWallet: null,
    selectedPassliAddressId: ""
  });
}

function stableJson(value) {
  try {
    return JSON.stringify(value || null);
  } catch {
    return "";
  }
}

function sameStoredPassliAuthState(stored, session, selectedWallet, origin) {
  return (
    stored.passliExtensionLoggedIn === true &&
    String(stored.passliExtensionAccountId || "") === String(session.accountId || "") &&
    String(stored.passliExtensionAlias || "") === String(session.alias || "") &&
    String(stored.passliExtensionCloudSignerAddress || "") === String(selectedWallet?.cloudSignerAddress || session.cloudSignerAddress || "") &&
    String(stored.passliExtensionCredentialId || "") === String(session.credentialId || "") &&
    String(stored.passliExtensionDeviceId || "") === String(session.deviceId || "") &&
    String(stored.passliExtensionHlMultisigSignerAddress || "") === String(selectedWallet?.hlMultisigSignerAddress || session.hlMultisigSignerAddress || "") &&
    String(stored.passliExtensionAuthOrigin || "") === String(origin || "") &&
    stableJson(stored.passliSelectedWallet) === stableJson(selectedWallet)
  );
}

async function getExtensionConfig() {
  if (!extensionConfigPromise) {
    extensionConfigPromise = fetch(chrome.runtime.getURL("config.yaml"))
      .then((response) => {
        if (!response.ok) {
          throw new Error(`Could not load extension config: ${response.status}`);
        }
        return response.text();
      })
      .then(parseSimpleYaml);
  }
  return extensionConfigPromise;
}

function demoAccountFromConfig(config) {
  return {
    address: configString(
      config,
      "demoAccountAddress",
      configString(config, "demoAccountPublicKey", DEFAULT_STATE.address)
    ),
    privateKey: configString(config, "demoAccountPrivateKey", DEFAULT_STATE.privateKey)
  };
}

function redactForLog(value) {
  if (typeof value === "bigint") {
    return value.toString();
  }
  if (typeof value === "string" && /^0x[a-fA-F0-9]{64}$/.test(value)) {
    return `${value.slice(0, 10)}...${value.slice(-6)}`;
  }
  if (typeof value === "string" && /^0x[a-fA-F0-9]{80,}$/.test(value)) {
    return `${value.slice(0, 10)}...${value.slice(-10)}`;
  }
  if (Array.isArray(value)) {
    return value.map(redactForLog);
  }
  if (value && typeof value === "object") {
    return Object.fromEntries(
      Object.entries(value).map(([key, entry]) => {
        if (/privatekey|secret|seed|keymaterial/i.test(key)) return [key, "[redacted]"];
        return [key, redactForLog(entry)];
      })
    );
  }
  return value;
}

let logWriteQueue = Promise.resolve();
function queueLogWrite(work) {
  const result = logWriteQueue.then(work);
  logWriteQueue = result.catch(() => {});
  return result;
}
function appendLog(entry) {
  return queueLogWrite(() => persistLogEntry(entry));
}
async function persistLogEntry(entry) {
  const stored = await chrome.storage.local.get({ debugLog: [] });
  const now = Date.now();
  const nextEntry = {
    id: `${now}-${Math.random().toString(16).slice(2)}`,
    time: new Date(now).toISOString(),
    ...redactForLog(entry)
  };
  const coalesceIndex = findCoalescibleLogEntry(stored.debugLog, nextEntry, now);
  if (coalesceIndex !== -1) {
    const previous = stored.debugLog[coalesceIndex];
    const count = Number(previous.count || 1) + 1;
    const debugLog = [
      ...stored.debugLog.slice(0, coalesceIndex),
      {
        ...previous,
        time: nextEntry.time,
        count,
        repeated: count,
        lastRepeatedAt: nextEntry.time
      },
      ...stored.debugLog.slice(coalesceIndex + 1)
    ];
    await chrome.storage.local.set({ debugLog });
    return;
  }

  const debugLog = [
    ...stored.debugLog,
    nextEntry
  ].slice(-MAX_LOG_ENTRIES);

  await chrome.storage.local.set({ debugLog });
}

function findCoalescibleLogEntry(debugLog, nextEntry, now) {
  for (let index = debugLog.length - 1; index >= 0; index -= 1) {
    const entry = debugLog[index];
    const entryTime = Date.parse(entry && entry.time ? entry.time : "");
    if (!Number.isFinite(entryTime) || now - entryTime > LOG_COALESCE_WINDOW_MS) break;
    if (shouldCoalesceLogEntry(entry, nextEntry, now)) return index;
  }
  return -1;
}

function shouldCoalesceLogEntry(previous, nextEntry, now) {
  if (!previous || previous.method !== nextEntry.method || previous.origin !== nextEntry.origin) return false;
  if (previous.phase !== nextEntry.phase) return false;
  const previousTime = Date.parse(previous.time || "");
  if (!Number.isFinite(previousTime) || now - previousTime > LOG_COALESCE_WINDOW_MS) return false;
  return stableLogValue(previous.params) === stableLogValue(nextEntry.params) &&
    stableLogValue(previous.result) === stableLogValue(nextEntry.result) &&
    stableLogValue(previous.error) === stableLogValue(nextEntry.error);
}

function stableLogValue(value) {
  if (value === undefined) return "";
  try {
    return JSON.stringify(value, (_key, entry) => typeof entry === "bigint" ? entry.toString() : entry);
  } catch {
    return String(value);
  }
}

async function getState() {
  const config = await getExtensionConfig();
  const stored = await chrome.storage.local.get(null);
  const demo = demoAccountFromConfig(config);
  const state = {
    ...DEFAULT_STATE,
    ...stored,
    privateKey: stored.privateKey || demo.privateKey,
    address: stored.address || demo.address,
    walletConnectProjectId: config.walletConnectProjectId || stored.walletConnectProjectId || "",
    connectedOrigins: stored.connectedOrigins || {},
    trustedDappOrigins: stored.trustedDappOrigins || {}
  };

  if (
    !stored.privateKey ||
    stored.address === "0x0000000000000000000000000000000000000abc" ||
    stored.chainId === "0x3e9"
  ) {
    state.privateKey = demo.privateKey;
    state.address = demo.address;
    state.chainId = DEFAULT_STATE.chainId;
    await setState({
      privateKey: state.privateKey,
      address: state.address,
      chainId: state.chainId
    });
  }

  // Older settings can retain externalAuthority mode after its wallet is gone,
  // while the popup displays the synced Passli selection. Repair only an
  // orphaned mode; an explicitly selected external wallet must still fail closed.
  if (
    state.signingMode === "externalAuthority" &&
    !state.selectedExternalAuthorityWalletId &&
    !externalAuthorityWalletsForState(state).length &&
    state.passliExtensionLoggedIn &&
    state.selectedPassliAddressId &&
    selectedPassliAddressForState(state)?.id === state.selectedPassliAddressId
  ) {
    state.signingMode = "local";
    await setState({ signingMode: state.signingMode });
  }

  return state;
}

async function setState(patch) {
  await chrome.storage.local.set(patch);
}

function normalizeAddress(address) {
  const value = String(address || "").trim();
  if (!/^0x[a-fA-F0-9]{40}$/.test(value)) {
    throw new Error("Address must be a 20-byte hex address, like 0x1234...");
  }
  return value;
}

function normalizeOptionalAddress(address, label) {
  if (address === undefined || address === null || address === "") return null;
  try {
    return normalizeAddress(address);
  } catch {
    throw new Error(`${label} must be a 20-byte hex address, like 0x1234...`);
  }
}

function originFromSender(sender) {
  try {
    return new URL(sender.url || sender.origin || "").origin;
  } catch {
    return "unknown";
  }
}

function tabIdFromSender(sender) {
  return sender && sender.tab && Number.isInteger(sender.tab.id) ? sender.tab.id : null;
}

function tabIdFromConnectionKey(key) {
  const match = /^tab:(\d+)$/.exec(String(key || ""));
  if (!match) return null;
  const tabId = Number(match[1]);
  return Number.isSafeInteger(tabId) ? tabId : null;
}

function isTabConnectionKey(value) {
  return /^tab:\d+$/.test(String(value || ""));
}

async function originFromTabId(tabId) {
  if (!chrome.tabs || !Number.isInteger(tabId)) return "";
  try {
    const tab = await chrome.tabs.get(tabId);
    return new URL(tab.url || "").origin;
  } catch {
    return "";
  }
}

function connectionKeyFromSender(sender, origin) {
  const tabId = tabIdFromSender(sender);
  return tabId === null ? origin : `tab:${tabId}`;
}

function unsupported(method) {
  return {
    code: 4200,
    message: `${method} is not implemented by Passli Safe Wallet`
  };
}

function providerError(error, fallbackCode = 4001, fallbackMessage = "Request failed.") {
  return {
    code: error && error.code ? error.code : fallbackCode,
    message: error && error.message ? error.message : fallbackMessage,
    data: error && error.data ? error.data : undefined
  };
}

function normalizeHexPrivateKey(privateKey) {
  const value = String(privateKey || "").trim();
  if (!/^0x[a-fA-F0-9]{64}$/.test(value)) {
    throw new Error("Invalid demo private key");
  }
  return value;
}

function sameAddress(left, right) {
  return String(left || "").toLowerCase() === String(right || "").toLowerCase();
}

function connectionMatchesPreferredAddress(account, preferredAddress) {
  return !preferredAddress || (account && account.address && sameAddress(account.address, preferredAddress));
}

function uniqueAccounts(accounts) {
  const seen = new Set();
  const result = [];
  for (const account of accounts || []) {
    if (!account || !account.address) continue;
    const key = accountKey(account.address);
    if (!key || seen.has(key)) continue;
    seen.add(key);
    result.push({
      ...account,
      address: account.address
    });
  }
  return result;
}

function requestedAddressForSigning(method, params) {
  if (method === "personal_sign") return params[1] || "";
  if (method === "eth_sendTransaction") return params[0] && params[0].from ? params[0].from : "";
  if (method === "eth_sign" || method === "eth_signTypedData" || method === "eth_signTypedData_v3" || method === "eth_signTypedData_v4") {
    return params[0] || "";
  }
  return "";
}

function normalizeHyperliquidAuthorizeActionRequest(params, activeAccount) {
  const request = params[0] && typeof params[0] === "object" ? params[0] : null;
  if (!request) {
    throw new Error("hyperliquid_authorizeAction requires a request object as params[0].");
  }

  const account = normalizeAddress(request.account || activeAccount.address);
  const hyperliquidChain = normalizeHyperliquidChain(request.hyperliquidChain);
  const actionSignatureChainId = request.action && typeof request.action === "object"
    ? request.action.signatureChainId
    : "";
  const signatureChainId = normalizeChainIdHex(
    request.signatureChainId || actionSignatureChainId || signatureChainIdForHyperliquidChain(hyperliquidChain)
  );
  const submitMode = request.submitMode || "walletSubmit";
  const noncePolicy = request.noncePolicy || "dapp";
  if (submitMode !== "walletSubmit" && submitMode !== "returnSignedAction") {
    throw new Error("submitMode must be walletSubmit or returnSignedAction.");
  }
  if (noncePolicy !== "dapp" && noncePolicy !== "wallet") {
    throw new Error("noncePolicy must be dapp or wallet.");
  }
  if (!request.action || typeof request.action !== "object" || Array.isArray(request.action)) {
    throw new Error("action must be an unsigned Hyperliquid action object.");
  }

  const action = { ...request.action };
  let nonce = request.nonce;
  if (noncePolicy === "wallet") {
    nonce = Date.now();
    if (action.nonce !== undefined) action.nonce = nonce;
  }
  if (noncePolicy === "dapp" && nonce === undefined && action.nonce !== undefined) {
    nonce = action.nonce;
  }
  nonce = Number(nonce);
  if (!Number.isSafeInteger(nonce) || nonce <= 0) {
    throw new Error("nonce must be a positive millisecond timestamp.");
  }

  const expiresAfter = request.expiresAfter === undefined || request.expiresAfter === null || request.expiresAfter === ""
    ? undefined
    : Number(request.expiresAfter);
  if (expiresAfter !== undefined && (!Number.isSafeInteger(expiresAfter) || expiresAfter <= 0)) {
    throw new Error("expiresAfter must be a positive millisecond timestamp.");
  }

  return {
    type: request.type || "hyperliquid.authorizeAction.v1",
    requestId: request.requestId || "",
    account,
    hyperliquidChain,
    signatureChainId,
    action,
    vaultAddress: normalizeOptionalAddress(request.vaultAddress, "vaultAddress") || undefined,
    submitMode,
    noncePolicy,
    nonce,
    expiresAfter,
    expiresAt: request.expiresAt || "",
    humanSummary: request.humanSummary || null
  };
}

function hyperliquidActionTypeFromParams(params) {
  const request = Array.isArray(params) && params[0] && typeof params[0] === "object"
    ? params[0]
    : null;
  const action = request && request.action && typeof request.action === "object"
    ? request.action
    : null;
  return action && typeof action.type === "string" ? action.type : "";
}

function isHyperliquidCancelActionType(actionType) {
  return actionType === "cancel" || actionType === "cancelByCloid";
}

function accountKey(address) {
  return String(address || "").toLowerCase();
}

function connectedAccountsForOrigin(connectedOrigins, origin, state) {
  const entry = connectedOrigins && connectedOrigins[origin];
  if (!entry) return {};

  if (entry === true) {
    const selectedAddress = selectedPassliAddressForState(state);
    const selectedWallet = selectedAddress && selectedAddress.address
      ? passliWalletFromCryptoAddress(selectedAddress, state)
      : null;
    const key = accountKey(selectedWallet && selectedWallet.address);
    return key ? {
      [key]: {
        address: selectedWallet.address,
        chainId: selectedWallet.chainId || state.chainId,
        legacy: true,
        signerType: "local",
        type: selectedWallet.type || "passli-account"
      }
    } : {};
  }

  if (entry && typeof entry === "object") {
    if (entry.account && entry.account.address) {
      return {
        [accountKey(entry.account.address)]: {
          ...entry.account,
          signerType: entry.signerType || entry.account.signerType || "local",
          tabId: entry.tabId,
          origin: entry.origin || origin
        }
      };
    }

    if (entry.accounts && typeof entry.accounts === "object") {
      return entry.accounts;
    }

    return Object.fromEntries(
      Object.entries(entry)
        .filter(([, value]) => value === true || (value && typeof value === "object"))
        .map(([key, value]) => [
          accountKey(key),
          value === true ? { address: key } : { address: value.address || key, ...value }
        ])
    );
  }

  return {};
}

function isOriginConnectedForAccount(connectedOrigins, origin, address, state) {
  const key = accountKey(address);
  if (!key) return false;
  return Boolean(connectedAccountsForOrigin(connectedOrigins, origin, state)[key]);
}

function connectOriginForAccount(connectedOrigins, origin, account, signerType, state) {
  const key = accountKey(account.address);
  const currentAccounts = connectedAccountsForOrigin(
    connectedOrigins,
    origin,
    state || { address: account.address }
  );
  return {
    ...connectedOrigins,
    [origin]: {
      accounts: {
        ...currentAccounts,
        [key]: {
          address: account.address,
          chainId: account.chainId || "",
          signerType,
          connectedAt: new Date().toISOString()
        }
      }
    }
  };
}

function revokeOriginForAccount(connectedOrigins, origin, address, state) {
  const accounts = { ...connectedAccountsForOrigin(connectedOrigins, origin, state) };
  delete accounts[accountKey(address)];

  if (!Object.keys(accounts).length) {
    const next = { ...connectedOrigins };
    delete next[origin];
    return next;
  }

  return {
    ...connectedOrigins,
    [origin]: { accounts }
  };
}

function listOriginsForAccount(connectedOrigins, address, state) {
  return Object.keys(connectedOrigins || {})
    .filter((origin) => isOriginConnectedForAccount(connectedOrigins, origin, address, state))
    .sort();
}

function trustedConnectionForOrigin(state, origin, preferredAccount) {
  const trusted = state.trustedDappOrigins && state.trustedDappOrigins[origin];
  if (!trusted || !trusted.account || !trusted.account.address) return null;
  const accounts = uniqueAccounts(
    (Array.isArray(trusted.accounts) && trusted.accounts.length ? trusted.accounts : [trusted.account])
      .filter((account) => account && account.address)
      .map((account) => ({
        ...account,
        chainId: account.chainId || state.chainId,
        signerType: account.signerType || trusted.signerType || "local"
      }))
  );
  if (!accounts.length) return null;
  const preferredTrustedAccount = preferredAccount && preferredAccount.address
    ? accounts.find((account) => sameAddress(account.address, preferredAccount.address))
    : null;
  if (
    preferredAccount &&
    preferredAccount.address &&
    !preferredTrustedAccount
  ) {
    return null;
  }

  const primaryAccount = preferredTrustedAccount || accounts[0];
  return {
    origin,
    signerType: primaryAccount.signerType || trusted.signerType || "local",
    account: {
      address: primaryAccount.address,
      chainId: primaryAccount.chainId || state.chainId,
      signerType: primaryAccount.signerType || trusted.signerType || "local"
    },
    accounts,
    trustedAt: trusted.trustedAt || ""
  };
}

function trustOriginForAccount(trustedDappOrigins, origin, account, signerType) {
  return trustOriginForAccounts(trustedDappOrigins, origin, [account], signerType);
}

function trustOriginForAccounts(trustedDappOrigins, origin, accounts, signerType) {
  const normalizedAccounts = uniqueAccounts((accounts || []).filter((account) => account && account.address));
  const primaryAccount = normalizedAccounts[0];
  if (!primaryAccount) return trustedDappOrigins || {};
  return {
    ...(trustedDappOrigins || {}),
    [origin]: {
      origin,
      signerType: primaryAccount.signerType || signerType,
      account: {
        address: primaryAccount.address,
        chainId: primaryAccount.chainId || "",
        signerType: primaryAccount.signerType || signerType
      },
      accounts: normalizedAccounts.map((account) => ({
        address: account.address,
        chainId: account.chainId || "",
        signerType: account.signerType || signerType || "local",
        label: account.label || "",
        type: account.type || ""
      })),
      trustedAt: new Date().toISOString()
    }
  };
}

function revokeTrustedOrigin(trustedDappOrigins, origin) {
  const next = { ...(trustedDappOrigins || {}) };
  delete next[origin];
  return next;
}

function selectedWalletForState(state) {
  if (state.signingMode === "externalAuthority") {
    const wallet = selectedExternalAuthorityWalletForState(state);
    if (wallet && wallet.address) {
      return {
        type: "external-authority",
        signerType: "externalAuthority",
        address: wallet.address,
        chainId: state.chainId,
        sourceChainId: wallet.chainId || "",
        label: wallet.label || "External wallet"
      };
    }
  }

  if (state.signingMode === "walletconnect" && state.walletConnectAccount && state.walletConnectAccount.address) {
    return {
      type: "walletconnect",
      address: state.walletConnectAccount.address,
      chainId: state.chainId,
      label: state.walletConnectLabel || state.walletConnectWallet?.name || "WalletConnect",
      sourceChainId: state.walletConnectAccount.chainId || ""
    };
  }

  const selectedAddress = selectedPassliAddressForState(state);
  if (selectedAddress && selectedAddress.address) {
    return passliWalletFromCryptoAddress(selectedAddress, state);
  }

  return null;
}

function selectedAddressStatusForState(state) {
  const selectedAddress = selectedPassliAddressForState(state);
  if (!selectedAddress) return null;
  return {
    id: selectedAddress.id,
    accountId: selectedAddress.accountId || state.passliExtensionAccountId || "",
    address: selectedAddress.address,
    chain: selectedAddress.chainName || "Chain",
    chainId: selectedAddress.chainId,
    chainName: selectedAddress.chainName || "Chain"
  };
}

function normalizeConnectionRecord(key, entry, fallbackOrigin, state, preferredAddress = "") {
  if (!entry) return null;

  if (entry === true) {
    const selectedAddress = selectedPassliAddressForState(state);
    const selectedWallet = selectedAddress && selectedAddress.address
      ? passliWalletFromCryptoAddress(selectedAddress, state)
      : null;
    if (!selectedWallet || !connectionMatchesPreferredAddress(selectedWallet, preferredAddress)) return null;
    return {
      key,
      origin: fallbackOrigin,
      tabId: null,
      signerType: "local",
      account: {
        address: selectedWallet.address,
        chainId: selectedWallet.chainId || state.chainId
      },
      legacy: true
    };
  }

  if (entry.account && entry.account.address) {
    if (!connectionMatchesPreferredAddress(entry.account, preferredAddress)) return null;
    return {
      key,
      origin: entry.origin || fallbackOrigin,
      tabId: Number.isInteger(entry.tabId) ? entry.tabId : tabIdFromConnectionKey(key),
      signerType: entry.signerType || entry.account.signerType || "local",
      account: {
        address: entry.account.address,
        chainId: entry.account.chainId || state.chainId
      },
      connectedAt: entry.connectedAt || "",
      legacy: Boolean(entry.legacy)
    };
  }

  const accounts = connectedAccountsForOrigin({ [fallbackOrigin]: entry }, fallbackOrigin, state);
  const preferredKey = accountKey(preferredAddress);
  const accountEntry = preferredKey ? accounts[preferredKey] : Object.values(accounts)[0];
  if (!accountEntry || !accountEntry.address) return null;

  return {
    key,
    origin: fallbackOrigin,
    tabId: Number.isInteger(entry.tabId) ? entry.tabId : tabIdFromConnectionKey(key),
    signerType: accountEntry.signerType || "local",
    account: {
      address: accountEntry.address,
      chainId: accountEntry.chainId || state.chainId
    },
    connectedAt: accountEntry.connectedAt || "",
    legacy: true
  };
}

function connectionAccountListFromRecord(entry, fallbackOrigin, state) {
  if (!entry) return [];
  const accounts = connectedAccountsForOrigin({ [fallbackOrigin]: entry }, fallbackOrigin, state);
  const order = Array.isArray(entry.accountOrder) ? entry.accountOrder.map(accountKey) : [];
  const orderedAccounts = [
    ...order.map((key) => accounts[key]).filter(Boolean),
    ...Object.entries(accounts)
      .filter(([key]) => !order.includes(accountKey(key)))
      .map(([, account]) => account)
  ];
  return uniqueAccounts(orderedAccounts.map((account) => ({
    address: account.address,
    chainId: account.chainId || state.chainId,
    signerType: account.signerType || entry.signerType || "local",
    connectedAt: account.connectedAt || entry.connectedAt || ""
  })));
}

function connectionAccountsForSender(state, sender, origin) {
  const key = connectionKeyFromSender(sender, origin);
  const byKey = connectionAccountListFromRecord(
    state.connectedOrigins && state.connectedOrigins[key],
    origin,
    state
  );
  if (byKey.length) return byKey;

  return connectionAccountListFromRecord(
    state.connectedOrigins && state.connectedOrigins[origin],
    origin,
    state
  );
}

function connectionForSender(state, sender, origin, preferredAccount) {
  const key = connectionKeyFromSender(sender, origin);
  const byKey = normalizeConnectionRecord(
    key,
    state.connectedOrigins && state.connectedOrigins[key],
    origin,
    state,
    preferredAccount && preferredAccount.address
  );
  if (byKey) return byKey;

  return normalizeConnectionRecord(
    origin,
    state.connectedOrigins && state.connectedOrigins[origin],
    origin,
    state,
    preferredAccount && preferredAccount.address
  );
}

function accountFromAdvertisedWallet(wallet) {
  if (!wallet || !wallet.address) return null;
  return {
    address: wallet.address,
    chainId: wallet.chainId || "",
    signerType: wallet.signerType || "local",
    label: wallet.label || "",
    type: wallet.type || ""
  };
}

function walletSelectionKey(wallet) {
  if (!wallet || !wallet.address) return "";
  return [
    String(wallet.signerType || "local"),
    String(wallet.type || ""),
    String(wallet.chainId || ""),
    accountKey(wallet.address)
  ].join(":");
}

function walletWithSelectionKey(wallet) {
  return {
    ...wallet,
    selectionKey: walletSelectionKey(wallet)
  };
}

async function advertisableWalletsForState(state) {
  const wallets = [];
  if (state.signingMode === "externalAuthority") {
    const wallet = selectedExternalAuthorityWalletForState(state);
    if (wallet && wallet.address) {
        wallets.push({
          type: "external-authority",
          signerType: "externalAuthority",
          address: wallet.address,
          chainId: state.chainId,
          label: wallet.label || "External wallet",
          sourceChainId: wallet.chainId || "",
          selected: true
        });
    }
    return uniqueAccounts(wallets).map((wallet) => walletWithSelectionKey({
      ...wallet,
      selected: Boolean(wallet.selected)
    }));
  }

  if (state.signingMode === "walletconnect") {
    if (state.walletConnectProjectId) {
      const status = await walletConnectStatus(state).catch(() => null);
      const account = status && status.connected && status.account && status.account.address
        ? status.account
        : state.walletConnectAccount;
      if (account && account.address) {
        wallets.push({
          type: "walletconnect",
          signerType: "walletconnect",
          address: account.address,
          chainId: state.chainId,
          label: state.walletConnectLabel || state.walletConnectWallet?.name || "WalletConnect",
          sourceChainId: account.chainId || "",
          selected: true
        });
      }
    }
    return uniqueAccounts(wallets).map((wallet) => walletWithSelectionKey({
      ...wallet,
      selected: Boolean(wallet.selected)
    }));
  }

  const address = selectedPassliAddressForState(state);
  if (address && address.address) {
    const isControlled =
      localPassliAddressIsVaultControlled(state, address.address) ||
      await canSignWithExtensionVault(state, address.address);
    if (!isControlled) return [];
    wallets.push({
      type: "passli-vault-address",
      signerType: "local",
      address: address.address,
      chainId: evmProviderCompatibleAccount(address, state)?.chainId || address.chainId,
      label: passliAddressOptionLabel(address),
      sourceChainId: address.chainId,
      selected: true
    });
  }

  return uniqueAccounts(wallets).map((wallet) => walletWithSelectionKey({
    ...wallet,
    selected: Boolean(wallet.selected)
  }));
}

function approvedAccountsFromSelection(availableWallets, selectedAddresses) {
  const selected = new Set((selectedAddresses || []).map(accountKey).filter(Boolean));
  const selectedKeys = new Set((selectedAddresses || []).map(String).filter(Boolean));
  const chosen = availableWallets.filter((wallet) =>
    selectedKeys.has(wallet.selectionKey || walletSelectionKey(wallet)) ||
    selected.has(accountKey(wallet.address))
  );
  return uniqueAccounts(chosen.map(accountFromAdvertisedWallet));
}

function accountForRequestedAddress(connectedAccounts, requestedAddress, fallbackAccount, fallbackSignerType) {
  if (requestedAddress) {
    const connectedMatch = (connectedAccounts || []).find((account) => sameAddress(account.address, requestedAddress));
    if (connectedMatch) return connectedMatch;
    if (!connectedAccounts || !connectedAccounts.length) {
      return {
        ...fallbackAccount,
        signerType: fallbackAccount.signerType || fallbackSignerType || "local"
      };
    }
    return null;
  }

  return {
    ...fallbackAccount,
    signerType: fallbackAccount.signerType || fallbackSignerType || "local"
  };
}

function connectSenderToAccount(connectedOrigins, sender, origin, account, signerType) {
  const key = connectionKeyFromSender(sender, origin);
  const next = { ...(connectedOrigins || {}) };
  delete next[origin];
  next[key] = {
    origin,
    tabId: tabIdFromSender(sender),
    signerType,
    account: {
      address: account.address,
      chainId: account.chainId || ""
    },
    connectedAt: new Date().toISOString()
  };
  return next;
}

function connectSenderToAccounts(connectedOrigins, sender, origin, accounts) {
  const normalizedAccounts = uniqueAccounts(accounts);
  const key = connectionKeyFromSender(sender, origin);
  const next = { ...(connectedOrigins || {}) };
  delete next[origin];
  next[key] = {
    origin,
    tabId: tabIdFromSender(sender),
    accounts: Object.fromEntries(
      normalizedAccounts.map((account) => [
        accountKey(account.address),
        {
          address: account.address,
          chainId: account.chainId || "",
          signerType: account.signerType || "local",
          label: account.label || "",
          type: account.type || "",
          connectedAt: new Date().toISOString()
        }
      ])
    ),
    accountOrder: normalizedAccounts.map((account) => account.address),
    connectedAt: new Date().toISOString()
  };
  return next;
}

function revokeSenderConnection(connectedOrigins, sender, origin) {
  const key = connectionKeyFromSender(sender, origin);
  const next = { ...(connectedOrigins || {}) };
  delete next[key];
  delete next[origin];
  return next;
}

function updateSenderConnectionChain(connectedOrigins, sender, origin, chainId) {
  const key = connectionKeyFromSender(sender, origin);
  const next = { ...(connectedOrigins || {}) };
  const entryKey = next[key] ? key : next[origin] ? origin : "";
  if (!entryKey) return next;

  const entry = next[entryKey];
  if (entry && entry.account && entry.account.address) {
    next[entryKey] = {
      ...entry,
      account: {
        ...entry.account,
        chainId
      }
    };
    return next;
  }

  if (entry && entry.accounts && typeof entry.accounts === "object") {
    next[entryKey] = {
      ...entry,
      accounts: Object.fromEntries(
        Object.entries(entry.accounts).map(([accountAddress, account]) => [
          accountAddress,
          account && typeof account === "object"
            ? { ...account, chainId }
            : account
        ])
      )
    };
    return next;
  }

  return next;
}

function listConnectionsForAccount(connectedOrigins, address, state) {
  const key = accountKey(address);
  if (!key) return [];

  return Object.entries(connectedOrigins || {})
    .map(([connectionKey, entry]) => normalizeConnectionRecord(connectionKey, entry, connectionKey, state, address))
    .filter((entry) => entry && accountKey(entry.account.address) === key)
    .sort((left, right) => {
      const originCompare = String(left.origin).localeCompare(String(right.origin));
      return originCompare || String(left.key).localeCompare(String(right.key));
    });
}

function listTrustedOriginsForAccount(trustedDappOrigins, address) {
  const key = accountKey(address);
  if (!key) return [];

  return Object.entries(trustedDappOrigins || {})
    .filter(([, entry]) => entry && entry.account && accountKey(entry.account.address) === key)
    .map(([origin, entry]) => ({
      key: `trusted:${origin}`,
      origin,
      tabId: null,
      signerType: entry.signerType || entry.account.signerType || "local",
      account: {
        address: entry.account.address,
        chainId: entry.account.chainId || ""
      },
      trusted: true,
      trustedAt: entry.trustedAt || ""
    }))
    .sort((left, right) => String(left.origin).localeCompare(String(right.origin)));
}

function mergeConnectionAndTrustLists(connections, trustedOrigins) {
  const activeOrigins = new Set(connections.map((connection) => connection.origin));
  return [
    ...connections,
    ...trustedOrigins.filter((trusted) => !activeOrigins.has(trusted.origin))
  ];
}

function messageForPersonalSign(value) {
  const message = String(value || "");
  if (/^0x([a-fA-F0-9]{2})*$/.test(message)) {
    return Ethers.getBytes(message);
  }
  return message;
}

function parseTypedData(value) {
  if (typeof value === "string") {
    return JSON.parse(value);
  }
  return value;
}

function typedDataParts(value) {
  const data = parseTypedData(value);
  const types = { ...(data.types || {}) };
  delete types.EIP712Domain;
  return {
    domain: data.domain || {},
    types,
    message: data.message || {}
  };
}

async function authorizeHyperliquidAction({ state, origin, method, params, activeAccount }) {
  if (!activeAccount || !activeAccount.address) {
    throw new Error("Connect an account before authorizing a Hyperliquid action.");
  }

  const request = normalizeHyperliquidAuthorizeActionRequest(params, activeAccount);
  if (!sameAddress(request.account, activeAccount.address)) {
    const error = new Error("Requested account is not connected to this dApp session.");
    error.code = 4100;
    throw error;
  }

  if (request.expiresAt) {
    const expiresAtMs = Date.parse(request.expiresAt);
    if (Number.isFinite(expiresAtMs) && expiresAtMs <= Date.now()) {
      const error = new Error("Hyperliquid authorization request is expired.");
      error.code = 4001;
      throw error;
    }
  }

  const config = await getExtensionConfig();
  const demoAccount = demoAccountFromConfig(config);
  if (!sameAddress(request.account, demoAccount.address)) {
    const error = new Error("This prototype can only authorize the configured demo Hyperliquid account.");
    error.code = 4100;
    throw error;
  }
  if (!demoAccount.privateKey) {
    throw new Error("Missing demo account private key for single-signature fallback.");
  }

  const cloudSigner = {
    accountId: state.passliExtensionAccountId || "",
    alias: state.passliExtensionAlias || "demo",
    dappOrigin: origin,
    requestId: request.requestId || "",
    signerAddress: state.passliExtensionCloudSignerAddress || config.cloudSignerAddress || "",
    url: new URL("/api/cloud-sign/l1-action", PASSLI_API_URL).toString()
  };
  await requireCloudSignerApprovalDecision({
    cloudSigner,
    origin,
    method,
    outerSigner: cloudSigner.signerAddress || demoAccount.address,
    request
  });

  const result = await HyperliquidBridge.authorizeAction({
    account: request.account,
    accountPrivateKey: demoAccount.privateKey,
    cloudSigner,
    localSignerPrivateKey: state.hlMultisigSignerPrivateKey ? normalizeHexPrivateKey(state.hlMultisigSignerPrivateKey) : "",
    hyperliquidChain: request.hyperliquidChain,
    signatureChainId: request.signatureChainId || signatureChainIdForHyperliquidChain(request.hyperliquidChain),
    action: request.action,
    vaultAddress: request.vaultAddress,
    submitMode: request.submitMode,
    nonce: request.nonce,
    expiresAfter: request.expiresAfter
  });

  if (request.submitMode === "walletSubmit") {
    await noteDemoWalletSignActivity(state, { origin, method });
    await appendLog({
      phase: "hyperliquid:authorize-action",
      origin,
      method,
      params: [request],
      result: {
        status: "submitted",
        signingMode: result.signingMode,
        account: request.account,
        hyperliquidChain: request.hyperliquidChain,
        requestId: request.requestId || "",
        hlResponse: result.hlResponse
      }
    });
    return result.hlResponse;
  }

  const response = {
    type: "hyperliquid.authorizeActionResult.v1",
    requestId: request.requestId,
    status: result.status,
    signingMode: result.signingMode,
    account: request.account,
    hyperliquidChain: request.hyperliquidChain,
    signedPayload: result.signedPayload
  };

  await noteDemoWalletSignActivity(state, { origin, method });
  await appendLog({
    phase: "hyperliquid:authorize-action",
    origin,
    method,
    params: [request],
    result: {
      status: response.status,
      signingMode: response.signingMode,
      account: response.account,
      hyperliquidChain: response.hyperliquidChain,
      requestId: response.requestId || ""
    }
  });

  return response;
}

async function signWithExtensionVault({ state, origin, method, params, activeAccount }) {
  const vaultRecord = await getDecryptedVaultRecord(state);
  if (!vaultRecord) {
    const error = new Error("Extension key vault is not provisioned.");
    error.code = 4100;
    throw error;
  }
  const requestedAddress = requestedAddressForSigning(method, params) || activeAccount.address;
  const vaultWallet = vaultWalletByAddress(vaultRecord, requestedAddress);
  if (!vaultWallet) {
    const error = new Error("Requested account is not available in the extension key vault.");
    error.code = 4100;
    throw error;
  }
  const wallet = new Ethers.Wallet(normalizeHexPrivateKey(vaultWallet.singleSigPrivateKey));
  if (!sameAddress(wallet.address, vaultWallet.address)) {
    throw new Error("Extension key vault wallet address does not match its stored private key.");
  }

  await requireApproval({
    origin,
    method,
    params,
    address: vaultWallet.address
  });

  const result = await signMethodWithWallet({ wallet, method, params });

  await appendLog({
    phase: "extension-vault:sign",
    origin,
    method,
    result: {
      accountId: vaultRecord.accountId,
      address: vaultWallet.address
    }
  });
  return result;
}

function vaultApprovalAnalysis(vaultApproval, fallback) {
  // Cloud policy summaries cannot replace locally decoded amounts or cautions.
  if (fallback.securityCritical) return fallback;
  if (!vaultApproval || typeof vaultApproval !== "object") return fallback;
  const riskLabel = String(vaultApproval.riskLevel || "medium");
  const riskTone = riskLabel.toLowerCase() === "low"
    ? "low"
    : riskLabel.toLowerCase() === "high"
      ? "high"
      : "medium";
  return {
    ...fallback,
    fields: Array.isArray(vaultApproval.fields) ? vaultApproval.fields : fallback.fields,
    network: vaultApproval.network || fallback.network,
    requestType: vaultApproval.requestType || fallback.requestType,
    risk: {
      level: riskTone === "high" ? 80 : riskTone === "low" ? 20 : 50,
      label: riskLabel.charAt(0).toUpperCase() + riskLabel.slice(1),
      summary: vaultApproval.summary || fallback.risk?.summary || "Review the vault signing request before approving.",
      tone: riskTone
    },
    subtype: vaultApproval.summary || fallback.subtype
  };
}

async function postVaultEvaluateAndSign(body, requestDeadline, requestContext) {
  const response = await fetch(new URL("/vault/v1/evaluate_and_sign", PASSLI_API_URL).toString(), {
    body: JSON.stringify(body),
    passliRequestDeadline: requestDeadline,
    passliProviderRequest: requestContext,
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json"
    },
    method: "POST"
  });
  const text = await response.text();
  let payload = {};
  if (text) {
    try {
      payload = JSON.parse(text);
    } catch {
      payload = {};
    }
  }
  if (!response.ok) {
    const error = new Error(payload.error || `Vault signing failed: ${response.status}`);
    error.code = response.status === 401 || response.status === 403 ? 4100 : -32603;
    error.reasonCode = payload.code || '';
    error.noBridgeFallback = true;
    throw error;
  }
  return payload.vault || payload;
}

function hyperliquidConvertAnalysis({ account, authorizedUsers = [], fundingSigners = [], hyperliquidChain, target, threshold }) {
  const isMulti = target !== "single";
  return {
    confidence: "medium",
    fields: [
      { label: "Account", value: account },
      { label: "Hyperliquid chain", value: hyperliquidChain },
      ...(isMulti ? [
        { label: "Required signatures", value: String(threshold) },
        { label: "Authorized signers", value: authorizedUsers.join("\n") },
        { label: "Signer activation transfers", value: fundingSigners.length ? fundingSigners.map((signer) => `${signer} receives 0.01 spot USDC via sendAsset`).join("\n") : "None needed" }
      ] : [])
    ],
    network: "Hyperliquid Core",
    requestType: isMulti ? "Enable multisig" : "Disable multisig",
    risk: {
      level: isMulti ? 70 : 80,
      label: "High",
      summary: isMulti
        ? "This changes the Hyperliquid account signer set. Missing signer accounts may be activated with 0.01 spot USDC sendAsset transfers plus Hyperliquid's activation fee."
        : "This removes Hyperliquid native multisig from the account.",
      tone: "high"
    },
    subtype: isMulti ? "convertToMultiSigUser" : "convertToSingleSigUser",
    summary: isMulti
      ? `Enable Hyperliquid native multisig with ${threshold} required signer${threshold === 1 ? "" : "s"}.`
      : "Convert this Hyperliquid account back to single-signature mode.",
    warnings: fundingSigners.length
      ? ["Approving will transfer 0.01 spot USDC from the account to each missing signer address before conversion. Hyperliquid also charges a 1 USDC activation fee for each fresh signer address."]
      : []
  };
}

async function signHyperliquidTypedDataWithVault({ state, origin, account, typedData, analysis }) {
  const accountId = state.passliExtensionAccountId || "";
  const deviceId = state.passliExtensionDeviceId || "";
  if (!accountId) throw Object.assign(new Error("Passli account is not attached to the extension."), { code: 4100 });
  if (!deviceId) throw Object.assign(new Error("Passli device is not attached to the extension session."), { code: 4100 });
  const requestId = crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`;
  const params = [account, JSON.stringify(typedData)];
  const approved = await postVaultEvaluateAndSign({
    approvedAt: new Date().toISOString(),
    canonicalAction: {
      connectedAccount: account,
      dappOrigin: origin,
      decodedAnalysis: analysis,
      method: "eth_signTypedData_v4",
      params,
      requestId,
      requestedAddress: account,
      tabId: null
    },
    deviceId,
    requestId,
    silentAttempt: false,
    userApproved: true,
    userId: accountId
  });
  const approvedResult = approved.result || {};
  if (approvedResult.status !== "approved") {
    throw Object.assign(new Error(approvedResult.reason || "Vault did not approve the Hyperliquid signing request."), { code: 4001 });
  }
  await appendLog({
    phase: "vault:hyperliquid-typed-data-sign:approved",
    origin,
    method: "eth_signTypedData_v4",
    result: {
      address: account,
      primaryType: typedData && typedData.primaryType ? typedData.primaryType : "",
      requestId
    }
  });
  return approvedResult.result;
}

async function decodeProviderRequest({ origin, method, params, address, fallbackChainId }) {
  const fallback = RequestDecoder.analyzeProviderRequest({
    origin,
    method,
    params,
    address,
    fallbackChainId
  });
  // Keep security-critical review deterministic, including with an older decoder service.
  if (fallback.securityCritical) return fallback;
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 1500);
  try {
    const response = await fetch(new URL("/decoder/v1/interpret", PASSLI_DECODER_URL).toString(), {
      body: JSON.stringify({
        address,
        fallbackChainId,
        method,
        origin,
        params
      }),
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json"
      },
      method: "POST",
      signal: controller.signal
    });
    if (!response.ok) return fallback;
    const payload = await response.json();
    return payload.decoder || fallback;
  } catch (error) {
    await appendLog({
      phase: "decoder:fallback",
      origin,
      method,
      error: error && error.message ? error.message : String(error)
    });
    return fallback;
  } finally {
    clearTimeout(timeout);
  }
}

async function signWithVaultPath({ state, origin, method, params, activeAccount, requestDeadline, requestContext }) {
  const requestedAddress = requestedAddressForSigning(method, params) || activeAccount.address;
  if (!localPassliAddressIsVaultControlled(state, requestedAddress)) {
    const error = new Error("Requested account is not available in the Passli vault.");
    error.code = 4100;
    throw error;
  }
  const accountId = state.passliExtensionAccountId || "";
  const deviceId = state.passliExtensionDeviceId || "";
  if (!accountId) {
    const error = new Error("Passli account is not attached to the extension.");
    error.code = 4100;
    throw error;
  }
  if (!deviceId) {
    const error = new Error("Passli device is not attached to the extension session.");
    error.code = 4100;
    throw error;
  }

  const requestId = crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`;
  const selectedAddress = selectedPassliAddressForState(state);
  const fallbackAnalysis = await decodeProviderRequest({
    origin,
    method,
    params,
    address: requestedAddress,
    fallbackChainId: activeAccount.chainId || ""
  });
  const userSignerAddress = state.passliExtensionHlMultisigSignerAddress ||
    state.passliSelectedWallet?.hlMultisigSignerAddress ||
    "";
  if (userSignerAddress && sameAddress(userSignerAddress, requestedAddress)) {
    const vaultRecord = await getDecryptedVaultRecord(state);
    const userSignerPrivateKey = localUserMultisigSignerPrivateKeyForAddress(vaultRecord, state, requestedAddress);
    if (!userSignerPrivateKey) {
      const error = new Error("Unlock the extension vault to sign with the HyperLiq MS User Signer.");
      error.code = 4100;
      throw error;
    }
    const wallet = new Ethers.Wallet(normalizeHexPrivateKey(userSignerPrivateKey));
    if (!sameAddress(wallet.address, requestedAddress)) {
      throw new Error("Extension user multisig signer address does not match its stored private key.");
    }
    await requireApproval({
      origin,
      method,
      params,
      address: requestedAddress,
      analysis: fallbackAnalysis
    });
    const result = await signMethodWithWallet({ wallet, method, params });
    await appendLog({
      phase: "extension-vault:user-multisig-signer-sign",
      origin,
      method,
      result: {
        address: requestedAddress,
        requestId
      }
    });
    return result;
  }
  const canonicalAction = {
    connectedAccount: activeAccount.address || "",
    dappOrigin: origin,
    decodedAnalysis: fallbackAnalysis,
    method,
    params,
    requestId,
    requestedAddress,
    selectedAddressId: selectedAddress ? selectedAddress.id : state.selectedPassliAddressId || "",
    tabId: null
  };
  // These requests must display their warnings before any endpoint can sign.
  const locallyApproved = Boolean(fallbackAnalysis.securityCritical);
  if (locallyApproved) {
    await requireApproval({ origin, method, params, address: requestedAddress, analysis: fallbackAnalysis, cloudSigningIdentity: { userId: accountId, deviceId } });
  }
  const baseBody = {
    canonicalAction,
    deviceId,
    requestId,
    silentAttempt: !locallyApproved,
    userApproved: locallyApproved,
    ...(locallyApproved ? { approvedAt: new Date().toISOString() } : {}),
    userId: accountId
  };
  const silent = await postVaultEvaluateAndSign(baseBody, requestDeadline, requestContext);
  const silentResult = silent.result || {};
  if (silentResult.status === "approved") {
    await appendLog({
      phase: locallyApproved ? "vault:sign:user-approved" : "vault:sign:silent-approved",
      origin,
      method,
      result: {
        address: requestedAddress,
        requestId
      }
    });
    return silentResult.result;
  }
  if (silentResult.status !== "approval_required") {
    const error = new Error(silentResult.reason || "Vault refused the signing request.");
    error.code = 4001;
    throw error;
  }

  await requireApproval({
    origin,
    method,
    params,
    address: requestedAddress,
    analysis: vaultApprovalAnalysis(silentResult.approval, fallbackAnalysis),
    cloudSigningIdentity: { userId: accountId, deviceId }
  });

  const approved = await postVaultEvaluateAndSign({
    ...baseBody,
    approvedAt: new Date().toISOString(),
    silentAttempt: false,
    userApproved: true
  }, requestDeadline, requestContext);
  const approvedResult = approved.result || {};
  if (approvedResult.status !== "approved") {
    const error = new Error(approvedResult.reason || "Vault did not approve the signing request.");
    error.code = 4001;
    throw error;
  }
  await appendLog({
    phase: "vault:sign:approved",
    origin,
    method,
    result: {
      address: requestedAddress,
      delivery: approvedResult.delivery || "return_to_dapp",
      requestId
    }
  });
  return approvedResult.result;
}

async function sendTransactionWithExtensionVault({ state, origin, method, params, activeAccount }) {
  const vaultRecord = await getDecryptedVaultRecord(state);
  if (!vaultRecord) {
    const error = new Error("Extension key vault is not provisioned.");
    error.code = 4100;
    throw error;
  }
  const requestedAddress = requestedAddressForSigning(method, params) || activeAccount.address;
  const vaultWallet = vaultWalletByAddress(vaultRecord, requestedAddress);
  if (!vaultWallet) {
    const error = new Error("Requested account is not available in the extension key vault.");
    error.code = 4100;
    throw error;
  }
  const wallet = new Ethers.Wallet(normalizeHexPrivateKey(vaultWallet.singleSigPrivateKey));
  return sendLocalTransaction({
    state,
    origin,
    method,
    params,
    activeAccount: {
      ...activeAccount,
      address: vaultWallet.address
    },
    wallet
  });
}

async function authorizeHyperliquidActionWithExtensionVault({ state, origin, method, params, activeAccount }) {
  const vaultRecord = await getDecryptedVaultRecord(state);
  if (!vaultRecord) {
    const error = new Error("Extension key vault is not provisioned.");
    error.code = 4100;
    throw error;
  }
  const request = normalizeHyperliquidAuthorizeActionRequest(params, activeAccount);
  if (!sameAddress(request.account, activeAccount.address)) {
    const error = new Error("Requested account is not connected to this dApp session.");
    error.code = 4100;
    throw error;
  }
  const singleSigPrivateKey = hyperliquidSingleSigPrivateKeyForVaultAccount(vaultRecord, state, request.account);
  if (request.expiresAt) {
    const expiresAtMs = Date.parse(request.expiresAt);
    if (Number.isFinite(expiresAtMs) && expiresAtMs <= Date.now()) {
      const error = new Error("Hyperliquid authorization request is expired.");
      error.code = 4001;
      throw error;
    }
  }

  const cloudSigner = {
    accountId: vaultRecord.accountId || state.passliExtensionAccountId || "",
    alias: vaultRecord.alias || state.passliExtensionAlias || "",
    dappOrigin: origin,
    requestId: request.requestId || "",
    signerAddress: vaultRecord.cloudSignerAddress || state.passliExtensionCloudSignerAddress || "",
    url: new URL("/api/cloud-sign/l1-action", PASSLI_API_URL).toString()
  };
  const multiSigStatus = await HyperliquidBridge.getMultiSigStatus({
    user: request.account,
    localSignerAddress: cloudSigner.signerAddress || "",
    hyperliquidChain: request.hyperliquidChain
  });
  if (!singleSigPrivateKey && multiSigStatus.mode !== "multiSig") {
    const error = new Error(sameAddress(request.account, cloudSigner.signerAddress)
      ? "The vault signer account is cloud-managed and cannot be used as a normal single-signature dApp account yet."
      : "Requested Hyperliquid account is not available in the extension key vault.");
    error.code = 4100;
    throw error;
  }
  const operationalSignerAddress = cloudSigner.signerAddress || request.account;
  const policyDecision = await requireCloudSignerApprovalDecision({
    cloudSigner,
    origin,
    method,
    outerSigner: operationalSignerAddress,
    request
  });

  let result;
  try {
    result = await HyperliquidBridge.authorizeAction({
      account: request.account,
      accountPrivateKey: singleSigPrivateKey ? normalizeHexPrivateKey(singleSigPrivateKey) : "",
      cloudSigner,
      localSignerPrivateKey: normalizeHexPrivateKey(hyperliquidMultisigUserSignerPrivateKey(vaultRecord)),
      hyperliquidChain: request.hyperliquidChain,
      signatureChainId: request.signatureChainId,
      action: request.action,
      vaultAddress: request.vaultAddress,
      submitMode: request.submitMode,
      nonce: request.nonce,
      expiresAfter: request.expiresAfter
    });
  } catch (error) {
    await appendLog({
      phase: "diagnostic:extension-vault-action-failed",
      origin,
      method,
      params: [request],
      result: {
        actionType: request.action && request.action.type ? request.action.type : "",
        cloudSignerRequest: error && error.cloudSignerRequest ? error.cloudSignerRequest : null,
        cloudSignerResponse: error && error.cloudSignerResponse ? error.cloudSignerResponse : null,
        cloudSignerStatus: error && error.cloudSignerStatus ? error.cloudSignerStatus : null,
        hyperliquidSubmitError: error && error.hyperliquidSubmitError ? error.hyperliquidSubmitError : null,
        hyperliquidSubmitRequest: error && error.hyperliquidSubmitRequest ? error.hyperliquidSubmitRequest : null,
        policyDecision,
        policyLogId: cloudSigner.policyLogId || "",
        requestId: request.requestId || ""
      },
      error: error && error.message ? error.message : String(error)
    });
    if (policyDecision === "silentAllow") {
      await appendLog({
        phase: "diagnostic:silent-policy-action-failed",
        origin,
        method,
        params: [request],
        result: {
          actionType: request.action && request.action.type ? request.action.type : "",
          policyDecision,
          policyLogId: cloudSigner.policyLogId || "",
          requestId: request.requestId || ""
        },
        error: error && error.message ? error.message : String(error)
      });
      const wrapped = new Error(`Cloud policy silently allowed this request, but extension signing/submission failed: ${error && error.message ? error.message : String(error)}`);
      wrapped.code = error && error.code ? error.code : 4001;
      wrapped.noBridgeFallback = true;
      throw wrapped;
    }
    error.noBridgeFallback = true;
    throw error;
  }

  await appendLog({
    phase: "extension-vault:hyperliquid-authorize-action",
    origin,
    method,
    params: [request],
    result: {
      account: request.account,
      hlResponse: result.hlResponse || null,
      hyperliquidChain: request.hyperliquidChain,
      requestId: request.requestId || "",
      signingMode: result.signingMode,
      status: result.status
    }
  });

  if (request.submitMode === "walletSubmit" && result.hlResponse && result.hlResponse.status === "err") {
    await appendLog({
      phase: "diagnostic:hyperliquid-submit-returned-error",
      origin,
      method,
      params: [request],
      result: {
        hlResponse: result.hlResponse,
        requestId: request.requestId || "",
        signedPayload: result.signedPayload || null
      },
      error: typeof result.hlResponse.response === "string"
        ? result.hlResponse.response
        : "Hyperliquid exchange returned status=err."
    });
  }

  if (request.submitMode === "walletSubmit") {
    return result.hlResponse;
  }
  return {
    type: "hyperliquid.authorizeActionResult.v1",
    requestId: request.requestId,
    status: result.status,
    signingMode: result.signingMode,
    account: request.account,
    hyperliquidChain: request.hyperliquidChain,
    signedPayload: result.signedPayload
  };
}

async function hyperliquidMultisigStatusForState(state) {
  const selectedPassliAddress = passliCryptoAddressesForState(state).find(passliAddressIsHyperliquid);
  const passliAccount = selectedPassliAddress && selectedPassliAddress.address
    ? {
      address: selectedPassliAddress.address,
      chainId: selectedPassliAddress.chainId || state.chainId
    }
    : null;
  if (!passliAccount || !passliAccount.address) {
    const error = new Error("No Hyperliquid account is selected.");
    error.code = 4100;
    throw error;
  }
  if (!passliAddressIsHyperliquid(selectedPassliAddress)) {
    const error = new Error("Select the Hyperliquid address before managing Hyperliquid multisig.");
    error.code = 4100;
    throw error;
  }
  const localSignerAddress = state.passliExtensionCloudSignerAddress ||
    (state.passliSelectedWallet && state.passliSelectedWallet.cloudSignerAddress) ||
    "";
  const status = await HyperliquidBridge.getMultiSigStatus({
    user: passliAccount.address,
    localSignerAddress,
    hyperliquidChain: normalizeHyperliquidChain(state.hyperliquidChain)
  });
  return {
    ...status,
    account: passliAccount.address,
    chainId: passliAccount.chainId || state.chainId,
    localSignerAddress,
    message: status.mode === "multiSig"
      ? "Hyperliquid dApps can send raw L1 actions for Passli policy approval, and recovery signers can protect access if Passli is unavailable."
      : "Enable multisig to let Passli approve decoded Hyperliquid L1 actions and add recovery signers."
  };
}

async function setHyperliquidMultisigMode(message) {
  const target = message.target === "single" ? "singleSig" : "multiSig";
  const state = await getState();
  const status = await hyperliquidMultisigStatusForState(state);
  if (status.mode === target) {
    return {
      result: {
        ...status,
        message: target === "multiSig"
          ? "This account is already in Hyperliquid native multisig mode."
          : "This account is already in Hyperliquid single-signature mode."
      }
    };
  }
  const account = normalizeAddress(status.account || "");
  let authorizedUsers = [];
  if (target === "multiSig") {
    const accountPreflight = status.accountPreflight && typeof status.accountPreflight === "object" ? status.accountPreflight : null;
    if (accountPreflight && accountPreflight.needsFunding) {
      return {
        error: {
          code: 4001,
          message: "Initialize this Hyperliquid account before enabling multisig. Deposit or receive a Core transfer first, then retry."
        }
      };
    }
    const passliSigner = String(state.passliExtensionCloudSignerAddress || "").trim();
    const includeBrowserSigner = message.includeBrowserSigner !== false;
    const includeAuthoritySigner = message.includeAuthoritySigner === true;
    const authoritySignerSelection = String(message.authoritySigner || state.hyperliquidMultisigAuthoritySigner || "");
    const deviceSigner = includeBrowserSigner ? String(state.passliExtensionHlMultisigSignerAddress || "").trim() : "";
    const authoritySigner = includeAuthoritySigner ? connectedSignerForSelection(state, authoritySignerSelection) : null;
    const authoritySignerAddress = String(authoritySigner && authoritySigner.address || "").trim();
    const threshold = Number(message.threshold || state.hyperliquidMultisigThreshold || 1) === 2 ? 2 : 1;
    if (!passliSigner) {
      return { error: { code: 4100, message: "Passli cloud signer is not synced yet. Open passli.app and refresh the extension session." } };
    }
    if (includeBrowserSigner && !deviceSigner) {
      return { error: { code: 4100, message: "Device Hyperliquid signer is not provisioned yet. Open passli.app and refresh the extension session." } };
    }
    if (includeAuthoritySigner && !authoritySignerAddress) {
      return { error: { code: 4100, message: "The selected connected wallet signer is not available. Reconnect it from passli.app, then retry." } };
    }
    authorizedUsers.push(normalizeAddress(passliSigner));
    if (deviceSigner) authorizedUsers.push(normalizeAddress(deviceSigner));
    if (authoritySignerAddress) authorizedUsers.push(normalizeAddress(authoritySignerAddress));
    authorizedUsers = Array.from(new Set(authorizedUsers.map((address) => address.toLowerCase()))).map(normalizeAddress);
    if (authorizedUsers.length < threshold) {
      return { error: { code: 4001, message: "Threshold 2 requires Browser or a connected wallet as an additional signer." } };
    }
    await setState({
      hyperliquidMultisigAuthoritySigner: authoritySignerSelection,
      hyperliquidMultisigIncludeAuthoritySigner: includeAuthoritySigner,
      hyperliquidMultisigIncludeBrowserSigner: includeBrowserSigner,
      hyperliquidMultisigThreshold: threshold
    });
  }
  const threshold = target === "multiSig"
    ? Number(message.threshold || state.hyperliquidMultisigThreshold || 1) === 2 ? 2 : 1
    : 1;
  const origin = `chrome-extension://${chrome.runtime.id}`;
  const hyperliquidChain = normalizeHyperliquidChain(state.hyperliquidChain);
  let fundingSigners = [];
  if (target === "multiSig") {
    const preflight = await HyperliquidBridge.getUserRoles({
      hyperliquidChain,
      users: [account, ...authorizedUsers]
    });
    const accountRole = preflight.roles.find((entry) => sameAddress(entry.user, account));
    if (!accountRole || !accountRole.exists) {
      return {
        error: {
          code: 4001,
          message: "Initialize this Hyperliquid account before enabling multisig. Deposit or receive a Core transfer first, then retry."
        }
      };
    }
    fundingSigners = preflight.missing
      .filter((entry) => !sameAddress(entry.user, account))
      .map((entry) => normalizeAddress(entry.user));
  }
  const analysis = hyperliquidConvertAnalysis({
    account,
    authorizedUsers,
    fundingSigners,
    hyperliquidChain,
    target: target === "singleSig" ? "single" : "multi",
    threshold
  });
  const params = [{
    account,
    fundMissingSigners: target === "multiSig",
    fundingSigners,
    hyperliquidChain,
    signatureChainId: state.signatureChainId || DEFAULT_SIGNATURE_CHAIN_ID,
    signers: {
      authorizedUsers
    },
    target: target === "singleSig" ? "single" : "multi",
    threshold
  }];
  await requireApproval({
    origin,
    method: "passli_hyperliquid_convertMultiSig",
    params,
    address: account,
    analysis,
    summary: analysis.summary
  });
  const conversionRequestId = crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`;
  const cloudSigner = {
    accountId: state.passliExtensionAccountId || "",
    alias: state.passliExtensionAlias || "",
    dappOrigin: origin,
    extensionApproval: {
      approvedAt: new Date().toISOString(),
      origin,
      status: "approved"
    },
    requestId: conversionRequestId,
    signerAddress: state.passliExtensionCloudSignerAddress || "",
    url: new URL("/api/cloud-sign/l1-action", PASSLI_API_URL).toString()
  };
  const result = await HyperliquidBridge.convertMultiSig({
    account,
    cloudSigner,
    localSignerPrivateKey: state.hlMultisigSignerPrivateKey ? normalizeHexPrivateKey(state.hlMultisigSignerPrivateKey) : "",
    authorizedUsers,
    fundMissingSigners: target === "multiSig",
    hyperliquidChain,
    signatureChainId: state.signatureChainId || DEFAULT_SIGNATURE_CHAIN_ID,
    signTypedData: (typedData) => signHyperliquidTypedDataWithVault({
      account,
      analysis,
      origin,
      state,
      typedData
    }),
    target: target === "singleSig" ? "single" : "multi",
    threshold
  });
  return { result };
}

async function requireCloudSignerApprovalDecision({ cloudSigner, origin, method, outerSigner, request }) {
  let policy;
  try {
    policy = await requestCloudSignerApprovalDecision({ cloudSigner, outerSigner, request });
  } catch (error) {
    const statusCode = Number(error && error.code ? error.code : 0);
    if (statusCode && statusCode < 500) {
      throw error;
    }
    policy = {
      decision: "requireUserApproval",
      logId: "",
      message: "Cloud signer policy preflight failed; requiring extension approval before asking the signer to enforce policy.",
      reason: "cloud-policy-preflight-failed",
      preflightError: error && error.message ? error.message : String(error)
    };
    await appendLog({
      phase: "approval:cloud-policy-preflight-failed-fallback",
      origin,
      method,
      params: [request],
      result: {
        policy,
        policyEndpoint: new URL("/api/cloud-sign/l1-action-policy", PASSLI_API_URL).toString(),
        cloudSignerAccountId: cloudSigner.accountId || "",
        outerSigner
      },
      error: policy.preflightError
    });
  }
  const decision = normalizeCloudApprovalDecision(policy);
  cloudSigner.policyDecision = decision;
  cloudSigner.policyLogId = policy.logId || "";
  const localAnalysis = RequestDecoder.analyzeProviderRequest({ origin, method, params: [request], address: request.account });
  if (decision === "silentAllow" && !localAnalysis.securityCritical) {
    await appendLog({
      phase: "approval:skipped-cloud-policy",
      origin,
      method,
      params: [request],
      result: {
        decision,
        policy
      }
    });
    return decision;
  }

  if (decision === "disabled" || decision === "deny") {
    await appendLog({
      phase: "approval:cloud-policy-blocked",
      origin,
      method,
      params: [request],
      result: {
        decision,
        policy
      }
    });
    if (decision === "disabled") {
      await setState({
        passliAccountDisabled: true,
        passliAccountDisabledAt: new Date().toISOString(),
        passliAccountDisabledReason: policy.reason || policy.message || "cloud-signer-disabled",
        passliAccountDisabledRequestId: policy.logId || request.requestId || ""
      });
      await showTripwireDisabledNotice({
        origin,
        method,
        params: [request],
        address: request.account,
        policy
      }).catch((noticeError) => {
        appendLog({
          phase: "approval:tripwire-disabled-notice-failed",
          origin,
          method,
          params: [request],
          result: { policy },
          error: noticeError && noticeError.message ? noticeError.message : String(noticeError)
        }).catch(() => {});
      });
    }
    const error = new Error(policy.message || (decision === "disabled"
      ? "Cloud signer disabled protected signing for this account."
      : "Cloud signer policy denied this request."));
    error.code = decision === "disabled" ? 4100 : 4001;
    error.noBridgeFallback = true;
    throw error;
  }

  try {
    await requireApproval({
      origin,
      method,
      params: [request],
      address: request.account
    });
  } catch (error) {
    await appendLog({
      phase: "approval:cloud-policy-user-approval-failed",
      origin,
      method,
      params: [request],
      result: {
        decision,
        policy
      },
      error: error && error.message ? error.message : String(error)
    });
    error.noBridgeFallback = true;
    throw error;
  }
  cloudSigner.extensionApproval = {
    approvedAt: new Date().toISOString(),
    origin,
    status: "approved"
  };
  return decision;
}

async function requestCloudSignerApprovalDecision({ cloudSigner, outerSigner, request }) {
  const policyUrl = new URL("/api/cloud-sign/l1-action-policy", PASSLI_API_URL).toString();
  let response;
  try {
    response = await fetch(policyUrl, {
      body: JSON.stringify({
        account: request.account,
        accountId: cloudSigner.accountId || "",
        action: request.action,
        alias: cloudSigner.alias || "",
        dappOrigin: cloudSigner.dappOrigin || "",
        expiresAfter: request.expiresAfter || undefined,
        hyperliquidChain: request.hyperliquidChain,
        nonce: request.nonce,
        outerSigner,
        requestId: cloudSigner.requestId || request.requestId || "",
        submitMode: request.submitMode,
        uid: cloudSigner.uid || "",
        vaultAddress: request.vaultAddress || undefined
      }),
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json"
      },
      method: "POST"
    });
  } catch (error) {
    const wrapped = new Error(error && error.message
      ? `Cloud signer policy request failed: ${error.message}`
      : "Cloud signer policy request failed.");
    wrapped.code = 502;
    wrapped.noBridgeFallback = true;
    throw wrapped;
  }
  const result = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(result.error || `Cloud signer policy request failed: ${response.status}`);
    error.code = response.status;
    error.noBridgeFallback = true;
    throw error;
  }
  return normalizeCloudApprovalPolicyResponse(result);
}

function normalizeCloudApprovalPolicyResponse(result) {
  if (!result || typeof result !== "object") {
    return { decision: "requireUserApproval", logId: "" };
  }
  if (result.policyDecision && typeof result.policyDecision === "object") {
    return {
      ...result.policyDecision,
      logId: result.logId || result.policyDecision.logId || ""
    };
  }
  if (result.decision && typeof result.decision === "object") {
    return {
      ...result.decision,
      logId: result.logId || result.decision.logId || ""
    };
  }
  if (typeof result.decision === "string" || typeof result.action === "string") {
    return {
      ...result,
      decision: typeof result.decision === "string" ? result.decision : result.action,
      logId: result.logId || ""
    };
  }
  return {
    ...result,
    logId: result.logId || ""
  };
}

function normalizeCloudApprovalDecision(policy) {
  if (!policy || typeof policy !== "object") return "requireUserApproval";
  const decision = String(policy.decision || policy.action || "").trim();
  if (decision === "silentAllow" || decision === "requireUserApproval" || decision === "disabled" || decision === "deny") {
    return decision;
  }
  return "requireUserApproval";
}

function signingSummary(method, params) {
  if (method === "personal_sign") {
    return "Approve this off-chain login/message signature in your WalletConnect wallet. It does not move funds or submit a transaction.";
  }

  if (method === "eth_sign") {
    return "Approve this raw message signature in your WalletConnect wallet.";
  }

  if (method === "eth_signTypedData" || method === "eth_signTypedData_v3" || method === "eth_signTypedData_v4") {
    try {
      const typedData = parseTypedData(params[1]);
      const primaryType = String(typedData.primaryType || "");
      const message = typedData.message || {};
      if (primaryType.includes("ApproveAgent")) {
        return [
          "Approve a Hyperliquid agent key in your WalletConnect wallet.",
          `Agent: ${message.agentName || "unknown"}`,
          `Agent address: ${message.agentAddress || "unknown"}`,
          `Hyperliquid chain: ${message.hyperliquidChain || "unknown"}`
        ].join("\n");
      }
      if (primaryType.includes("ApproveBuilderFee")) {
        return "Approve a Hyperliquid builder fee setting in your WalletConnect wallet.";
      }
      return `Approve this typed-data signature in your WalletConnect wallet: ${primaryType || "unknown typed data"}.`;
    } catch {
      return "Approve this typed-data signature in your WalletConnect wallet.";
    }
  }

  return `Approve this ${method} request in your WalletConnect wallet.`;
}

async function rpcRequest(chainId, method, params) {
  const normalizedChainId = normalizeChainIdHex(chainId);
  const url = RPC_URLS[normalizedChainId];
  if (!url) {
    return { error: { code: 4902, message: `No demo RPC configured for ${chainId}` } };
  }

  const response = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      jsonrpc: "2.0",
      id: Date.now(),
      method,
      params
    })
  });
  const payload = await response.json();
  if (payload.error) return { error: payload.error };
  return { result: payload.result };
}

async function rpcResult(chainId, method, params) {
  const response = await rpcRequest(chainId, method, params);
  if (response.error) {
    const error = new Error(response.error.message || `${method} failed`);
    error.code = response.error.code;
    error.data = response.error.data;
    throw error;
  }
  return response.result;
}

function normalizeTransactionRequest(tx, activeAccount, chainId) {
  if (!tx || typeof tx !== "object") {
    throw new Error("eth_sendTransaction requires a transaction object.");
  }

  const from = tx.from || activeAccount.address;
  if (from && !sameAddress(from, activeAccount.address)) {
    throw new Error("Requested account is not available");
  }

  const request = {
    from: activeAccount.address,
    to: tx.to || undefined,
    data: tx.data || "0x",
    value: tx.value || "0x0",
    chainId
  };

  if (tx.gas || tx.gasLimit) request.gas = tx.gas || tx.gasLimit;
  if (tx.nonce !== undefined) request.nonce = tx.nonce;
  if (tx.gasPrice !== undefined) request.gasPrice = tx.gasPrice;
  if (tx.maxFeePerGas !== undefined) request.maxFeePerGas = tx.maxFeePerGas;
  if (tx.maxPriorityFeePerGas !== undefined) request.maxPriorityFeePerGas = tx.maxPriorityFeePerGas;
  if (tx.type !== undefined) request.type = tx.type;
  if (tx.accessList !== undefined) request.accessList = tx.accessList;

  return request;
}

async function fillTransactionForSigning(chainId, tx) {
  const filled = { ...tx };
  if (filled.nonce === undefined) {
    filled.nonce = await rpcResult(chainId, "eth_getTransactionCount", [filled.from, "pending"]);
  }
  if (!filled.gas) {
    filled.gas = await rpcResult(chainId, "eth_estimateGas", [filled]);
  }
  if (filled.gasPrice === undefined && filled.maxFeePerGas === undefined && filled.maxPriorityFeePerGas === undefined) {
    filled.gasPrice = await rpcResult(chainId, "eth_gasPrice", []);
  }
  return filled;
}

function transactionForEthersSign(tx) {
  const signedTx = {
    chainId: BigInt(tx.chainId),
    data: tx.data || "0x",
    gasLimit: tx.gas,
    nonce: tx.nonce,
    value: tx.value || "0x0"
  };

  if (tx.to) signedTx.to = tx.to;
  if (tx.gasPrice !== undefined) signedTx.gasPrice = tx.gasPrice;
  if (tx.maxFeePerGas !== undefined) signedTx.maxFeePerGas = tx.maxFeePerGas;
  if (tx.maxPriorityFeePerGas !== undefined) signedTx.maxPriorityFeePerGas = tx.maxPriorityFeePerGas;
  if (tx.type !== undefined) signedTx.type = tx.type;
  if (tx.accessList !== undefined) signedTx.accessList = tx.accessList;

  return signedTx;
}

async function sendLocalTransaction({ state, origin, method, params, activeAccount, wallet }) {
  const chainId = normalizeChainIdHex(
    RequestDecoder.requestedChainId(method, params, activeAccount.chainId || state.chainId) || activeAccount.chainId || state.chainId
  );
  const normalized = normalizeTransactionRequest(params[0], activeAccount, chainId);

  await requireApproval({
    origin,
    method,
    params,
    address: activeAccount.address
  });

  const filled = await fillTransactionForSigning(chainId, normalized);
  const rawTransaction = await wallet.signTransaction(transactionForEthersSign(filled));
  const hash = await rpcResult(chainId, "eth_sendRawTransaction", [rawTransaction]);
  await noteDemoWalletSignActivity(state, { origin, method });
  await appendLog({
    phase: "eth_sendTransaction:submitted",
    origin,
    method,
    params,
    result: {
      chainId,
      from: activeAccount.address,
      to: normalized.to || null,
      hash
    }
  });
  return hash;
}

async function walletConnectStatus(state) {
  if (!state.walletConnectProjectId) {
    return { connected: false };
  }

  const result = await WalletConnectBridge.status(state.walletConnectProjectId, {
    address: state.selectedWalletConnectAddress || state.walletConnectAccount?.address || "",
    topic: state.selectedWalletConnectTopic || state.walletConnectAccount?.topic || ""
  });
  const accounts = Array.isArray(result.accounts) ? result.accounts : [];
  const selectedAccount = accounts.find((account) =>
    String(account.topic || "") === String(state.selectedWalletConnectTopic || "") &&
    sameAddress(account.address, state.selectedWalletConnectAddress)
  ) || result.account || accounts[0] || null;
  await setState({
    walletConnectUri: result.connected ? "" : state.walletConnectUri || "",
    walletConnectAccount: selectedAccount,
    walletConnectWallet: selectedAccount?.wallet || result.wallet || null,
    selectedWalletConnectAddress: selectedAccount?.address || "",
    selectedWalletConnectTopic: selectedAccount?.topic || ""
  });
  return {
    ...result,
    account: selectedAccount,
    wallet: selectedAccount?.wallet || result.wallet || null
  };
}

async function getActiveAccount(state) {
  if (state.signingMode === "externalAuthority") {
    const wallet = selectedExternalAuthorityWalletForState(state);
    return {
      address: wallet && wallet.address ? wallet.address : "",
      chainId: state.chainId,
      signerType: "externalAuthority",
      sourceChainId: wallet && wallet.chainId ? wallet.chainId : ""
    };
  }

  if (state.signingMode !== "walletconnect") {
    const selectedPassliAddress = selectedPassliAddressForState(state);
    if (selectedPassliAddress && selectedPassliAddress.address) {
      return {
        address: selectedPassliAddress.address,
        chainId: selectedPassliAddress.chainId || state.chainId
      };
    }
    if (state.passliExtensionLoggedIn) {
      return {
        address: "",
        chainId: state.chainId
      };
    }
    return {
      address: "",
      chainId: state.chainId
    };
  }

  const status = await walletConnectStatus(state);
  if (status.connected && status.account && status.account.address) {
    return {
      address: status.account.address,
      chainId: state.chainId,
      signerType: "walletconnect",
      sourceChainId: status.account.chainId || ""
    };
  }

  return {
    address: "",
    chainId: state.chainId
  };
}

async function walletConnectSign(state, method, params, fallbackChainId) {
  if (!state.walletConnectProjectId) {
    throw new Error("WalletConnect project ID is required.");
  }

  const chainId = RequestDecoder.requestedChainId(method, params, fallbackChainId || state.signatureChainId) || state.signatureChainId;
  await appendLog({
    phase: "walletconnect:request",
    origin: "extension",
    method,
    params,
    result: { chainId }
  });

  let result;
  try {
    result = await withTimeout(
      WalletConnectBridge.request({
        projectId: state.walletConnectProjectId,
        chainId,
        topic: state.selectedWalletConnectTopic || state.walletConnectAccount?.topic || "",
        address: state.selectedWalletConnectAddress || state.walletConnectAccount?.address || "",
        method,
        params
      }),
      2 * 60 * 1000,
      "Timed out waiting for WalletConnect signature approval."
    );
  } catch (error) {
    await appendLog({
      phase: "walletconnect:error",
      origin: "extension",
      method,
      params,
      error: error && error.message ? error.message : String(error)
    });
    throw error;
  }

  await appendLog({
    phase: "walletconnect:response",
    origin: "extension",
    method,
    result
  });

  return result;
}

async function walletConnectSignWithNotice(state, { origin, method, params, address, fallbackChainId }) {
  const chainId = RequestDecoder.requestedChainId(method, params, fallbackChainId || state.signatureChainId) || state.signatureChainId;
  await appendLog({
    phase: "walletconnect:request",
    origin: "extension",
    method,
    params,
    result: { chainId, host: "approval-window" }
  });

  const notice = await requestWalletConnectNotice({
    origin,
    method,
    params,
    address,
    summary: signingSummary(method, params),
    walletConnectRequest: {
      projectId: state.walletConnectProjectId,
      chainId,
      topic: state.selectedWalletConnectTopic || state.walletConnectAccount?.topic || "",
      address,
      method,
      params
    }
  });

  let completed = false;
  const signingPromise = (async () => {
    try {
      const result = await withTimeout(
        WalletConnectBridge.request({
          projectId: state.walletConnectProjectId,
          chainId,
          topic: state.selectedWalletConnectTopic || state.walletConnectAccount?.topic || "",
          address,
          method,
          params
        }),
        2 * 60 * 1000,
        "Timed out waiting for WalletConnect signature approval."
      );
      if (!completed) {
        await appendLog({
          phase: "walletconnect:response",
          origin,
          method,
          result
        });
      }
      return result;
    } catch (error) {
      if (!completed) {
        await appendLog({
          phase: "walletconnect:error",
          origin,
          method,
          params,
          error: error && error.message ? error.message : String(error)
        });
      }
      throw error;
    }
  })();

  const cancelPromise = notice.promise.then(
    () => new Promise(() => {}),
    (error) => {
      throw error;
    }
  );

  try {
    const result = await Promise.race([signingPromise, cancelPromise]);
    completed = true;
    notifyWalletConnectNotice(notice.id, {
      action: "signed",
      method
    });
    await delay(500);
    return result;
  } finally {
    completed = true;
    await closePendingWindow(notice.id);
  }
}

function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function notifyWalletConnectNotice(id, message) {
  const port = walletConnectSigningPorts.get(id);
  if (!port) return;
  try {
    port.postMessage(message);
  } catch {
    // The status popup may already be closed.
  }
}

function withTimeout(promise, timeoutMs, message) {
  return Promise.race([
    promise,
    new Promise((_, reject) => {
      setTimeout(() => reject(new Error(message)), timeoutMs);
    })
  ]);
}

async function broadcastProviderEvent(origin, eventName, payload) {
  if (!chrome.tabs || !origin) return [];

  const tabs = await chrome.tabs.query({});
  const targetTabs = tabs.filter((tab) => {
    try {
      return tab.id !== undefined && new URL(tab.url || "").origin === origin;
    } catch {
      return false;
    }
  });
  const deliveries = await Promise.all(
    targetTabs.map(async (tab) => {
      try {
        await chrome.tabs.sendMessage(tab.id, {
          type: "HYPERLIQUID_DEMO_PROVIDER_EVENT",
          eventName,
          payload
        });
        return { delivered: true, eventName, origin, tabId: tab.id };
      } catch (error) {
        return {
          delivered: false,
          eventName,
          origin,
          tabId: tab.id,
          error: error && error.message ? error.message : String(error)
        };
      }
    })
  );
  return deliveries;
}

async function broadcastExtensionWalletStatusToPassli(state) {
  if (!chrome.tabs) return;
  const tabs = await chrome.tabs.query({});
  await Promise.allSettled(
    tabs
      .filter((tab) => {
        try {
          return tab.id !== undefined && PASSLI_AUTH_ORIGINS.has(new URL(tab.url || "").origin);
        } catch {
          return false;
        }
      })
      .map((tab) =>
        chrome.tabs.sendMessage(tab.id, {
          type: "PASSLI_EXTENSION_STATUS_TO_PAGE",
          payload: {
            type: PASSLI_EXTENSION_SELECTED_ADDRESS_STATUS_TYPE,
            extensionProtocolVersion: PASSLI_EXTENSION_PROTOCOL_VERSION,
            extensionVersion: extensionVersion(),
            requiredWebVersion: PASSLI_REQUIRED_WEB_VERSION,
            selectedAddress: selectedAddressStatusForState(state),
            selectedWallet: selectedWalletForState(state),
            source: "passli-extension"
          }
        })
      )
  );
}

async function broadcastConnectionProviderEvent(connection, eventName, payload) {
  if (!chrome.tabs || !connection) {
    return { delivered: false, eventName, origin: connection && connection.origin ? connection.origin : "", tabId: null, error: "No tabs API or connection." };
  }

  if (Number.isInteger(connection.tabId)) {
    try {
      await chrome.tabs.sendMessage(connection.tabId, {
        type: "HYPERLIQUID_DEMO_PROVIDER_EVENT",
        eventName,
        payload
      });
      return { delivered: true, eventName, origin: connection.origin || "", tabId: connection.tabId };
    } catch (error) {
      const tabOrigin = await originFromTabId(connection.tabId);
      return {
        delivered: false,
        eventName,
        origin: connection.origin || tabOrigin || "",
        tabId: connection.tabId,
        tabOrigin,
        error: error && error.message ? error.message : String(error)
      };
    }
  }

  const deliveries = await broadcastProviderEvent(connection.origin, eventName, payload);
  return {
    delivered: deliveries.some((delivery) => delivery.delivered),
    deliveries,
    eventName,
    origin: connection.origin || "",
    tabId: null
  };
}

async function broadcastActiveAccountConnections(state) {
  const connections = Object.entries(state.connectedOrigins || {})
    .map(([key, entry]) => normalizeConnectionRecord(key, entry, entry && entry.origin ? entry.origin : key, state))
    .filter(Boolean);
  await Promise.allSettled(
    connections.map((connection) =>
      broadcastConnectionProviderEvent(
        connection,
        "accountsChanged",
        [connection.account.address]
      )
    )
  );
}

function accountForConnectionRebind(account, signerType, state) {
  return {
    address: account.address,
    chainId: account.chainId || state.chainId,
    signerType,
    type: signerType === "walletconnect" ? "walletconnect" : "passli-account"
  };
}

async function rebindConnectedOriginsToAccount(state, account, signerType) {
  const reboundAccount = accountForConnectionRebind(account, signerType, state);
  const connectedOrigins = {};
  const trustedOriginsToUpdate = new Set();
  const now = new Date().toISOString();

  for (const [key, entry] of Object.entries(state.connectedOrigins || {})) {
    if (!entry) continue;
    const fallbackOrigin = entry && entry.origin ? entry.origin : key;
    const connection = normalizeConnectionRecord(key, entry, fallbackOrigin, state) || {};
    const tabId = Number.isInteger(connection.tabId)
      ? connection.tabId
      : Number.isInteger(entry.tabId)
        ? entry.tabId
        : tabIdFromConnectionKey(key);
    const storedOrigin = connection.origin || entry.origin || key;
    const recoveredOrigin = isTabConnectionKey(storedOrigin)
      ? await originFromTabId(tabId)
      : "";
    const origin = recoveredOrigin || storedOrigin;
    trustedOriginsToUpdate.add(origin);
    connectedOrigins[key] = {
      origin,
      tabId,
      accounts: {
        [accountKey(reboundAccount.address)]: {
          ...reboundAccount,
          connectedAt: now
        }
      },
      accountOrder: [reboundAccount.address],
      connectedAt: entry.connectedAt || now,
      reboundAt: now
    };
  }

  let trustedDappOrigins = state.trustedDappOrigins || {};
  for (const origin of trustedOriginsToUpdate) {
    trustedDappOrigins = trustOriginForAccounts(trustedDappOrigins, origin, [reboundAccount], signerType);
  }

  return {
    connectedOrigins,
    trustedDappOrigins,
    reboundAccount,
    updatedOrigins: Array.from(trustedOriginsToUpdate).sort()
  };
}

async function broadcastDisconnectForConnections(state) {
  const connections = Object.entries(state.connectedOrigins || {})
    .map(([key, entry]) => normalizeConnectionRecord(key, entry, entry && entry.origin ? entry.origin : key, state))
    .filter(Boolean);
  await Promise.allSettled(
    connections.map((connection) =>
      broadcastConnectionProviderEvent(connection, "accountsChanged", [])
    )
  );
}

async function rebindAndBroadcastSelectedWalletChange(previousState, nextState, origin, method) {
  const previousWallet = previousState.passliSelectedWallet && previousState.passliSelectedWallet.address
    ? previousState.passliSelectedWallet
    : null;
  const nextWallet = nextState.passliSelectedWallet && nextState.passliSelectedWallet.address
    ? nextState.passliSelectedWallet
    : null;
  if (!nextWallet || accountKey(previousWallet && previousWallet.address) === accountKey(nextWallet.address)) {
    return { notifiedConnections: 0, notifiedOrigins: [] };
  }
  if (nextState.signingMode === "walletconnect") {
    return { notifiedConnections: 0, notifiedOrigins: [] };
  }

  const rebound = await rebindConnectedOriginsToAccount(nextState, {
    address: nextWallet.address,
    chainId: nextWallet.chainId || nextState.chainId
  }, "local");
  await setState({
    connectedOrigins: rebound.connectedOrigins,
    trustedDappOrigins: rebound.trustedDappOrigins
  });

  const finalState = {
    ...nextState,
    connectedOrigins: rebound.connectedOrigins,
    trustedDappOrigins: rebound.trustedDappOrigins
  };
  const connections = Object.entries(finalState.connectedOrigins || {})
    .map(([key, entry]) => normalizeConnectionRecord(
      key,
      entry,
      entry && entry.origin ? entry.origin : key,
      finalState,
      nextWallet.address
    ))
    .filter(Boolean);
  const deliveries = await Promise.all(
    connections.map((connection) =>
      broadcastConnectionProviderEvent(connection, "accountsChanged", [nextWallet.address])
    )
  );
  const deliveredConnections = deliveries.filter((delivery) => delivery && delivery.delivered).length;

  await appendLog({
    phase: "connection:selected-wallet-notified",
    origin,
    method,
    result: {
      previousAddress: previousWallet && previousWallet.address ? previousWallet.address : "",
      nextAddress: nextWallet.address,
      notifiedConnections: connections.length,
      deliveredConnections,
      notifiedOrigins: rebound.updatedOrigins,
      deliveries
    }
  });
  return { notifiedConnections: connections.length, deliveredConnections, notifiedOrigins: rebound.updatedOrigins };
}

function approvalTitle(method) {
  if (method === "eth_requestAccounts" || method === "wallet_requestPermissions") {
    return "Connect Wallet";
  }
  if (method === "hyperliquid_authorizeAction") {
    return "Authorize Hyperliquid Action";
  }
  if (method === "eth_sendTransaction") {
    return "Review Transaction";
  }
  if (method === "personal_sign") {
    return "Sign In / Prove Wallet";
  }
  return "Sign Message";
}

function walletConnectTitle(method) {
  if (method === "eth_signTypedData_v4" || method === "eth_signTypedData_v3" || method === "eth_signTypedData") {
    return "Approve in WalletConnect";
  }
  return "Sign in WalletConnect";
}

function isConnectApprovalMethod(method) {
  return method === "eth_requestAccounts" || method === "wallet_requestPermissions";
}

async function focusTab(tabId) {
  const tab = await chrome.tabs.get(tabId);
  if (tab.windowId !== undefined) {
    await chrome.windows.update(tab.windowId, { focused: true });
  }
  await chrome.tabs.update(tabId, { active: true });
}

async function waitForTabComplete(tabId) {
  const tab = await chrome.tabs.get(tabId);
  if (tab.status === "complete") return;
  await new Promise((resolve) => {
    const listener = (updatedTabId, changeInfo) => {
      if (updatedTabId !== tabId || changeInfo.status !== "complete") return;
      chrome.tabs.onUpdated.removeListener(listener);
      resolve();
    };
    chrome.tabs.onUpdated.addListener(listener);
    setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(listener);
      resolve();
    }, 10000);
  });
}

async function findPassliBridgeTab() {
  const tabs = await chrome.tabs.query({});
  return tabs.find((tab) => {
    try {
      const origin = new URL(tab.url || "").origin;
      return origin === PASSLI_AUTH_URL || origin === PASSLI_DEV_AUTH_URL;
    } catch {
      return false;
    }
  }) || null;
}

function passliBridgeUrl() {
  const url = new URL("/", PASSLI_AUTH_URL);
  url.searchParams.set("extensionBridge", "1");
  url.searchParams.set("extensionId", chrome.runtime.id);
  return url.toString();
}

async function getOrCreatePassliBridgeTab() {
  const existing = await findPassliBridgeTab();
  if (existing && existing.id !== undefined) {
    return existing.id;
  }

  const created = await chrome.tabs.create({ url: passliBridgeUrl(), active: false });
  if (created.id === undefined) {
    throw new Error("Could not open passli.app bridge tab.");
  }
  return created.id;
}

async function openPassliAppForUnlock() {
  const existing = await findPassliBridgeTab();
  if (existing && existing.id !== undefined) {
    await focusTab(existing.id);
    return existing.id;
  }
  const created = await chrome.tabs.create({ url: passliBridgeUrl(), active: true });
  if (created.id === undefined) {
    throw new Error("Could not open passli.app.");
  }
  return created.id;
}

async function createPassliBridgeTab() {
  const created = await chrome.tabs.create({ url: passliBridgeUrl(), active: false });
  if (created.id === undefined) {
    throw new Error("Could not open passli.app bridge tab.");
  }
  return created.id;
}

function isMissingBridgeReceiverError(error) {
  const message = String(error && error.message ? error.message : error || "");
  return (
    message.includes("Receiving end does not exist") ||
    message.includes("Could not establish connection") ||
    message.includes("Extension context invalidated")
  );
}

async function trySendToPassliBridgeTab(tabId, payload, attempts) {
  await waitForTabComplete(tabId);
  let lastError = null;
  for (let attempt = 0; attempt < attempts; attempt += 1) {
    try {
      await chrome.tabs.sendMessage(tabId, {
        type: "PASSLI_EXTENSION_BRIDGE_TO_PAGE",
        payload
      });
      return null;
    } catch (error) {
      lastError = error;
      await delay(250);
    }
  }
  return lastError;
}

async function sendToPassliBridgeTab(tabId, payload) {
  let activeTabId = tabId;
  let lastError = await trySendToPassliBridgeTab(activeTabId, payload, 4);
  if (!lastError) return activeTabId;

  if (isMissingBridgeReceiverError(lastError)) {
    await appendLog({
      phase: "passli-bridge:receiver-missing",
      origin: payload.dappOrigin || "extension",
      method: payload.method || "bridge",
      result: {
        requestId: payload.requestId || "",
        recovery: "reload-existing-tab",
        tabId: activeTabId
      },
      error: lastError.message || String(lastError)
    });
    try {
      await chrome.tabs.reload(activeTabId, { bypassCache: true });
      await delay(500);
      lastError = await trySendToPassliBridgeTab(activeTabId, payload, 8);
      if (!lastError) return activeTabId;
    } catch (error) {
      lastError = error;
    }

    await appendLog({
      phase: "passli-bridge:receiver-reload-failed",
      origin: payload.dappOrigin || "extension",
      method: payload.method || "bridge",
      result: {
        requestId: payload.requestId || "",
        recovery: "create-fresh-tab",
        previousTabId: activeTabId
      },
      error: lastError && lastError.message ? lastError.message : String(lastError)
    });
    activeTabId = await createPassliBridgeTab();
    lastError = await trySendToPassliBridgeTab(activeTabId, payload, 8);
    if (!lastError) return activeTabId;
  }

  const message = lastError && lastError.message
    ? lastError.message
    : "Could not reach passli.app bridge page.";
  throw new Error(`Passli bridge page is not ready: ${message}`);
}

async function focusPassliBridgeRequest(tabId, requestId) {
  void requestId;
  await focusTab(tabId);
}

async function startPassliBridgeRequest({ origin, method, params, sender, address, analysis, signerType, authorityWalletId, authorityWalletLabel }) {
  const requestId = crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`;
  const tabId = await getOrCreatePassliBridgeTab();
  const bridgeRequest = {
    type: PASSLI_BRIDGE_REQUEST_TYPE,
    requestId,
    extensionId: chrome.runtime.id,
    dappOrigin: origin,
    tabId: tabIdFromSender(sender),
    method,
    params,
    connectedAccount: address || "",
    address: address || "",
    analysis,
    signerType: signerType || "",
    authorityWalletId: authorityWalletId || "",
    authorityWalletLabel: authorityWalletLabel || "",
    requestedAt: new Date().toISOString()
  };

  const promise = new Promise((resolve, reject) => {
    const timeout = setTimeout(() => {
      const error = new Error("Timed out waiting for passli.app bridge response.");
      pendingBridgeRequests.delete(requestId);
      appendLog({
        phase: "passli-bridge:timeout",
        origin,
        method,
        result: {
          requestId,
          tabId
        },
        error: error.message
      }).catch(() => {});
      setApprovalBridgeResult(passliBridgeErrorResponse(requestId, error, "failed"));
      reject(error);
    }, PASSLI_BRIDGE_TIMEOUT_MS);
    pendingBridgeRequests.set(requestId, {
      reject,
      resolve,
      tabId,
      timeout
    });
  });

  try {
    const readyTabId = await sendToPassliBridgeTab(tabId, bridgeRequest);
    const pending = pendingBridgeRequests.get(requestId);
    if (pending) pending.tabId = readyTabId;
    return { promise, request: bridgeRequest, requestId, tabId: readyTabId };
  } catch (error) {
    const pending = pendingBridgeRequests.get(requestId);
    if (pending) {
      clearTimeout(pending.timeout);
      pendingBridgeRequests.delete(requestId);
    }
    throw error;
  }
}

async function sendPassliBridgeApproval(requestId, approved, error) {
  const pending = pendingBridgeRequests.get(requestId);
  if (!pending) return;
  const extensionApproval = approved
    ? {
      approvedAt: new Date().toISOString(),
      origin: "extension",
      status: "approved"
    }
    : undefined;
  const readyTabId = await sendToPassliBridgeTab(pending.tabId, {
    type: PASSLI_BRIDGE_APPROVAL_TYPE,
    approved,
    error: error ? { message: error.message || String(error), code: error.code } : undefined,
    extensionApproval,
    requestId
  });
  pending.tabId = readyTabId;
}

async function cancelPassliBridgeRequest(requestId, error) {
  const pending = pendingBridgeRequests.get(requestId);
  if (!pending) return false;
  const cancelError = error || new Error("User cancelled while waiting for passli.app.");
  clearTimeout(pending.timeout);
  pendingBridgeRequests.delete(requestId);
  await appendLog({
    phase: "passli-bridge:cancelled",
    origin: "extension",
    method: "cancelPassliBridgeRequest",
    result: {
      requestId,
      tabId: pending.tabId
    },
    error: cancelError.message || String(cancelError)
  });
  await sendToPassliBridgeTab(pending.tabId, {
    type: PASSLI_BRIDGE_APPROVAL_TYPE,
    approved: false,
    error: {
      code: cancelError.code || 4001,
      message: cancelError.message || String(cancelError)
    },
    requestId
  }).catch((sendError) => {
    appendLog({
      phase: "passli-bridge:cancel-notify-failed",
      origin: "extension",
      method: "cancelPassliBridgeRequest",
      result: { requestId, tabId: pending.tabId },
      error: sendError && sendError.message ? sendError.message : String(sendError)
    }).catch(() => {});
  });
  setApprovalBridgeResult(passliBridgeErrorResponse(requestId, cancelError, "rejected"));
  pending.reject(cancelError);
  return true;
}

async function requestApproval({ origin, method, params, address, bridgeRequestId, bridgeTabId, availableWallets, summary, analysis, signerType, authorityWalletLabel, cloudSigningIdentity }) {
  if (isConnectApprovalMethod(method)) {
    for (const pending of pendingApprovals.values()) {
      if (
        pending.approval.origin === origin &&
        isConnectApprovalMethod(pending.approval.method)
      ) {
        await appendLog({
          phase: "approval:coalesced",
          origin,
          method,
          params,
          result: {
            pendingMethod: pending.approval.method
          }
        });
        return pending.promise;
      }
    }
  }

  const id = `${Date.now()}-${Math.random().toString(16).slice(2)}`;
  const decodedAnalysis = analysis || await decodeProviderRequest({
    origin,
    method,
    params,
    address,
    fallbackChainId: ""
  });
  const approval = {
    id,
    title: approvalTitle(method),
    origin,
    method,
    params: redactForLog(params),
    address,
    summary: summary || "",
    signerType: signerType || "",
    authorityWalletLabel: authorityWalletLabel || "",
    availableWallets: isConnectApprovalMethod(method) ? availableWallets || [] : [],
    bridgeRequestId: bridgeRequestId || "",
    analysis: decodedAnalysis
  };

  await appendLog({
    phase: "approval:open",
    origin,
    method,
    params
  });

  let resolveApproval;
  let rejectApproval;
  const promise = new Promise((resolve, reject) => {
    resolveApproval = resolve;
    rejectApproval = reject;
  });

  const timeout = setTimeout(() => {
    pendingApprovals.delete(id);
    appendLog({
      phase: "approval:timeout",
      origin,
      method
    }).catch(() => {});
    rejectApproval(new Error("Approval timed out"));
  }, 5 * 60 * 1000);

  pendingApprovals.set(id, {
    approval,
    bridgeRequestId: bridgeRequestId || "",
    bridgeTabId: bridgeTabId || null,
    cloudSigningIdentity,
    resolve: resolveApproval,
    reject: rejectApproval,
    promise,
    timeout,
    windowId: null
  });

  const approvalUrl = chrome.runtime.getURL(`src/approval.html?id=${encodeURIComponent(id)}`);
  const createdWindow = await openApprovalWindow(approvalUrl);

  const pending = pendingApprovals.get(id);
  if (pending) {
    pending.windowId = createdWindow.id;
  }

  return promise;
}

async function requestVaultUnlockNotice({ origin, method, params, address }, error) {
  const id = `${Date.now()}-${Math.random().toString(16).slice(2)}`;
  const decodedAnalysis = await decodeProviderRequest({
    origin,
    method,
    params,
    address,
    fallbackChainId: ""
  });
  const fields = Array.isArray(decodedAnalysis.fields) ? decodedAnalysis.fields.slice() : [];
  fields.unshift(
    { label: "Required action", value: "Unlock your Passli vault, then retry the dApp action." },
    { label: "Why", value: "This request needs vault signing. The extension cannot sign while the encrypted vault is locked." }
  );
  const approval = {
    id,
    mode: "vault-locked",
    noticeOnly: true,
    title: "Unlock Vault",
    origin,
    method,
    params: redactForLog(params),
    address,
    summary: "The vault is locked, so Passli cannot sign this request yet.",
    analysis: {
      ...decodedAnalysis,
      fields,
      risk: {
        label: "Blocked",
        level: 100,
        summary: "No signature was produced. Unlock Passli and retry this action.",
        tone: "high"
      },
      requestType: "Vault locked",
      subtype: decodedAnalysis.subtype || method
    },
    unlockError: error && error.message ? error.message : String(error || "")
  };

  await appendLog({
    phase: "vault:locked-notice-open",
    origin,
    method,
    params,
    result: {
      address,
      reason: approval.unlockError
    }
  });

  let resolveNotice;
  const promise = new Promise((resolve) => {
    resolveNotice = resolve;
  });

  const timeout = setTimeout(() => {
    pendingApprovals.delete(id);
    appendLog({
      phase: "vault:locked-notice-timeout",
      origin,
      method
    }).catch(() => {});
    resolveNotice({ status: "timeout" });
  }, 2 * 60 * 1000);

  pendingApprovals.set(id, {
    approval,
    resolve: resolveNotice,
    reject: resolveNotice,
    promise,
    timeout,
    windowId: null
  });

  const approvalUrl = chrome.runtime.getURL(`src/approval.html?id=${encodeURIComponent(id)}`);
  const createdWindow = await openApprovalWindow(approvalUrl);
  const pending = pendingApprovals.get(id);
  if (pending) {
    pending.windowId = createdWindow.id;
  }
  return promise;
}

async function showTripwireDisabledNotice({ origin, method, params, address, policy }) {
  const id = `${Date.now()}-${Math.random().toString(16).slice(2)}`;
  const decoded = RequestDecoder.analyzeProviderRequest({
    origin,
    method,
    params,
    address,
    fallbackChainId: ""
  });
  const fields = Array.isArray(decoded.fields) ? decoded.fields.slice() : [];
  fields.unshift(
    { label: "Tripwire", value: policy.reason || "Account protection rule" },
    { label: "Disabled scope", value: "New orders and outbound fund movement are restricted." },
    { label: "Still allowed", value: "Cancel orders, risk-reducing actions, reads, and non-money-moving flows." },
    { label: "Re-enable", value: "Use the Passli extension recovery flow with a provisioned recovery/admin device." }
  );
  if (policy.notional !== undefined && policy.notional !== null && policy.notional !== "") {
    fields.splice(1, 0, { label: "Request value", value: `$${policy.notional}` });
  }

  const approval = {
    id,
    mode: "tripwire-disabled-notice",
    noticeOnly: true,
    title: "Tripwire Triggered",
    origin,
    method,
    params: redactForLog(params),
    address,
    summary: policy.message || "Cloud signer disabled protected signing for this account until recovery re-enable.",
    analysis: {
      ...decoded,
      requestType: "Account Disabled",
      subtype: "Tripwire rule triggered",
      fields
    },
    policy
  };

  await appendLog({
    phase: "approval:tripwire-disabled-notice-open",
    origin,
    method,
    params,
    result: {
      policy
    }
  });

  let resolveNotice;
  let rejectNotice;
  const promise = new Promise((resolve, reject) => {
    resolveNotice = resolve;
    rejectNotice = reject;
  });

  const timeout = setTimeout(() => {
    pendingApprovals.delete(id);
    appendLog({
      phase: "approval:tripwire-disabled-notice-timeout",
      origin,
      method
    }).catch(() => {});
    resolveNotice({ status: "dismissed", reason: "timeout" });
  }, 2 * 60 * 1000);

  pendingApprovals.set(id, {
    approval,
    resolve: resolveNotice,
    reject: rejectNotice,
    promise,
    timeout,
    windowId: null
  });
  promise.catch(() => {});

  const approvalUrl = chrome.runtime.getURL(`src/approval.html?id=${encodeURIComponent(id)}`);
  const createdWindow = await openApprovalWindow(approvalUrl);

  const pending = pendingApprovals.get(id);
  if (pending) {
    pending.windowId = createdWindow.id;
  }

  return { id, promise };
}

function reenableMessage(payload) {
  return [
    "Re-enable your Passli account?",
    "",
    "Only sign this if you are intentionally re-enabling protected signing for your Passli account.",
    "",
    `Type: ${payload.type}`,
    `Account: ${payload.accountId}`,
    `Disabled request: ${payload.disabledRequestId || "unknown"}`,
    `Disabled reason: ${payload.disabledReason || "unknown"}`,
    `Disabled at: ${payload.disabledAt || "unknown"}`,
    `Recovery address: ${payload.recoveryAddress}`,
    `Signer endpoint: ${payload.signerEndpointId}`,
    `Nonce: ${payload.nonce}`,
    `Expires at: ${payload.expiresAt}`
  ].join("\n");
}

async function submitReenableAuthorization(body) {
  const url = new URL("/api/cloud-sign/re-enable", PASSLI_API_URL).toString();
  const response = await fetch(url, {
    body: JSON.stringify(body),
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json"
    },
    method: "POST"
  });
  const text = await response.text();
  let payload = {};
  if (text) {
    try {
      payload = JSON.parse(text);
    } catch {
      payload = {};
    }
  }
  if (!response.ok) {
    if (response.status === 404) {
      throw new Error("Passli API does not have the re-enable endpoint yet. Restart or deploy the Passli API server, then try Re-enable Account again.");
    }
    throw new Error(payload.error || `Re-enable request failed: ${response.status}`);
  }
  return payload;
}

async function signReenableWithExternalAuthority(state, message, recoveryAccount) {
  const bridge = await startPassliBridgeRequest({
    origin: "extension",
    method: "personal_sign",
    params: [message, recoveryAccount.address],
    sender: null,
    address: recoveryAccount.address,
    analysis: {
      requestType: "Account Re-enable",
      subtype: "Recovery authority signature",
      fields: [
        { label: "Recovery wallet", value: recoveryAccount.address },
        { label: "Authority source", value: recoveryAccount.label || "External authority wallet" }
      ]
    }
  });
  await appendLog({
    phase: "account-reenable:external-authority-request",
    origin: "extension",
    method: "passli.reEnableAccount.v1",
    params: [{ recoveryAddress: recoveryAccount.address }],
    result: {
      bridgeRequestId: bridge.requestId,
      recoveryAddress: recoveryAccount.address
    }
  });
  await delay(500);
  await sendPassliBridgeApproval(bridge.requestId, true);
  return bridge.promise;
}

async function reenableAccountFromNotice(approval) {
  const state = await getState();
  const externalRecoveryAccount = selectedExternalAuthorityWalletForState(state);
  let status = null;
  if (!externalRecoveryAccount) {
    status = await walletConnectStatus(state);
  }
  const recoveryAccount = externalRecoveryAccount || (
    status && status.connected && status.account && status.account.address
      ? status.account
      : null
  );
  if (!recoveryAccount) {
    throw new Error("No recovery/admin wallet is connected. Connect a hardware wallet in passli.app under External authority wallet, or connect the extension WalletConnect wallet, then try Re-enable Account again.");
  }

  const now = new Date();
  const originalRequest = Array.isArray(approval.params) ? approval.params[0] || {} : {};
  const policy = approval.policy || {};
  const accountId = String(originalRequest.account || approval.address || state.passliExtensionAccountId || "");
  const payload = {
    type: "passli.reEnableAccount.v1",
    ask: "Re-enable your Passli account?",
    accountId,
    disabledRequestId: String(policy.logId || originalRequest.requestId || state.passliAccountDisabledRequestId || ""),
    disabledReason: String(policy.reason || state.passliAccountDisabledReason || "cloud-signer-disabled"),
    disabledAt: String(state.passliAccountDisabledAt || now.toISOString()),
    policyVersion: "demo-v1",
    signerEndpointId: PASSLI_API_URL,
    recoveryAddress: recoveryAccount.address,
    nonce: crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`,
    expiresAt: new Date(now.getTime() + 5 * 60 * 1000).toISOString(),
    chainId: recoveryAccount.chainId || state.signatureChainId
  };
  const message = reenableMessage(payload);

  await appendLog({
    phase: externalRecoveryAccount ? "account-reenable:external-authority-start" : "account-reenable:walletconnect-request",
    origin: "extension",
    method: "passli.reEnableAccount.v1",
    params: [payload],
    result: {
      recoveryAddress: recoveryAccount.address,
      recoverySource: externalRecoveryAccount ? "externalAuthority" : "walletconnect"
    }
  });

  const signature = externalRecoveryAccount
    ? await signReenableWithExternalAuthority(state, message, recoveryAccount)
    : await walletConnectSign(
      state,
      "personal_sign",
      [message, recoveryAccount.address],
      recoveryAccount.chainId || state.signatureChainId
    );
  const result = await submitReenableAuthorization({
    payload,
    message,
    signature
  });

  await setState({
    passliAccountDisabled: false,
    passliAccountDisabledAt: "",
    passliAccountDisabledReason: "",
    passliAccountDisabledRequestId: ""
  });
  await appendLog({
    phase: "account-reenable:submitted",
    origin: "extension",
    method: "passli.reEnableAccount.v1",
    result
  });
  return result;
}

async function requestWalletConnectNotice({ origin, method, params, address, summary, analysis, walletConnectRequest }) {
  const id = `${Date.now()}-${Math.random().toString(16).slice(2)}`;
  const decodedAnalysis = analysis || await decodeProviderRequest({
    origin,
    method,
    params,
    address,
    fallbackChainId: walletConnectRequest && walletConnectRequest.chainId
  });
  const approval = {
    id,
    mode: "walletconnect-status",
    title: walletConnectTitle(method),
    origin,
    method,
    params: redactForLog(params),
    address,
    summary,
    analysis: decodedAnalysis,
    walletConnectRequest
  };

  await appendLog({
    phase: "walletconnect:notice-open",
    origin,
    method,
    params,
    result: { summary }
  });

  let resolveResult;
  let rejectResult;
  const promise = new Promise((resolve, reject) => {
    resolveResult = resolve;
    rejectResult = reject;
  });

  const timeout = setTimeout(() => {
    pendingApprovals.delete(id);
    appendLog({
      phase: "walletconnect:notice-timeout",
      origin,
      method
    }).catch(() => {});
    rejectResult(new Error("Timed out waiting for WalletConnect."));
  }, 2 * 60 * 1000);

  pendingApprovals.set(id, {
    approval,
    resolve: resolveResult,
    reject: rejectResult,
    promise,
    timeout,
    windowId: null
  });

  const approvalUrl = chrome.runtime.getURL(`src/approval.html?id=${encodeURIComponent(id)}`);
  const createdWindow = await openApprovalWindow(approvalUrl);

  const pending = pendingApprovals.get(id);
  if (pending) {
    pending.windowId = createdWindow.id;
  }

  return { id, promise };
}

async function closePendingWindow(id) {
  const pending = pendingApprovals.get(id);
  if (!pending) return;
  pendingApprovals.delete(id);
  clearTimeout(pending.timeout);
  if (pending.windowId !== null) {
    try {
      await chrome.windows.remove(pending.windowId);
    } catch {
      // The user may have already closed it.
    }
  }
}

async function openApprovalWindow(url) {
  if (approvalWindowId !== null) {
    try {
      const existingWindow = await chrome.windows.get(approvalWindowId, { populate: true });
      const firstTab = existingWindow.tabs && existingWindow.tabs[0];
      if (firstTab && firstTab.id !== undefined) {
        await chrome.tabs.update(firstTab.id, { url });
        await chrome.windows.update(approvalWindowId, { focused: true });
        return existingWindow;
      }
    } catch {
      approvalWindowId = null;
    }
  }

  const createdWindow = await chrome.windows.create({
    url,
    type: "popup",
    width: 430,
    height: 640,
    focused: true
  });
  approvalWindowId = createdWindow.id;
  return createdWindow;
}

async function requireApproval(context) {
  const result = await requestApproval(context);
  if (result === "approved") return result;
  if (result && result.status === "approved") return result;
  throw new Error("User rejected the request");
}

async function requireSafeRequestApprovalIfNeeded(state, context) {
  if (state.autoApproveSafeRequests !== false) return;
  await requireApproval({
    ...context,
    safeRequest: true
  });
}

async function bridgeThroughPassli({ origin, method, params, sender, address, fallbackSummary }) {
  const analysis = await decodeProviderRequest({
    origin,
    method,
    params,
    address,
    fallbackChainId: ""
  });
  const bridge = await startPassliBridgeRequest({
    address,
    analysis,
    method,
    origin,
    params,
    sender
  });

  try {
    await requireApproval({
      origin,
      method,
      params,
      address,
      summary: fallbackSummary || "",
      bridgeRequestId: bridge.requestId,
      bridgeTabId: bridge.tabId
    });
  } catch (error) {
    await sendPassliBridgeApproval(bridge.requestId, false, error).catch(() => {});
    const pending = pendingBridgeRequests.get(bridge.requestId);
    if (pending) {
      clearTimeout(pending.timeout);
      pendingBridgeRequests.delete(bridge.requestId);
    }
    throw error;
  }

  await sendPassliBridgeApproval(bridge.requestId, true);
  return bridge.promise;
}

async function externalAuthoritySignThroughPassli({ state, origin, method, params, sender, account }) {
  const authorityWallet = externalAuthorityWalletForAddress(state, account.address) || selectedExternalAuthorityWalletForState(state);
  const walletLabel = authorityWallet?.label || account.label || "your external wallet";
  const analysis = await decodeProviderRequest({
    origin,
    method,
    params,
    address: account.address,
    fallbackChainId: account.chainId || state.chainId
  });
  const bridge = await startPassliBridgeRequest({
    address: account.address,
    analysis,
    authorityWalletId: authorityWallet?.id || "",
    authorityWalletLabel: walletLabel,
    method,
    origin,
    params,
    sender,
    signerType: "externalAuthority"
  });
  const summary = `Approve this request in ${walletLabel}. Passli cannot sign for this address.`;

  try {
    await requireApproval({
      origin,
      method,
      params,
      address: account.address,
      summary,
      analysis,
      signerType: "externalAuthority",
      authorityWalletLabel: walletLabel,
      bridgeRequestId: bridge.requestId,
      bridgeTabId: bridge.tabId
    });
  } catch (error) {
    await sendPassliBridgeApproval(bridge.requestId, false, error).catch(() => {});
    const pending = pendingBridgeRequests.get(bridge.requestId);
    if (pending) {
      clearTimeout(pending.timeout);
      pendingBridgeRequests.delete(bridge.requestId);
    }
    throw error;
  }

  await sendPassliBridgeApproval(bridge.requestId, true);
  return bridge.promise;
}

async function handleProviderRequest(message, sender) {
  let state = await getState();
  const origin = originFromSender(sender);
  const method = message.method;
  const params = Array.isArray(message.params) ? message.params : [];
  const wallet = new Ethers.Wallet(normalizeHexPrivateKey(state.privateKey));
  const selectedAccount = await getActiveAccount(state);
  await appendLog({
    phase: "provider:selected-account",
    origin,
    method,
    result: {
      signingMode: state.signingMode || "local",
      selectedPassliAddressId: state.selectedPassliAddressId || "",
      selectedAddress: selectedAddressStatusForState(state),
      activeAccount: selectedAccount,
      passliAddresses: passliCryptoAddressesForState(state)
        .map((address) => ({
          id: address.id,
          chainId: address.chainId,
          chainName: address.chainName,
          address: address.address,
          sourceRole: address.sourceRole || ""
        }))
    }
  });
  const selectedSignerType = state.signingMode === "walletconnect"
    ? "walletconnect"
    : state.signingMode === "externalAuthority"
      ? "externalAuthority"
      : "local";
  let connected = connectionForSender(state, sender, origin, selectedAccount);
  let connectedAccounts = connected ? connectionAccountsForSender(state, sender, origin) : [];
  if (connected) {
    connected = connectionWithAvailableSigner(state, connected);
    connectedAccounts = connectedAccounts.map((account) => accountWithAvailableSigner(state, account));
  }
  if (connected && !(await connectionIsDappSignable(state, connected))) {
    const connectedOrigins = revokeSenderConnection(state.connectedOrigins, sender, origin);
    await setState({ connectedOrigins });
    await appendLog({
      phase: "connection:revoked-unsignable-local-account",
      origin,
      method,
      result: {
        address: connected.account.address,
        connectionKey: connected.key
      }
    });
    state = {
      ...state,
      connectedOrigins
    };
    connected = null;
    connectedAccounts = [];
  }

  let trusted = connected ? null : trustedConnectionForOrigin(state, origin, selectedAccount);
  if (trusted) {
    trusted = connectionWithAvailableSigner(state, trusted);
  }
  if (trusted && !(await connectionIsDappSignable(state, trusted))) {
    const trustedDappOrigins = revokeTrustedOrigin(state.trustedDappOrigins, origin);
    await setState({ trustedDappOrigins });
    await appendLog({
      phase: "connection:ignored-unsignable-trusted-local-account",
      origin,
      method,
      result: {
        address: trusted.account.address
      }
    });
    state = {
      ...state,
      trustedDappOrigins
    };
    trusted = null;
  }

  const activeAccount = connected ? connected.account : selectedAccount;
  const signerType = connected ? connected.signerType : selectedSignerType;

  switch (method) {
    case "eth_requestAccounts": {
      if (connected) {
        const evmConnectedAccounts = evmProviderAccounts(connectedAccounts.length ? connectedAccounts : [activeAccount], state);
        if (!evmConnectedAccounts.length) return evmProviderAccountError(activeAccount, method);
        const trustedDappOrigins = trustOriginForAccounts(
          state.trustedDappOrigins,
          origin,
          evmConnectedAccounts,
          signerType
        );
        await setState({ trustedDappOrigins });
        await appendLog({
          phase: "approval:skipped-connected",
          origin,
          method,
          result: {
            address: activeAccount.address,
            accounts: evmConnectedAccounts.map((account) => account.address),
            connectionKey: connected.key
          }
        });
        return { result: evmConnectedAccounts.map((account) => account.address) };
      }

      if (trusted) {
        const trustedAccounts = evmProviderAccounts(trusted.accounts && trusted.accounts.length ? trusted.accounts : [trusted.account], state);
        if (!trustedAccounts.length) return evmProviderAccountError(trusted.account, method);
        const connectedOrigins = connectSenderToAccounts(
          state.connectedOrigins,
          sender,
          origin,
          trustedAccounts
        );
        await setState({ connectedOrigins });
        await appendLog({
          phase: "approval:skipped-trusted-origin",
          origin,
          method,
          result: {
            address: trusted.account.address,
            signerType: trusted.signerType
          }
        });
        return { result: trustedAccounts.map((account) => account.address) };
      }

      const compatibilityError = evmProviderAccountCompatibilityError(selectedAccount, state, method);
      if (compatibilityError) return compatibilityError;
      const availableWallets = await advertisableWalletsForState(state);
      if (!availableWallets.length) {
        return { error: { code: 4100, message: "No EVM Passli wallet is synced for the current session. Open passli.app and choose an EVM address such as Hyperliquid, Ethereum, Arbitrum, or Base." } };
      }

      const approvalResult = await requireApproval({
        origin,
        method,
        params,
        address: selectedAccount.address,
        availableWallets
      });
      const approvedAccounts = approvalResult && Array.isArray(approvalResult.accounts)
        ? approvalResult.accounts
        : evmProviderAccounts([selectedAccount], state);
      if (!approvedAccounts.length) {
        return { error: { code: 4100, message: "No EVM account was approved for this dApp." } };
      }
      const connectedOrigins = connectSenderToAccounts(
        state.connectedOrigins,
        sender,
        origin,
        approvedAccounts
      );
      const trustedDappOrigins = trustOriginForAccounts(
        state.trustedDappOrigins,
        origin,
        approvedAccounts.length ? approvedAccounts : [selectedAccount].filter((account) => account && account.address),
        (approvedAccounts[0] && approvedAccounts[0].signerType) || selectedSignerType
      );
      await setState({ connectedOrigins, trustedDappOrigins });
      return { result: approvedAccounts.map((account) => account.address) };
    }

    case "eth_accounts": {
      if (connected) {
        const evmConnectedAccounts = evmProviderAccounts(connectedAccounts.length ? connectedAccounts : [activeAccount], state);
        if (!evmConnectedAccounts.length) return evmProviderAccountError(activeAccount, method);
        return {
          result: evmConnectedAccounts.map((account) => account.address)
        };
      }

      if (trusted) {
        const trustedAccounts = evmProviderAccounts(trusted.accounts && trusted.accounts.length ? trusted.accounts : [trusted.account], state);
        if (!trustedAccounts.length) return [];
        const connectedOrigins = connectSenderToAccounts(
          state.connectedOrigins,
          sender,
          origin,
          trustedAccounts
        );
        await setState({ connectedOrigins });
        await appendLog({
          phase: "connection:rehydrated-trusted-origin",
          origin,
          method,
          result: {
            address: trusted.account.address,
            signerType: trusted.signerType
          }
        });
        return { result: trustedAccounts.map((account) => account.address) };
      }
      return {
        result: []
      };
    }

    case "eth_chainId": {
      const compatibilityError = evmProviderAccountCompatibilityError(activeAccount, state, method);
      if (compatibilityError) return compatibilityError;
      return { result: evmProviderChainId(activeAccount.chainId, state.chainId) };
    }

    case "net_version": {
      const compatibilityError = evmProviderAccountCompatibilityError(activeAccount, state, method);
      if (compatibilityError) return compatibilityError;
      return { result: String(Number.parseInt(evmProviderChainId(activeAccount.chainId, state.chainId), 16)) };
    }

    case "eth_coinbase": {
      if (connected) {
        await requireSafeRequestApprovalIfNeeded(state, {
          origin,
          method,
          params,
          address: activeAccount.address
        });
      }
      return { result: connected ? activeAccount.address : null };
    }

    case "hyperliquid_getCoreConfig": {
      await requireSafeRequestApprovalIfNeeded(state, {
        origin,
        method,
        params,
        address: connected ? activeAccount.address : ""
      });
      return {
        result: {
          hyperliquidChain: state.hyperliquidChain,
          signatureChainId: state.signatureChainId,
          signerAddress: connected ? activeAccount.address : null,
          note: "HyperCore is not an EVM chain ID. Core API actions use Hyperliquid action signing."
        }
      };
    }

    case "wallet_switchEthereumChain": {
      const requestedChainId = params[0] && params[0].chainId;
      if (!/^0x[0-9a-fA-F]+$/.test(String(requestedChainId || ""))) {
        return { error: { code: 4902, message: "Invalid chainId" } };
      }
      if (connected) {
        await setState({
          connectedOrigins: updateSenderConnectionChain(
            state.connectedOrigins,
            sender,
            origin,
            requestedChainId
          )
        });
        return { result: null };
      }
      return { result: null };
    }

    case "wallet_addEthereumChain": {
      const chain = params[0] || {};
      if (!/^0x[0-9a-fA-F]+$/.test(String(chain.chainId || ""))) {
        return { error: { code: 4902, message: "Invalid chainId" } };
      }
      if (connected) {
        await setState({
          connectedOrigins: updateSenderConnectionChain(
            state.connectedOrigins,
            sender,
            origin,
            chain.chainId
          )
        });
        return { result: null };
      }
      return { result: null };
    }

    case "wallet_getPermissions": {
      return {
        result: connected
          ? [{ parentCapability: "eth_accounts" }]
          : []
      };
    }

    case "wallet_requestPermissions": {
      if (connected) {
        const evmConnectedAccounts = evmProviderAccounts(connectedAccounts.length ? connectedAccounts : [activeAccount], state);
        if (!evmConnectedAccounts.length) return evmProviderAccountError(activeAccount, method);
        const trustedDappOrigins = trustOriginForAccounts(
          state.trustedDappOrigins,
          origin,
          evmConnectedAccounts,
          signerType
        );
        await setState({ trustedDappOrigins });
        await appendLog({
          phase: "approval:skipped-connected",
          origin,
          method,
          result: {
            address: activeAccount.address,
            accounts: evmConnectedAccounts.map((account) => account.address),
            connectionKey: connected.key
          }
        });
        return { result: [{ parentCapability: "eth_accounts" }] };
      }

      if (trusted) {
        const trustedAccounts = evmProviderAccounts(trusted.accounts && trusted.accounts.length ? trusted.accounts : [trusted.account], state);
        if (!trustedAccounts.length) return evmProviderAccountError(trusted.account, method);
        const connectedOrigins = connectSenderToAccounts(
          state.connectedOrigins,
          sender,
          origin,
          trustedAccounts
        );
        await setState({ connectedOrigins });
        await appendLog({
          phase: "approval:skipped-trusted-origin",
          origin,
          method,
          result: {
            address: trusted.account.address,
            signerType: trusted.signerType
          }
        });
        return { result: [{ parentCapability: "eth_accounts" }] };
      }

      const compatibilityError = evmProviderAccountCompatibilityError(selectedAccount, state, method);
      if (compatibilityError) return compatibilityError;
      const availableWallets = await advertisableWalletsForState(state);
      if (!availableWallets.length) {
        return { error: { code: 4100, message: "No EVM Passli wallet is synced for the current session. Open passli.app and choose an EVM address such as Hyperliquid, Ethereum, Arbitrum, or Base." } };
      }

      const approvalResult = await requireApproval({
        origin,
        method,
        params,
        address: selectedAccount.address,
        availableWallets
      });
      const approvedAccounts = approvalResult && Array.isArray(approvalResult.accounts)
        ? approvalResult.accounts
        : evmProviderAccounts([selectedAccount], state);
      if (!approvedAccounts.length) {
        return { error: { code: 4100, message: "No EVM account was approved for this dApp." } };
      }
      const connectedOrigins = connectSenderToAccounts(
        state.connectedOrigins,
        sender,
        origin,
        approvedAccounts
      );
      const trustedDappOrigins = trustOriginForAccounts(
        state.trustedDappOrigins,
        origin,
        approvedAccounts.length ? approvedAccounts : [selectedAccount].filter((account) => account && account.address),
        (approvedAccounts[0] && approvedAccounts[0].signerType) || selectedSignerType
      );
      await setState({ connectedOrigins, trustedDappOrigins });
      return { result: [{ parentCapability: "eth_accounts" }] };
    }

    case "wallet_revokePermissions": {
      const connectedOrigins = revokeSenderConnection(
        state.connectedOrigins,
        sender,
        origin
      );
      await setState({ connectedOrigins });
      if (connected) {
        await broadcastConnectionProviderEvent(connected, "accountsChanged", []);
      } else {
        await broadcastProviderEvent(origin, "accountsChanged", []);
      }
      return { result: null };
    }

    case "personal_sign": {
      const requestedAddress = requestedAddressForSigning(method, params);
      const signingAccount = accountForRequestedAddress(connectedAccounts, requestedAddress, activeAccount, signerType);
      if (!signingAccount || !signingAccount.address) {
        return { error: { code: 4100, message: "Requested account is not available" } };
      }
      if (signingAccount.signerType === "walletconnect") {
        return {
          result: await walletConnectSignWithNotice(state, {
            origin,
            method,
            params,
            address: signingAccount.address,
            fallbackChainId: signingAccount.chainId
          })
        };
      }
      if (signingAccount.signerType === "externalAuthority") {
        return {
          result: await externalAuthoritySignThroughPassli({
            state,
            origin,
            method,
            params,
            sender,
            account: signingAccount
          })
        };
      }
      const bridgeContext = {
          origin,
          method,
          params,
          sender,
          address: String(signingAccount.address)
        };
      try {
        return {
          result: await signWithVaultPath({
            state,
            origin,
            method,
            params,
            requestDeadline: Number(message.deadline),
            requestContext: { id: message.id, tabId: sender.tab?.id, frameId: sender.frameId, documentId: sender.documentId },
            activeAccount: signingAccount
          })
        };
      } catch (error) {
        return { result: await vaultBridgeFallback(bridgeContext, error) };
      }
    }

    case "eth_sign": {
      const requestedAddress = requestedAddressForSigning(method, params);
      const signingAccount = accountForRequestedAddress(connectedAccounts, requestedAddress, activeAccount, signerType);
      if (!signingAccount || !signingAccount.address) {
        return { error: { code: 4100, message: "Requested account is not available" } };
      }
      if (signingAccount.signerType === "walletconnect") {
        return {
          result: await walletConnectSignWithNotice(state, {
            origin,
            method,
            params,
            address: signingAccount.address,
            fallbackChainId: signingAccount.chainId
          })
        };
      }
      if (signingAccount.signerType === "externalAuthority") {
        return {
          result: await externalAuthoritySignThroughPassli({
            state,
            origin,
            method,
            params,
            sender,
            account: signingAccount
          })
        };
      }
      const bridgeContext = {
          origin,
          method,
          params,
          sender,
          address: String(signingAccount.address)
        };
      try {
        return {
          result: await signWithVaultPath({
            state,
            origin,
            method,
            params,
            requestDeadline: Number(message.deadline),
            requestContext: { id: message.id, tabId: sender.tab?.id, frameId: sender.frameId, documentId: sender.documentId },
            activeAccount: signingAccount
          })
        };
      } catch (error) {
        return { result: await vaultBridgeFallback(bridgeContext, error) };
      }
    }

    case "eth_signTypedData":
    case "eth_signTypedData_v3":
    case "eth_signTypedData_v4": {
      const requestedAddress = requestedAddressForSigning(method, params);
      const signingAccount = accountForRequestedAddress(connectedAccounts, requestedAddress, activeAccount, signerType);
      if (!signingAccount || !signingAccount.address) {
        return { error: { code: 4100, message: "Requested account is not available" } };
      }
      if (signingAccount.signerType === "walletconnect") {
        return {
          result: await walletConnectSignWithNotice(state, {
            origin,
            method,
            params,
            address: signingAccount.address,
            fallbackChainId: signingAccount.chainId
          })
        };
      }
      if (signingAccount.signerType === "externalAuthority") {
        return {
          result: await externalAuthoritySignThroughPassli({
            state,
            origin,
            method,
            params,
            sender,
            account: signingAccount
          })
        };
      }
      const bridgeContext = {
          origin,
          method,
          params,
          sender,
          address: String(signingAccount.address)
        };
      try {
        return {
          result: await signWithVaultPath({
            state,
            origin,
            method,
            params,
            requestDeadline: Number(message.deadline),
            requestContext: { id: message.id, tabId: sender.tab?.id, frameId: sender.frameId, documentId: sender.documentId },
            activeAccount: signingAccount
          })
        };
      } catch (error) {
        return { result: await vaultBridgeFallback(bridgeContext, error) };
      }
    }

    case "eth_blockNumber":
    case "eth_call":
    case "eth_estimateGas":
    case "eth_feeHistory":
    case "eth_gasPrice":
    case "eth_getBalance":
    case "eth_getBlockByHash":
    case "eth_getBlockByNumber":
    case "eth_getCode":
    case "eth_getLogs":
    case "eth_getStorageAt":
    case "eth_getTransactionByHash":
    case "eth_getTransactionCount":
    case "eth_getTransactionReceipt":
    case "eth_maxPriorityFeePerGas":
    case "eth_syncing":
    case "web3_clientVersion": {
      const compatibilityError = evmProviderAccountCompatibilityError(activeAccount, state, method);
      if (compatibilityError) return compatibilityError;
      await requireSafeRequestApprovalIfNeeded(state, {
        origin,
        method,
        params,
        address: connected ? activeAccount.address : ""
      });
      return rpcRequest(evmProviderChainId(activeAccount.chainId, state.chainId), method, params);
    }

    case "wallet_getCapabilities": {
      if (connected) {
        await requireSafeRequestApprovalIfNeeded(state, {
          origin,
          method,
          params,
          address: activeAccount.address
        });
      }

      const requestedChains = requestedCapabilityChains(
        params,
        activeAccount && activeAccount.chainId,
        state.chainId
      );
      const result = {};
      for (const normalized of requestedChains) {
        if (normalized === "0x3e7" || normalized === "0xa4b1" || normalized === "0x3e6") {
          result[normalized] = {
            hyperliquidAuthorizeAction: HYPERLIQUID_AUTHORIZE_ACTION_CAPABILITY
          };
        }
      }
      return { result };
    }

    case "wallet_watchAsset": {
      await requireSafeRequestApprovalIfNeeded(state, {
        origin,
        method,
        params,
        address: connected ? activeAccount.address : ""
      });
      return { result: true };
    }

    case "eth_sendTransaction": {
      const tx = params[0] || {};
      const requestedAddress = requestedAddressForSigning(method, params);
      const signingAccount = accountForRequestedAddress(connectedAccounts, requestedAddress, activeAccount, signerType);
      if (!signingAccount || !signingAccount.address) {
        return { error: { code: 4100, message: "Requested account is not available" } };
      }
      if (signingAccount.signerType === "walletconnect") {
        return {
          result: await walletConnectSignWithNotice(state, {
            origin,
            method,
            params,
            address: signingAccount.address,
            fallbackChainId: signingAccount.chainId
          })
        };
      }
      if (signingAccount.signerType === "externalAuthority") {
        return {
          result: await externalAuthoritySignThroughPassli({
            state,
            origin,
            method,
            params,
            sender,
            account: signingAccount
          })
        };
      }
      const bridgeContext = {
        origin,
        method,
        params,
        sender,
        address: String(signingAccount.address)
      };
      try {
        return {
          result: await sendTransactionWithExtensionVault({
            state,
            origin,
            method,
            params,
            activeAccount: signingAccount
          })
        };
      } catch (error) {
        try {
          return { result: await vaultBridgeFallback(bridgeContext, error) };
        } catch (fallbackError) {
          return {
            error: {
              code: fallbackError && fallbackError.code ? fallbackError.code : 4001,
              message: fallbackError && fallbackError.message ? fallbackError.message : "Could not send transaction.",
              data: fallbackError && fallbackError.data ? fallbackError.data : undefined
            }
          };
        }
      }
    }

    case "hyperliquid_authorizeAction": {
      if (!connected) {
        return { error: { code: 4100, message: "Connect an account before authorizing a Hyperliquid action." } };
      }
      const actionType = hyperliquidActionTypeFromParams(params);
      if (signerType === "externalAuthority") {
        return {
          result: await bridgeThroughPassli({
            origin,
            method,
            params,
            sender,
            address: activeAccount.address
          })
        };
      }
      try {
        return {
          result: await authorizeHyperliquidActionWithExtensionVault({
            state,
            origin,
            method,
            params,
            activeAccount
          })
        };
      } catch (error) {
        if (isHyperliquidCancelActionType(actionType)) {
          await appendKeyVaultVerboseLog({
            phase: "extension-vault:cancel-silent-path-failed",
            origin,
            method,
            params,
            result: {
              ...keyVaultStateSummary(state),
              actionType,
              activeAccount: activeAccount && activeAccount.address ? activeAccount.address : "",
              fallbackSummary: `Silent cancel failed because of a Passli implementation error: ${error && error.message ? error.message : String(error)}. Approve to route this cancel through the fallback path; reject to stop.`
            },
            error: error && error.message ? error.message : String(error)
          });
          await appendLog({
            phase: "diagnostic:cancel-fallback-requires-approval",
            origin,
            method,
            params,
            result: {
              actionType,
              reason: "Silent cancel path failed; user-approved fallback is allowed so order cancellation is not blocked."
            },
            error: error && error.message ? error.message : String(error)
          });
          return {
            result: await vaultBridgeFallback({
              origin,
              method,
              params,
              sender,
              address: activeAccount.address,
              fallbackSummary: `Silent cancel failed because of a Passli implementation error: ${error && error.message ? error.message : String(error)}. Approve to route this cancel through the fallback path; reject to stop.`
            }, error)
          };
        }
        if (error && error.noBridgeFallback) {
          return { error: providerError(error, error.code || 4001, "Could not authorize Hyperliquid action.") };
        }
        if (signerType !== "walletconnect") {
          return {
            result: await vaultBridgeFallback({
              origin,
              method,
              params,
              sender,
              address: activeAccount.address
            }, error)
          };
        }
        return { error: providerError(error, 4001, "Could not authorize Hyperliquid action.") };
      }
    }

    default:
      return { error: unsupported(method) };
  }
}

async function handleProviderRequestWithLog(message, sender) {
  const startedAt = Date.now();
  const origin = originFromSender(sender);
  const params = Array.isArray(message.params) ? message.params : [];

  await appendLog({
    phase: "request",
    origin,
    method: message.method,
    params
  });

  try {
    const response = await handleProviderRequest(message, sender);
    const debug = {
      origin,
      method: message.method,
      params,
      durationMs: Date.now() - startedAt,
      ok: !response.error
    };

    await appendLog({
      phase: response.error ? "error" : "response",
      ...debug,
      result: response.result,
      error: response.error
    });

    return {
      ...response,
      debug
    };
  } catch (error) {
    await appendLog({
      phase: "throw",
      origin,
      method: message.method,
      params,
      durationMs: Date.now() - startedAt,
      error: error && error.message ? error.message : String(error)
    });
    throw error;
  }
}

async function handleDebugMessage(message) {
  if (message.action === "getConfig") {
    return { result: await getExtensionConfig() };
  }

  if (message.action === "getConnections") {
    const state = await getState();
    const signerType = state.signingMode === "walletconnect"
      ? "walletconnect"
      : state.signingMode === "externalAuthority"
        ? "externalAuthority"
        : "local";
    let walletConnectStatusResult = null;
    let activeAccount = await getActiveAccount(state);
    let walletConnect = {
      connected: signerType === "walletconnect" && Boolean(state.walletConnectAccount),
      account: state.walletConnectAccount || null,
      accounts: state.walletConnectAccount ? [state.walletConnectAccount] : [],
      wallet: state.walletConnectWallet || null,
      label: state.walletConnectLabel || "",
      uri: state.walletConnectUri || ""
    };

    if (state.walletConnectProjectId) {
      try {
        const status = await walletConnectStatus(state);
        walletConnectStatusResult = status;
        walletConnect = {
          ...walletConnect,
          connected: signerType === "walletconnect" && Boolean(status.connected),
          account: status.account || state.walletConnectAccount || null,
          accounts: Array.isArray(status.accounts) ? status.accounts : [],
          wallet: status.wallet || state.walletConnectWallet || null,
          uri: signerType === "walletconnect" && !status.connected ? state.walletConnectUri || "" : ""
        };
      } catch (error) {
        walletConnect.error = error && error.message ? error.message : String(error);
      }
    }

    if (signerType === "walletconnect") {
      activeAccount = walletConnectStatusResult && walletConnectStatusResult.connected && walletConnectStatusResult.account
        ? walletConnectStatusResult.account
        : { address: "", chainId: "" };
    }

    return {
      result: {
        activeAccount,
        signerType,
        dapps: mergeConnectionAndTrustLists(
          listConnectionsForAccount(state.connectedOrigins || {}, activeAccount.address, state),
          listTrustedOriginsForAccount(state.trustedDappOrigins || {}, activeAccount.address)
        )
          .map((connection) => ({
            key: connection.key,
            origin: connection.origin,
            tabId: connection.tabId,
            signerType: connection.signerType,
            account: connection.account,
            trusted: Boolean(connection.trusted),
            trustedAt: connection.trustedAt || ""
          })),
        walletConnect: signerType === "walletconnect"
          ? walletConnect
          : { connected: false, account: null, accounts: [], wallet: null, label: "", uri: "" }
      }
    };
  }

  if (message.action === "revokeDappConnection") {
    const origin = String(message.origin || "");
    const connectionKey = String(message.connectionKey || "");
    const state = await getState();
    const activeAccount = await getActiveAccount(state);
    const connection = connectionKey
      ? normalizeConnectionRecord(
        connectionKey,
        state.connectedOrigins && state.connectedOrigins[connectionKey],
        origin || connectionKey,
        state,
        activeAccount.address
      )
      : null;
    const connectedOrigins = { ...(state.connectedOrigins || {}) };
    const trustedDappOrigins = revokeTrustedOrigin(state.trustedDappOrigins, origin);
    if (connectionKey) {
      delete connectedOrigins[connectionKey];
    } else {
      const next = revokeOriginForAccount(connectedOrigins, origin, activeAccount.address, state);
      Object.keys(connectedOrigins).forEach((key) => delete connectedOrigins[key]);
      Object.assign(connectedOrigins, next);
    }
    await setState({ connectedOrigins, trustedDappOrigins });
    if (connection) {
      await broadcastConnectionProviderEvent(connection, "accountsChanged", []);
    } else {
      await broadcastProviderEvent(origin, "accountsChanged", []);
    }
    await appendLog({
      phase: "connection:deleted",
      origin: connection ? connection.origin : origin,
      method: "revokeDappConnection",
      result: { address: activeAccount.address, connectionKey, trusted: false }
    });
    return { result: { origin, connectionKey, address: activeAccount.address, connected: false } };
  }

  if (message.action === "broadcastActiveAccountConnections") {
    const state = await getState();
    await broadcastActiveAccountConnections(state);
    return { result: true };
  }

  if (message.action === "setDefaultAccountSource") {
    const signingMode = message.signingMode === "walletconnect"
      ? "walletconnect"
      : message.signingMode === "externalAuthority"
        ? "externalAuthority"
        : "local";
    const previousState = await getState();
    const previousAccount = await getActiveAccount(previousState);
    const passliAddresses = passliCryptoAddressesForState(previousState);
    const requestedPassliAddressId = signingMode === "local"
      ? String(message.selectedPassliAddressId || previousState.selectedPassliAddressId || "")
      : "";
    const requestedPassliAddress = signingMode === "local" && requestedPassliAddressId
      ? passliAddresses.find((address) => address.id === requestedPassliAddressId) || null
      : null;
    if (signingMode === "local" && requestedPassliAddressId && !requestedPassliAddress) {
      await appendLog({
        phase: "connection:default-account-selection-missing",
        origin: "extension",
        method: message.action,
        result: {
          requestedPassliAddressId,
          availablePassliAddressIds: passliAddresses.map((address) => address.id)
        }
      });
      return {
        error: {
          code: 4100,
          message: `Selected Passli address was not found in the synced vault address list: ${requestedPassliAddressId}`
        }
      };
    }
    const selectedPassliAddress = signingMode === "local"
      ? requestedPassliAddress || passliAddresses[0] || null
      : null;
    const selectedExternalAuthorityWalletId = signingMode === "externalAuthority"
      ? String(message.externalAuthorityWalletId || previousState.selectedExternalAuthorityWalletId || "")
      : "";
    const externalAuthorityWallet = signingMode === "externalAuthority"
      ? (
        externalAuthorityWalletsForState(previousState).find((wallet) => wallet.id === selectedExternalAuthorityWalletId) ||
        selectedExternalAuthorityWalletForState({
          ...previousState,
          selectedExternalAuthorityWalletId
        })
      )
      : null;
    const requestedWalletConnectAddress = message.walletConnectAddress || previousState.selectedWalletConnectAddress || previousState.walletConnectAccount?.address || "";
    let selectedWalletConnectTopic = signingMode === "walletconnect"
      ? String(message.walletConnectTopic || previousState.selectedWalletConnectTopic || previousState.walletConnectAccount?.topic || "")
      : "";
    let selectedWalletConnectAddress = signingMode === "walletconnect"
      ? requestedWalletConnectAddress
        ? normalizeAddress(requestedWalletConnectAddress)
        : ""
      : "";
    if (signingMode === "walletconnect" && previousState.walletConnectProjectId) {
      const status = await WalletConnectBridge.status(previousState.walletConnectProjectId, {
        address: selectedWalletConnectAddress,
        topic: selectedWalletConnectTopic
      });
      const accounts = Array.isArray(status.accounts) ? status.accounts : [];
      const selectedAccount = accounts.find((account) =>
        String(account.topic || "") === String(selectedWalletConnectTopic || "") &&
        sameAddress(account.address, selectedWalletConnectAddress)
      ) || status.account || accounts[0] || null;
      selectedWalletConnectAddress = selectedAccount?.address || selectedWalletConnectAddress;
      selectedWalletConnectTopic = selectedAccount?.topic || selectedWalletConnectTopic;
      if (selectedAccount && selectedAccount.address) {
        await setState({
          walletConnectAccount: selectedAccount,
          walletConnectWallet: selectedAccount.wallet || status.wallet || null,
          selectedWalletConnectAddress,
          selectedWalletConnectTopic
        });
      }
    }
    const nextState = {
      ...previousState,
      signingMode,
      selectedExternalAuthorityWalletId: externalAuthorityWallet?.id || selectedExternalAuthorityWalletId,
      selectedPassliAddressId: selectedPassliAddress ? selectedPassliAddress.id : "",
      selectedWalletConnectAddress,
      selectedWalletConnectTopic
    };
    const nextAccount = await getActiveAccount(nextState);
    const signerType = signingMode === "walletconnect"
      ? "walletconnect"
      : signingMode === "externalAuthority"
        ? "externalAuthority"
        : "local";
    if (!nextAccount.address) {
      return {
        error: {
          code: 4100,
          message: signingMode === "walletconnect"
            ? "WalletConnect is not connected."
            : signingMode === "externalAuthority"
              ? "No external authority wallet is synced from passli.app."
            : "No Passli default wallet is synced."
        }
      };
    }
    await setState({
      signingMode,
      passliCryptoAddressLastUsedAt: selectedPassliAddress
        ? {
          ...(previousState.passliCryptoAddressLastUsedAt || {}),
          [selectedPassliAddress.id]: new Date().toISOString()
        }
        : previousState.passliCryptoAddressLastUsedAt || {},
      passliSelectedWallet: selectedPassliAddress
        ? passliWalletFromCryptoAddress(selectedPassliAddress, previousState)
        : null,
      selectedExternalAuthorityWalletId: externalAuthorityWallet?.id || selectedExternalAuthorityWalletId,
      selectedPassliAddressId: selectedPassliAddress ? selectedPassliAddress.id : "",
      selectedWalletConnectAddress,
      selectedWalletConnectTopic
    });

    let notifiedConnections = 0;
    let deliveredConnections = 0;
    let notifiedOrigins = [];
    let deliveries = [];
    if (nextState.notifyDappsOnDefaultAccountChange === true) {
      const rebound = await rebindConnectedOriginsToAccount(nextState, nextAccount, signerType);
      await setState({
        connectedOrigins: rebound.connectedOrigins,
        trustedDappOrigins: rebound.trustedDappOrigins
      });
      const finalState = {
        ...nextState,
        connectedOrigins: rebound.connectedOrigins,
        trustedDappOrigins: rebound.trustedDappOrigins
      };
      const connections = Object.entries(finalState.connectedOrigins || {})
        .map(([key, entry]) => normalizeConnectionRecord(
          key,
          entry,
          entry && entry.origin ? entry.origin : key,
          finalState,
          nextAccount.address
        ))
        .filter(Boolean);
      notifiedConnections = connections.length;
      notifiedOrigins = rebound.updatedOrigins;
      deliveries = await Promise.all(
        connections.map((connection) =>
          broadcastConnectionProviderEvent(connection, "accountsChanged", [nextAccount.address])
        )
      );
      deliveredConnections = deliveries.filter((delivery) => delivery && delivery.delivered).length;
    }

    await appendLog({
      phase: nextState.notifyDappsOnDefaultAccountChange === true
        ? "connection:default-account-notified"
        : "connection:default-account-changed",
      origin: "extension",
      method: message.action,
      result: {
        previousAddress: previousAccount.address || "",
        nextAddress: nextAccount.address,
        signingMode,
        selectedExternalAuthorityWalletId: signingMode === "externalAuthority" ? externalAuthorityWallet?.id || selectedExternalAuthorityWalletId : "",
        selectedPassliAddressId: selectedPassliAddress ? selectedPassliAddress.id : "",
        selectedWalletConnectAddress,
        selectedWalletConnectTopic,
        notifyDappsOnDefaultAccountChange: nextState.notifyDappsOnDefaultAccountChange === true,
        notifiedConnections,
        deliveredConnections,
        notifiedOrigins,
        deliveries
      }
    });

    return {
      result: {
        address: nextAccount.address,
        notifiedConnections,
        deliveredConnections,
        notifiedOrigins,
        signingMode
      }
    };
  }

  if (message.action === "getLog") {
    await logWriteQueue;
    const stored = await chrome.storage.local.get({ debugLog: [] });
    return { result: stored.debugLog };
  }

  if (message.action === "appendLog") {
    await appendLog(message.entry || {});
    return { result: true };
  }

  if (message.action === "appendContentDebugLog") {
    await appendLog({
      origin: message.origin || "page",
      phase: message.phase || "content-script",
      method: message.method || "inpage",
      params: message.params,
      result: message.result,
      error: message.error
    });
    return { result: true };
  }

  if (message.action === "clearLog") {
    await queueLogWrite(() => chrome.storage.local.set({ debugLog: [] }));
    return { result: [] };
  }

  if (message.action === "walletConnectStatus") {
    const state = await getState();
    return { result: await walletConnectStatus(state) };
  }

  if (message.action === "refreshVaultCryptoAddresses") {
    return { result: await refreshVaultCryptoAddressesForSession({ accountId: (await getState()).passliExtensionAccountId }) };
  }

  if (message.action === "hyperliquidMultisigStatus") {
    const state = await getState();
    return { result: await hyperliquidMultisigStatusForState(state) };
  }

  if (message.action === "setHyperliquidMultisigMode") {
    return setHyperliquidMultisigMode(message);
  }

  if (message.action === "walletConnectConnect") {
    await appendLog({
      phase: "walletconnect:connect-blocked",
      origin: "extension",
      method: "walletConnectConnect",
      error: "Extension-owned WalletConnect pairing is disabled. Pair authority wallets from passli.app."
    });
    return {
      error: {
        code: 4100,
        message: "Extension-owned WalletConnect pairing is disabled. Open passli.app to connect an authority wallet."
      }
    };
  }

  if (message.action === "walletConnectDisconnect") {
    const state = await getState();
    if (state.walletConnectProjectId) {
      await WalletConnectBridge.disconnect(state.walletConnectProjectId);
    }
    await setState({
      signingMode: "local",
      walletConnectUri: "",
      walletConnectAccount: null,
      walletConnectWallet: null,
      walletConnectLabel: "",
      selectedWalletConnectAddress: "",
      selectedWalletConnectTopic: ""
    });
    await appendLog({
      phase: "walletconnect:disconnect",
      origin: "extension",
      method: "walletConnectDisconnect"
    });
    return { result: { connected: false } };
  }

  return { error: { code: 4200, message: "Unknown debug action" } };
}

async function handlePassliExtensionLoginComplete(message, sender) {
  const origin = message.origin || originFromSender(sender);
  if (!PASSLI_AUTH_ORIGINS.has(origin)) {
    await appendLog({
      phase: "passli-extension-login:rejected",
      origin,
      method: "complete",
      error: "Unexpected origin"
    });
    return { error: { code: 4001, message: "Unexpected Passli login origin." } };
  }
  try {
    assertCompatibleWebVersion(message);
  } catch (error) {
    await appendLog({
      phase: "passli-extension-version:mismatch",
      origin,
      method: "complete",
      result: {
        appVersion: message.appVersion || "",
        extensionVersion: extensionVersion(),
        requiredWebVersion: PASSLI_REQUIRED_WEB_VERSION
      },
      error: error.message
    });
    return { error: { code: error.code || 426, message: error.message } };
  }

  const requestId = String(message.requestId || "");
  const session = message.session || {};
  const selectedWallet = message.selectedWallet || null;
  const selectedAddress = message.selectedAddress || null;
  const selectedAddressId = String(message.selectedAddressId || selectedAddress?.id || passliAddressId(selectedAddress) || "");
  const stored = await chrome.storage.local.get({
    passliExtensionAccountId: "",
    passliExtensionAlias: "",
    passliExtensionLoggedIn: false,
    passliExtensionLoginRequestId: ""
  });
  if (!requestId || requestId !== stored.passliExtensionLoginRequestId) {
    if (
      stored.passliExtensionLoggedIn === true &&
      session.accountId &&
      String(stored.passliExtensionAccountId || "") === String(session.accountId) &&
      (!session.alias || String(stored.passliExtensionAlias || "") === String(session.alias))
    ) {
      await appendLog({
        phase: "passli-extension-login:already-complete",
        origin,
        method: "complete",
        result: {
          accountId: session.accountId,
          alias: session.alias || "",
          expectedRequestId: stored.passliExtensionLoginRequestId || "",
          requestId
        }
      });
      return { result: true };
    }
    await appendLog({
      phase: "passli-extension-login:rejected",
      origin,
      method: "complete",
      result: { requestId, expectedRequestId: stored.passliExtensionLoginRequestId || "" },
      error: "Unknown login request"
    });
    return { error: { code: 4001, message: "Unknown extension login request." } };
  }
  if (!session.alias || !session.accountId) {
    return { error: { code: 4001, message: "Passli login session is incomplete." } };
  }

  const enrichedSelectedWallet = selectedWallet && selectedWallet.address
    ? enrichPassliSelectedWallet(selectedWallet, session)
    : null;
  const storedAuth = await chrome.storage.local.get({
    passliExtensionLoggedIn: false,
    passliExtensionAccountId: "",
    passliExtensionAlias: "",
    passliExtensionCloudSignerAddress: "",
    passliExtensionCredentialId: "",
    passliExtensionDeviceId: "",
    passliExtensionHlMultisigSignerAddress: "",
    passliExtensionAuthOrigin: "",
    passliSelectedWallet: null
  });
  if (sameStoredPassliAuthState(storedAuth, session, enrichedSelectedWallet, origin)) {
    await refreshVaultCryptoAddressesForSession(session, selectedAddressId).catch(async (error) => {
      await clearPassliVaultAddressSelection();
      await appendLog({
        phase: "passli-extension-address-sync:error",
        origin,
        method: "complete",
        error: error && error.message ? error.message : String(error)
      });
    });
    return { result: true };
  }
  const previousState = await getState();
  await chrome.storage.local.set({
    passliExtensionLoggedIn: true,
    passliExtensionAccountId: String(session.accountId),
    passliExtensionAlias: String(session.alias),
    passliExtensionCloudSignerAddress: enrichedSelectedWallet?.cloudSignerAddress || String(session.cloudSignerAddress || ""),
    passliExtensionCredentialId: String(session.credentialId || ""),
    passliExtensionDeviceId: String(session.deviceId || ""),
    passliExtensionHlMultisigSignerAddress: enrichedSelectedWallet?.hlMultisigSignerAddress || String(session.hlMultisigSignerAddress || ""),
    passliExtensionLoginAt: new Date().toISOString(),
    passliExtensionAuthOrigin: origin,
    passliExtensionLoginRequestId: "",
    passliExtensionLoginRequestCreatedAt: "",
    passliSelectedWallet: null
  });
  await refreshVaultCryptoAddressesForSession(session, selectedAddressId).catch(async (error) => {
    await clearPassliVaultAddressSelection();
    await appendLog({
      phase: "passli-extension-address-sync:error",
      origin,
      method: "complete",
      error: error && error.message ? error.message : String(error)
    });
  });
  const nextState = await getState();
  const dappNotification = await rebindAndBroadcastSelectedWalletChange(
    previousState,
    nextState,
    origin,
    "complete"
  );
  await appendLog({
    phase: "passli-extension-login:complete",
    origin,
    method: "complete",
    result: {
      alias: session.alias,
      accountId: session.accountId,
      requestId,
      selectedWallet: enrichedSelectedWallet,
      dappNotification
    }
  });
  return { result: true };
}

async function handlePassliExtensionAuthStatus(message, sender) {
  const origin = message.origin || originFromSender(sender);
  if (!PASSLI_AUTH_ORIGINS.has(origin)) {
    await appendLog({
      phase: "passli-extension-auth-sync:rejected",
      origin,
      method: "authStatus",
      error: "Unexpected origin"
    });
    return { error: { code: 4001, message: "Unexpected Passli auth origin." } };
  }
  try {
    assertCompatibleWebVersion(message);
  } catch (error) {
    await appendLog({
      phase: "passli-extension-version:mismatch",
      origin,
      method: "authStatus",
      result: {
        appVersion: message.appVersion || "",
        extensionVersion: extensionVersion(),
        requiredWebVersion: PASSLI_REQUIRED_WEB_VERSION
      },
      error: error.message
    });
    return { error: { code: error.code || 426, message: error.message } };
  }

  const status = String(message.status || "").trim();
  const session = message.session || {};
  const selectedWallet = message.selectedWallet || null;
  const selectedAddress = message.selectedAddress || null;
  const selectedAddressId = String(message.selectedAddressId || selectedAddress?.id || passliAddressId(selectedAddress) || "");

  if (status === "logged_out") {
    const storedLogout = await chrome.storage.local.get({
      passliExtensionLoggedIn: false,
      passliExtensionAccountId: "",
      passliExtensionAlias: "",
      passliExtensionAuthOrigin: ""
    });
    if (
      storedLogout.passliExtensionLoggedIn === false &&
      !storedLogout.passliExtensionAccountId &&
      !storedLogout.passliExtensionAlias &&
      String(storedLogout.passliExtensionAuthOrigin || "") === String(origin || "")
    ) {
      return { result: true };
    }
    await chrome.storage.local.set({
      passliExtensionLoggedIn: false,
      passliExtensionAccountId: "",
      passliExtensionAlias: "",
      passliExtensionCloudSignerAddress: "",
      passliExtensionCredentialId: "",
      passliExtensionDeviceId: "",
      passliExtensionHlMultisigSignerAddress: "",
      passliExtensionLoginAt: "",
      passliExtensionAuthOrigin: origin,
      passliExtensionLoginRequestId: "",
      passliExtensionLoginRequestCreatedAt: "",
      passliCryptoAddresses: [],
      passliSelectedWallet: null,
      selectedPassliAddressId: ""
    });
    await appendLog({
      phase: "passli-extension-auth-sync:logout",
      origin,
      method: "authStatus",
      result: {
        retainedDappConnections: true
      }
    });
    return { result: true };
  }

  if (status !== "logged_in") {
    return { error: { code: 4001, message: "Unknown Passli auth status." } };
  }

  if (!session.alias || !session.accountId) {
    return { error: { code: 4001, message: "Passli auth session is incomplete." } };
  }

  const enrichedSelectedWallet = selectedWallet && selectedWallet.address
    ? enrichPassliSelectedWallet(selectedWallet, session)
    : null;
  const storedAuth = await chrome.storage.local.get({
    passliExtensionLoggedIn: false,
    passliExtensionAccountId: "",
    passliExtensionAlias: "",
    passliExtensionCloudSignerAddress: "",
    passliExtensionCredentialId: "",
    passliExtensionDeviceId: "",
    passliExtensionHlMultisigSignerAddress: "",
    passliExtensionAuthOrigin: "",
    passliSelectedWallet: null,
    selectedPassliAddressId: ""
  });
  if (
    sameStoredPassliAuthState(storedAuth, session, enrichedSelectedWallet, origin) &&
    (!selectedAddressId || String(storedAuth.selectedPassliAddressId || "") === selectedAddressId)
  ) {
    await refreshVaultCryptoAddressesForSession(session, selectedAddressId).catch(async (error) => {
      await clearPassliVaultAddressSelection();
      await appendLog({
        phase: "passli-extension-address-sync:error",
        origin,
        method: "authStatus",
        error: error && error.message ? error.message : String(error)
      });
    });
    return { result: true };
  }
  const previousState = await getState();
  await chrome.storage.local.set({
    passliExtensionLoggedIn: true,
    passliExtensionAccountId: String(session.accountId),
    passliExtensionAlias: String(session.alias),
    passliExtensionCloudSignerAddress: enrichedSelectedWallet?.cloudSignerAddress || String(session.cloudSignerAddress || ""),
    passliExtensionCredentialId: String(session.credentialId || ""),
    passliExtensionDeviceId: String(session.deviceId || ""),
    passliExtensionHlMultisigSignerAddress: enrichedSelectedWallet?.hlMultisigSignerAddress || String(session.hlMultisigSignerAddress || ""),
    passliExtensionLoginAt: new Date().toISOString(),
    passliExtensionAuthOrigin: origin,
    passliExtensionLoginRequestId: "",
    passliExtensionLoginRequestCreatedAt: "",
    passliSelectedWallet: null
  });
  await refreshVaultCryptoAddressesForSession(session, selectedAddressId).catch(async (error) => {
    await clearPassliVaultAddressSelection();
    await appendLog({
      phase: "passli-extension-address-sync:error",
      origin,
      method: "authStatus",
      error: error && error.message ? error.message : String(error)
    });
  });
  const nextState = await getState();
  const dappNotification = await rebindAndBroadcastSelectedWalletChange(
    previousState,
    nextState,
    origin,
    "authStatus"
  );
  await appendLog({
    phase: "passli-extension-auth-sync:login",
    origin,
    method: "authStatus",
    result: {
      alias: session.alias,
      accountId: session.accountId,
      selectedWallet: enrichedSelectedWallet,
      dappNotification
    }
  });
  return { result: true };
}

async function handleWalletConnectPairingPort(port) {
  const send = (message) => {
    try {
      port.postMessage(message);
    } catch {
      // The popup can close before WalletConnect pairing finishes. Storage is still updated below.
    }
  };
  await appendLog({
    phase: "walletconnect:pairing-port-blocked",
    origin: "extension",
    method: "walletConnectConnect",
    error: "Extension-owned WalletConnect pairing is disabled. Pair authority wallets from passli.app."
  });
  send({
    type: "error",
    error: {
      code: 4100,
      message: "Extension-owned WalletConnect pairing is disabled. Open passli.app to connect an authority wallet."
    }
  });
  port.disconnect();
}

function handleWalletConnectSigningPort(port) {
  let activeId = null;

  port.onMessage.addListener((message) => {
    if (!message || !message.id) return;

    if (message.action === "open") {
      activeId = message.id;
      walletConnectSigningPorts.set(activeId, port);
      appendLog({
        phase: "walletconnect:notice-port-open",
        origin: "extension",
        method: "walletConnectSigningPort",
        result: { id: activeId }
      }).catch(() => {});
      return;
    }

    if (message.action === "ping") {
      appendLog({
        phase: "walletconnect:notice-port-ping",
        origin: "extension",
        method: "walletConnectSigningPort",
        result: { id: message.id }
      }).catch(() => {});
    }
  });

  port.onDisconnect.addListener(() => {
    if (!activeId) return;
    walletConnectSigningPorts.delete(activeId);
    appendLog({
      phase: "walletconnect:notice-port-closed",
      origin: "extension",
      method: "walletConnectSigningPort",
      result: { id: activeId }
    }).catch(() => {});
  });
}

function approvalBridgeResultFromResponse(response) {
  return response.status === "approved"
    ? {
      result: response.result,
      status: "approved"
    }
    : {
      error: response.error || { message: "Passli bridge request failed." },
      status: response.status || "failed"
    };
}

function notifyApprovalStatusPorts(id, result) {
  const ports = approvalStatusPorts.get(id);
  if (!ports) return;
  for (const port of ports) {
    try {
      port.postMessage({
        action: "bridgeResult",
        id,
        result
      });
    } catch {
      // A disconnected port will be removed by its onDisconnect handler.
    }
  }
}

function handleApprovalStatusPort(port) {
  let activeId = null;

  port.onMessage.addListener((message) => {
    if (!message || message.action !== "open" || !message.id) return;
    activeId = String(message.id);
    const ports = approvalStatusPorts.get(activeId) || new Set();
    ports.add(port);
    approvalStatusPorts.set(activeId, ports);

    const pending = pendingApprovals.get(activeId);
    if (pending && pending.bridgeResult) {
      notifyApprovalStatusPorts(activeId, pending.bridgeResult);
    }
  });

  port.onDisconnect.addListener(() => {
    if (!activeId) return;
    const ports = approvalStatusPorts.get(activeId);
    if (!ports) return;
    ports.delete(port);
    if (!ports.size) approvalStatusPorts.delete(activeId);
  });
}

async function handleApprovalMessage(message) {
  const pending = pendingApprovals.get(message.id);
  if (!pending) {
    if (message.action === "reenable" && message.approval && message.approval.noticeOnly) {
      try {
        const result = await reenableAccountFromNotice(message.approval);
        return { result };
      } catch (error) {
        await appendLog({
          phase: "account-reenable:error",
          origin: message.approval.origin || "extension",
          method: message.approval.method || "passli.reEnableAccount.v1",
          result: {
            recoveredFromNoticePayload: true
          },
          error: error && error.message ? error.message : String(error)
        });
        return {
          error: {
            code: error && error.code ? error.code : 4001,
            message: error && error.message ? error.message : "Account re-enable failed."
          }
        };
      }
    }
    return { error: { code: 4001, message: "Approval request not found" } };
  }

  if (message.action === "get") {
    return { result: pending.approval };
  }

  if (pending.approval.noticeOnly && message.action === "reenable") {
    try {
      const result = await reenableAccountFromNotice(pending.approval);
      clearTimeout(pending.timeout);
      pendingApprovals.delete(message.id);
      pending.resolve({ status: "reenabled", result });
      return { result };
    } catch (error) {
      await appendLog({
        phase: "account-reenable:error",
        origin: pending.approval.origin,
        method: pending.approval.method,
        error: error && error.message ? error.message : String(error)
      });
      return {
        error: {
          code: error && error.code ? error.code : 4001,
          message: error && error.message ? error.message : "Account re-enable failed."
        }
      };
    }
  }

  if (pending.approval.noticeOnly && pending.approval.mode === "vault-locked" && message.action === "openPassli") {
    try {
      const tabId = await openPassliAppForUnlock();
      clearTimeout(pending.timeout);
      pendingApprovals.delete(message.id);
      await appendLog({
        phase: "vault:locked-notice-open-passli",
        origin: pending.approval.origin,
        method: pending.approval.method,
        result: { tabId }
      });
      pending.resolve({ status: "opened-passli", tabId });
      return { result: { openedPassli: true, tabId } };
    } catch (error) {
      return {
        error: {
          code: error && error.code ? error.code : 4001,
          message: error && error.message ? error.message : "Could not open passli.app."
        }
      };
    }
  }

  if (pending.approval.noticeOnly) {
    clearTimeout(pending.timeout);
    pendingApprovals.delete(message.id);
    if (pending.windowId !== null) {
      chrome.windows.remove(pending.windowId).catch(() => {});
    }
    await appendLog({
      phase: "approval:notice-dismissed",
      origin: pending.approval.origin,
      method: pending.approval.method,
      result: {
        mode: pending.approval.mode || "notice"
      }
    });
    pending.resolve({ status: "dismissed" });
    return { result: true };
  }

  if (message.action === "walletconnectResult") {
    clearTimeout(pending.timeout);
    await appendLog({
      phase: "walletconnect:response",
      origin: pending.approval.origin,
      method: pending.approval.method,
      result: message.result
    });
    pending.resolve(message.result);
    return { result: true };
  }

  if (message.action === "walletconnectError") {
    clearTimeout(pending.timeout);
    await appendLog({
      phase: "walletconnect:error",
      origin: pending.approval.origin,
      method: pending.approval.method,
      error: message.error || "WalletConnect request failed."
    });
    pending.reject(new Error(message.error || "WalletConnect request failed."));
    return { result: false };
  }

  if (message.action === "details") {
    if (!pending.bridgeTabId || !pending.bridgeRequestId) {
      return { error: { code: 4001, message: "No Passli detail page is attached to this request." } };
    }
    await focusPassliBridgeRequest(pending.bridgeTabId, pending.bridgeRequestId);
    return { result: true };
  }

  if (message.action === "bridgeStatus") {
    if (!pending.bridgeRequestId) {
      return { error: { code: 4001, message: "No Passli bridge request is attached to this approval." } };
    }
    if (!pending.bridgeResult) {
      return { result: { status: "pending" } };
    }
    const bridgeResult = pending.bridgeResult;
    if (bridgeResult.status === "approved") {
      pendingApprovals.delete(message.id);
      if (pending.bridgeResultCleanup) clearTimeout(pending.bridgeResultCleanup);
      return { result: bridgeResult };
    }
    return { result: bridgeResult };
  }

  if (message.action !== "approve") {
    if (pending.approved && pending.bridgeRequestId && !pending.bridgeResult) {
      await cancelPassliBridgeRequest(
        pending.bridgeRequestId,
        Object.assign(new Error("User cancelled while waiting for passli.app."), { code: 4001 })
      );
    }
    clearTimeout(pending.timeout);
    pendingApprovals.delete(message.id);
  }

  if (message.action !== "approve" && pending.windowId !== null) {
    chrome.windows.remove(pending.windowId).catch(() => {});
  }

  if (message.action === "approve") {
    // Keep the review open on a connection failure. Recording consent alone
    // must not tell the popup that the signing request has completed.
    if (pending.cloudSigningIdentity) {
      try { await selectPairedCloudTab(pending.cloudSigningIdentity); }
      catch (error) { return { error: { code: error.code || 4100, message: error.message } }; }
    }
    let approvalResult = "approved";
    if (isConnectApprovalMethod(pending.approval.method)) {
      const availableWallets = Array.isArray(pending.approval.availableWallets)
        ? pending.approval.availableWallets
        : [];
      const selectedAccounts = approvedAccountsFromSelection(availableWallets, message.selectedWalletAddresses);
      if (!selectedAccounts.length) {
        return { error: { code: 4001, message: "Select at least one wallet to connect." } };
      }
      approvalResult = { status: "approved", accounts: selectedAccounts };
    }
    await appendLog({
      phase: "approval:approved",
      origin: pending.approval.origin,
      method: pending.approval.method,
      result: isConnectApprovalMethod(pending.approval.method)
        ? { accounts: approvalResult.accounts.map((account) => account.address) }
        : undefined
    });
    pending.approved = true;
    pending.resolve(approvalResult);
    if (pending.bridgeRequestId) {
      return { result: { pendingBridge: true, requestId: pending.bridgeRequestId } };
    }
    clearTimeout(pending.timeout);
    pendingApprovals.delete(message.id);
    return { result: true };
  }

  await appendLog({
    phase: "approval:rejected",
    origin: pending.approval.origin,
    method: pending.approval.method
  });
  pending.reject(new Error("User rejected the request"));
  return { result: false };
}

async function handlePassliBridgeResponse(message, sender) {
  const origin = message.origin || originFromSender(sender);
  if (!PASSLI_AUTH_ORIGINS.has(origin)) {
    await appendLog({
      phase: "passli-bridge:response-rejected",
      origin,
      method: "bridgeResponse",
      error: "Unexpected origin"
    });
    return { error: { code: 4001, message: "Unexpected Passli bridge origin." } };
  }

  const response = message.response || {};
  if (response.type !== PASSLI_BRIDGE_RESPONSE_TYPE || !response.requestId) {
    return { error: { code: 4001, message: "Invalid Passli bridge response." } };
  }

  const pending = pendingBridgeRequests.get(response.requestId);
  if (!pending) {
    return { error: { code: 4001, message: "Unknown Passli bridge request." } };
  }

  clearTimeout(pending.timeout);
  pendingBridgeRequests.delete(response.requestId);
  await appendLog({
    phase: response.status === "approved" ? "passli-bridge:response" : "passli-bridge:error",
    origin,
    method: "bridgeResponse",
    result: response.status === "approved" ? response.result : undefined,
    error: response.status === "approved" ? undefined : response.error
  });

  if (response.status === "approved") {
    setApprovalBridgeResult(response);
    pending.resolve(response.result);
    return { result: true };
  }

  const error = new Error(response.error && response.error.message ? response.error.message : "Passli bridge request failed.");
  error.code = response.error && response.error.code ? response.error.code : 4001;
  setApprovalBridgeResult(response);
  pending.reject(error);
  return { result: false };
}

function setApprovalBridgeResult(response) {
  for (const [id, pending] of pendingApprovals.entries()) {
    if (pending.bridgeRequestId !== response.requestId) continue;
    clearTimeout(pending.timeout);
    pending.bridgeResult = approvalBridgeResultFromResponse(response);
    notifyApprovalStatusPorts(id, pending.bridgeResult);
    if (response.status === "approved") {
      pending.bridgeResultCleanup = setTimeout(() => {
        for (const [id, nextPending] of pendingApprovals.entries()) {
          if (nextPending === pending) pendingApprovals.delete(id);
        }
      }, 30 * 1000);
    }
    return true;
  }
  return false;
}

function runtimeMessageName(message) {
  if (!message || typeof message !== "object") return "unknown";
  if (message.type === "HYPERLIQUID_DEMO_DEBUG") return `debug:${message.action || "unknown"}`;
  return message.type || message.method || "unknown";
}

function runtimeMessageOrigin(message, sender) {
  return message && message.origin
    ? message.origin
    : originFromSender(sender) || "extension";
}

function shouldAuditRuntimeMessage(message) {
  if (!message || typeof message !== "object") return false;
  if (message.type !== "HYPERLIQUID_DEMO_DEBUG") return true;
  return !["getLog", "clearLog", "getConfig", "walletConnectStatus"].includes(String(message.action || ""));
}

function runtimeMessageParams(message) {
  if (!message || typeof message !== "object") return undefined;
  if (message.type === "HYPERLIQUID_DEMO_PROVIDER_REQUEST") return Array.isArray(message.params) ? message.params : [];
  if (message.type === "HYPERLIQUID_DEMO_APPROVAL") {
    return {
      action: message.action || "",
      id: message.id || "",
      origin: message.origin || ""
    };
  }
  if (message.type === "HYPERLIQUID_DEMO_DEBUG") {
    return {
      action: message.action || "",
      params: message.params || undefined,
      signingMode: message.signingMode || undefined
    };
  }
  if (message.type === "PASSLI_EXTENSION_PROVISION_OPERATIONAL_KEYS") {
    const payload = message.payload || {};
    return {
      accountId: payload.accountId || "",
      appVersion: payload.appVersion || "",
      origin: message.origin || "",
      requestId: payload.requestId || "",
      requiredExtensionVersion: payload.requiredExtensionVersion || "",
      type: payload.type || "",
      version: payload.version || null,
      walletCount: payload.keyMaterial && Array.isArray(payload.keyMaterial.wallets) ? payload.keyMaterial.wallets.length : 0
    };
  }
  if (message.type === "PASSLI_EXTENSION_BRIDGE_RESPONSE") {
    const response = message.response || {};
    return {
      origin: message.origin || "",
      requestId: response.requestId || "",
      status: response.status || "",
      type: response.type || ""
    };
  }
  if (message.type === PASSLI_EXTERNAL_AUTHORITY_WALLETS_TYPE) {
    return {
      accountId: message.accountId || "",
      appVersion: message.appVersion || "",
      origin: message.origin || "",
      requiredExtensionVersion: message.requiredExtensionVersion || "",
      type: message.type || "",
      walletCount: Array.isArray(message.wallets) ? message.wallets.length : 0
    };
  }
  return {
    action: message.action || undefined,
    appVersion: message.appVersion || undefined,
    origin: message.origin || undefined,
    requestId: message.requestId || undefined,
    requiredExtensionVersion: message.requiredExtensionVersion || undefined,
    status: message.status || undefined,
    type: message.type || undefined
  };
}

function runtimeReplyResult(response) {
  if (!response || typeof response !== "object") return response;
  if (response.error) return undefined;
  if (response.result && typeof response.result === "object") {
    return {
      ...response.result,
      privateKey: undefined,
      seed: undefined,
      secret: undefined
    };
  }
  return response.result;
}

async function auditRuntimeIncoming(message, sender) {
  if (!shouldAuditRuntimeMessage(message)) return false;
  await appendLog({
    phase: "message:incoming",
    origin: runtimeMessageOrigin(message, sender),
    method: runtimeMessageName(message),
    params: runtimeMessageParams(message)
  });
  return true;
}

async function auditRuntimeReply(message, sender, startedAt, response, loggedIncoming) {
  if (!loggedIncoming) return;
  await appendLog({
    phase: response && response.error ? "message:reply-error" : "message:reply",
    origin: runtimeMessageOrigin(message, sender),
    method: runtimeMessageName(message),
    durationMs: Date.now() - startedAt,
    result: runtimeReplyResult(response),
    error: response && response.error ? response.error : undefined
  });
}

function respondWithAudit(message, sender, sendResponse, handler) {
  const startedAt = Date.now();
  auditRuntimeIncoming(message, sender)
    .catch(() => false)
    .then((loggedIncoming) => handler()
      .then(async (response) => {
        await auditRuntimeReply(message, sender, startedAt, response, loggedIncoming).catch(() => {});
        sendResponse(response);
      })
      .catch(async (error) => {
        const response = {
          error: {
            code: error && error.code ? error.code : -32603,
            message: error && error.message ? error.message : "Internal error"
          }
        };
        await auditRuntimeReply(message, sender, startedAt, response, loggedIncoming).catch(() => {});
        sendResponse(response);
      }));
  return true;
}

chrome.runtime.onInstalled.addListener(async () => {
  const config = await getExtensionConfig();
  const stored = await chrome.storage.local.get(null);
  const demo = demoAccountFromConfig(config);
  const patch = {
    ...DEFAULT_STATE,
    ...stored,
    privateKey: stored.privateKey || demo.privateKey,
    address: stored.address || demo.address,
    walletConnectProjectId: config.walletConnectProjectId || stored.walletConnectProjectId || "",
    connectedOrigins: stored.connectedOrigins || {},
    trustedDappOrigins: stored.trustedDappOrigins || {}
  };

  if (
    !stored.privateKey ||
    stored.address === "0x0000000000000000000000000000000000000abc" ||
    stored.chainId === "0x3e9"
  ) {
    patch.privateKey = demo.privateKey;
    patch.address = demo.address;
    patch.chainId = DEFAULT_STATE.chainId;
  }

  await setState(patch);
});

chrome.windows.onRemoved.addListener((windowId) => {
  if (approvalWindowId === windowId) {
    approvalWindowId = null;
  }

  for (const [id, pending] of pendingApprovals.entries()) {
    if (pending.windowId !== windowId) continue;
    clearTimeout(pending.timeout);
    if (!(pending.approved && pending.bridgeRequestId && !pending.bridgeResult)) {
      pendingApprovals.delete(id);
    }
    appendLog({
      phase: "approval:closed",
      origin: pending.approval.origin,
      method: pending.approval.method
    });
    if (!(pending.approved && pending.bridgeRequestId)) {
      pending.reject(new Error("Approval window closed"));
    }
  }
});

chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName !== "local") return;
  if (
    !changes.signingMode &&
    !changes.address &&
    !changes.chainId &&
    !changes.walletConnectAccount &&
    !changes.walletConnectWallet &&
    !changes.walletConnectLabel &&
    !changes.selectedWalletConnectAddress &&
    !changes.selectedWalletConnectTopic &&
    !changes.externalAuthorityWallets &&
    !changes.selectedExternalAuthorityWalletId &&
    !changes.passliCryptoAddresses &&
    !changes.selectedPassliAddressId
  ) {
    return;
  }
  getState()
    .then(broadcastExtensionWalletStatusToPassli)
    .catch(() => {});
});

chrome.runtime.onConnect.addListener((port) => {
  if (port.name === "approval-status") {
    handleApprovalStatusPort(port);
    return;
  }
  if (port.name === "walletconnect-pairing") {
    handleWalletConnectPairingPort(port);
    return;
  }

  if (port.name === "walletconnect-signing") {
    handleWalletConnectSigningPort(port);
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message && message.type === "HYPERLIQUID_DEMO_APPROVAL") {
    return respondWithAudit(message, sender, sendResponse, () => handleApprovalMessage(message));
  }

  if (message && message.type === "HYPERLIQUID_DEMO_DEBUG") {
    return respondWithAudit(message, sender, sendResponse, () => handleDebugMessage(message));
  }

  if (message && message.type === "PASSLI_EXTENSION_LOGIN_COMPLETE") {
    return respondWithAudit(message, sender, sendResponse, () => handlePassliExtensionLoginComplete(message, sender));
  }

  if (message && message.type === PASSLI_EXTENSION_AUTH_STATUS_TYPE) {
    return respondWithAudit(message, sender, sendResponse, () => handlePassliExtensionAuthStatus(message, sender));
  }

  if (message && message.type === PASSLI_EXTERNAL_AUTHORITY_WALLETS_TYPE) {
    return respondWithAudit(message, sender, sendResponse, async () => {
      const origin = message.origin || originFromSender(sender);
      assertAllowedPassliOrigin(origin);
      assertCompatibleWebVersion(message);
      const wallets = (Array.isArray(message.wallets) ? message.wallets : [])
        .map(normalizeExternalAuthorityWallet)
        .filter(Boolean);
      const previousState = await getState();
      const selectedStillExists = wallets.some((wallet) => wallet.id === previousState.selectedExternalAuthorityWalletId);
      await setState({
        externalAuthorityWallets: wallets,
        selectedExternalAuthorityWalletId: selectedStillExists ? previousState.selectedExternalAuthorityWalletId : ""
      });
      return {
        result: {
          walletCount: wallets.length
        }
      };
    });
  }

  if (message && message.type === PASSLI_EXTENSION_ADDRESSES_UPDATED_TYPE) {
    return respondWithAudit(message, sender, sendResponse, async () => {
      const origin = message.origin || originFromSender(sender);
      assertAllowedPassliOrigin(origin);
      assertCompatibleWebVersion(message);
      const state = await getState();
      const accountId = String(message.accountId || state.passliExtensionAccountId || "");
      const addresses = normalizePassliCryptoAddresses(message.addresses, accountId);
      const selectedId = String(message.selectedAddressId || "");
      const selectionState = passliSelectionStateForSync(state, addresses, accountId);
      const selectableAddresses = passliCryptoAddressesForState(selectionState);
      const selected = selectedSyncedPassliAddress(selectableAddresses, state, selectedId);
      await setState({
        passliCryptoAddresses: addresses,
        passliSelectedWallet: passliWalletFromCryptoAddress(selected, {
          ...selectionState,
          passliExtensionAccountId: accountId
        }),
        selectedPassliAddressId: selected ? selected.id : ""
      });
      await appendLog({
        phase: "passli-extension-address-sync:updated",
        origin,
        method: PASSLI_EXTENSION_ADDRESSES_UPDATED_TYPE,
        result: {
          addressCount: addresses.length,
          incomingSelectedAddressId: selectedId,
          selectedAddressId: selected ? selected.id : ""
        }
      });
      return {
        result: {
          addressCount: addresses.length,
          selectedAddressId: selected ? selected.id : ""
        }
      };
    });
  }

  if (message && message.type === "PASSLI_EXTENSION_PROVISION_OPERATIONAL_KEYS") {
    return respondWithAudit(message, sender, sendResponse, async () => {
      try {
        return { result: await saveProvisionedOperationalKeys(message, sender) };
      } catch (error) {
        await appendKeyVaultVerboseLog({
          phase: "extension-vault:provision-failed",
          origin: message.origin || originFromSender(sender),
          method: PASSLI_PROVISION_OPERATIONAL_KEYS_TYPE,
          result: {
            payloadType: message && message.payload ? message.payload.type || "" : "",
            requestId: message && message.payload ? message.payload.requestId || "" : ""
          },
          error: error && error.message ? error.message : String(error)
        }).catch(() => {});
        return {
          error: {
            code: error && error.code ? error.code : -32603,
            message: error && error.message ? error.message : "Could not provision extension key vault."
          }
        };
      }
    });
  }

  if (message && message.type === "PASSLI_EXTENSION_BRIDGE_RESPONSE") {
    return respondWithAudit(message, sender, sendResponse, () => handlePassliBridgeResponse(message, sender));
  }

  if (!message || message.type !== "HYPERLIQUID_DEMO_PROVIDER_REQUEST") {
    return false;
  }

  return respondWithAudit(message, sender, sendResponse, () => handleProviderRequestWithLog(message, sender));
});


// Isolated passkey feature; authenticated requests reuse the paired Passli tab.
globalThis.PassliPasskeyProvider.install({chrome,selectPairedTab:selectPairedCloudTab,log:appendLog});
globalThis.PassliExtensionProfiles.install({chrome,selectPairedTab:selectPairedCloudTab});
globalThis.PassliPasskeyReconnect.install({chrome,log:appendLog}).catch(()=>{});

// Legacy cloud adapters must use the paired browser's signing key. No secret
// is copied to the extension, and a closed/logged-out tab fails closed.
const unsignedFetch=globalThis.fetch.bind(globalThis);
const extensionStepUps=globalThis.PassliExtensionStepUp.create({chrome});
const pairedTabRecoveries=new Map();
async function recoverPairedCloudTab(tab){
 if(pairedTabRecoveries.has(tab.id))return pairedTabRecoveries.get(tab.id);
 const recovery=(async()=>{
   const current=await chrome.tabs.get(tab.id),origin=new URL(tab.url).origin;
   if(!PASSLI_AUTH_ORIGINS.has(origin)||current.url!==tab.url||(current.pendingUrl&&new URL(current.pendingUrl).origin!==origin))throw Error('Passli tab changed before reconnecting.');
   // Session storage survives service-worker suspension. Never repeatedly reload a broken page.
   const key='passliBridgeReload:'+tab.id,store=chrome.storage.session;
   const last=(await store.get(key))[key];
   if(Number.isFinite(last)&&Date.now()-last<60000)throw Error('Passli reconnect already attempted. Refresh Passli manually.');
   await store.set({[key]:Date.now()});
   if(typeof appendLog==='function')await appendLog({phase:'passkey:bridge-reload-started',origin,method:'PASSLI_SIGNED_CLOUD_PROBE'}).catch(()=>{});
   await chrome.tabs.reload(tab.id);
   const deadline=Date.now()+12000;
   let ready;
   while(Date.now()<deadline){
     const fresh=await chrome.tabs.get(tab.id);
     if(new URL(fresh.url).origin!==origin||(fresh.pendingUrl&&new URL(fresh.pendingUrl).origin!==origin))throw Error('Passli tab navigated while reconnecting.');
     try{ready=await chrome.tabs.sendMessage(tab.id,{type:'PASSLI_SIGNED_CLOUD_PROBE'});if(ready?.status===200){
       if(typeof appendLog==='function')await appendLog({phase:'passkey:bridge-reconnected',origin,method:'PASSLI_SIGNED_CLOUD_PROBE'}).catch(()=>{});
       return ready;
     }}catch{/* The newly loaded content script may not be ready yet. */}
     await new Promise(resolve=>setTimeout(resolve,250));
   }
   if(ready)return ready;
   throw Error('Passli reconnect timed out. Refresh Passli manually.');
 })();
 pairedTabRecoveries.set(tab.id,recovery);
 try{return await recovery;}finally{pairedTabRecoveries.delete(tab.id);}
}
async function selectPairedCloudTab(payload){
 const tabs=await chrome.tabs.query({});
 const accountId=payload.userId||payload.accountId||payload.uid||payload.payload?.accountId;
 const candidates=tabs.filter(tab=>{
   try{return tab.id!==undefined&&PASSLI_AUTH_ORIGINS.has(new URL(tab.url||'about:blank').origin)}catch{return false}
 }).sort((a,b)=>Number(Boolean(b.active))-Number(Boolean(a.active)));
 const reasons=new Set(),stale=[];
 // Probes have no signing side effects. Never send the operation to multiple tabs.
 // Prefer an already healthy tab before refreshing any stale candidate.
 for(const recovering of [false,true])for(const tab of recovering?stale:candidates){
   try{
     const ready=recovering?await recoverPairedCloudTab(tab):await chrome.tabs.sendMessage(tab.id,{type:'PASSLI_SIGNED_CLOUD_PROBE'});
     if(ready?.status!==200){reasons.add(ready?.status===401?'browser authorization missing':'page did not answer the connection check');continue;}
     if(ready.body?.stepUpProtocol!==1){reasons.add('page needs updating');continue;}
     if(accountId&&ready.body?.accountId!==accountId){reasons.add('different account');continue;}
     if(payload.deviceId&&ready.body?.deviceId!==payload.deviceId){reasons.add('different paired device');continue;}
     return {selectedTab:tab,selectedIdentity:ready.body};
   }catch(error){
     const message=String(error?.message||'');
     const reason=/receiving end does not exist|could not establish connection/i.test(message)?'Passli page receiver missing':/message (?:port|channel) closed|channel closed before|port closed/i.test(message)?'Passli page response channel closed':/context invalidated/i.test(message)?'Passli page extension context expired':/permission|cannot access|not allowed/i.test(message)?'Passli page access denied':'Passli page probe failed';
     if(!recovering&&typeof chrome.tabs.reload==='function'&&['Passli page receiver missing','Passli page extension context expired'].includes(reason))stale.push(tab);
     reasons.add(reason);
     if(typeof appendLog==='function')await appendLog({phase:recovering?'passkey:bridge-reload-failed':'passkey:bridge-probe-failed',origin:new URL(tab.url).origin,method:'PASSLI_SIGNED_CLOUD_PROBE',params:{reason,extensionVersion:chrome.runtime?.getManifest?.().version||'unknown'}}).catch(()=>{});
   }
 }
 const detail=candidates.length?[...reasons].join('; '):'no Passli tab is open in this browser';
 throw Object.assign(new Error(`Refresh Passli: ${detail}. Keep the matching account and paired browser signed in, then retry Approve.`),{code:4100,noBridgeFallback:true});
}
globalThis.fetch=async function(input,options={}){
 const url=new URL(input instanceof Request?input.url:String(input));
 const paths=['/vault/v1/evaluate_and_sign','/api/cloud-sign/l1-action','/api/cloud-sign/l1-action-policy','/api/cloud-sign/l1-action-result','/api/cloud-sign/re-enable','/api/cloud-sign/reenable','/vault/v1/crypto_addresses'];
 if(url.origin!==new URL(PASSLI_API_URL).origin||!paths.includes(url.pathname))return unsignedFetch(input,options);
 if(String(options.method||'GET').toUpperCase()!=='POST')throw new Error('Cloud signing requires a signed POST request.');
 const payload=JSON.parse(options.body||'{}');
 const {selectedTab,selectedIdentity}=await selectPairedCloudTab(payload);
 const send=async(path,body)=>{
   let result;
   try{result=await chrome.tabs.sendMessage(selectedTab.id,{type:'PASSLI_SIGNED_CLOUD_REQUEST',path,payload:body,extensionManagedApproval:true})}
   catch{throw Object.assign(new Error('The Passli signing tab disconnected. Check its approval before starting a new request.'),{code:-32603,noBridgeFallback:true})}
   if(!result||!Number.isInteger(result.status))throw Object.assign(new Error('The Passli signing tab returned no result. Check its approval before starting a new request.'),{code:-32603,noBridgeFallback:true});
   return result;
 };
 let result=await send(url.pathname,payload);
 if(result.status===403&&result.body?.code==='OPERATION_APPROVAL_REQUIRED'&&result.body.approval){
   const approval=result.body.approval;
   const requestActive=async()=>{
     const context=options.passliProviderRequest;
     if(!context||!Number.isInteger(context.tabId))return false;
     try{
       const state=await chrome.tabs.sendMessage(context.tabId,{type:'PASSLI_PROVIDER_REQUEST_PENDING',id:context.id},context.documentId?{documentId:context.documentId}:{frameId:context.frameId||0});
       return state?.pending===true;
     }catch{return false;}
   };
   result=await extensionStepUps.run({approval,origin:payload.canonicalAction?.dappOrigin||payload.dappOrigin||'',
     requestDeadline:options.passliRequestDeadline,
     requestActive:options.passliProviderRequest?requestActive:undefined,
     refresh:()=>{const fresh={...payload};delete fresh.operationApprovalId;return send(url.pathname,fresh);},
     send:async (action,id=approval.id)=>{
       const response=await send('/api/operation-approval',{userId:selectedIdentity.accountId,deviceId:selectedIdentity.deviceId,id,action});
       if(response.status!==200)throw Object.assign(Error(response.body?.error||'Step-up approval failed.'),{status:response.status,code:response.body?.code});
       return response.body;
     },
     complete:id=>send(url.pathname,{...payload,operationApprovalId:id})
   });
 }
 return new Response(JSON.stringify(result.body),{status:result.status,headers:{'Content-Type':'application/json'}});
};
