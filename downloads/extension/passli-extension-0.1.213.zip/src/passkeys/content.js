(() => {
 const runtime=chrome.runtime;
 const previous=globalThis.__passliPasskeyBridgeV2;
 if(previous?.alive())return;
 previous?.retire();
 const active=new Set();
 let retired=false;
 const alive=()=>{try{return !retired&&!!runtime.getManifest().version;}catch{return false;}};
 // A reloaded extension can invalidate this page's runtime synchronously.
 // Convert both synchronous throws and rejected sends into one rejected promise.
 const send=async message=>runtime.sendMessage(message);
 console.debug('[Passli passkeys]',{stage:'bridge-ready'});
 const trace=(stage,operation,reason)=>{send({type:'PASSLI_PASSKEY_TRACE_V1',stage,operation,reason}).catch(()=>{});};
 trace('bridge-ready');
 let traceCount=0,traceSince=Date.now();
 const receive=event=>{
  if(event.source!==window||event.origin!==location.origin)return;
  const m=event.data;
  if(m?.type==='PASSLI_PASSKEY_BRIDGE_RESET_V1'){if(!alive())retire();return;}
  if(retired)return;
  // A fresh capture listener supersedes pre-reconnect bubble listeners, including v202.
  if(['PASSLI_PASSKEY_TRACE_V1','PASSLI_PASSKEY_CANCEL_V1','PASSLI_PASSKEY_REQUEST_V1'].includes(m?.type))event.stopImmediatePropagation?.();
  if(m?.type==='PASSLI_PASSKEY_TRACE_V1'){
   if(Date.now()-traceSince>=60000){traceSince=Date.now();traceCount=0;}
   if(traceCount++<24&&['adapter-ready','request-intercepted','native-bypass'].includes(m.stage))trace(m.stage,['create','get'].includes(m.operation)?m.operation:undefined,['conditional-mediation','passli-origin'].includes(m.reason)?m.reason:undefined);
   return;
  }
  if(!m||typeof m.id!=='string'||m.id.length>128)return;
  if(m.type==='PASSLI_PASSKEY_CANCEL_V1'){if(active.delete(m.id))send({type:'PASSLI_PASSKEY_CANCEL_V1',id:m.id}).catch(()=>{});return;}
  if(m.type!=='PASSLI_PASSKEY_REQUEST_V1'||active.has(m.id)||active.size>=3)return;
  active.add(m.id);
  console.debug('[Passli passkeys]',{stage:'request-forwarded',operation:m.operation==='create'?'create':m.operation==='get'?'get':'invalid'});
  trace('request-forwarded',['create','get'].includes(m.operation)?m.operation:undefined);
  send({type:m.type,id:m.id,operation:m.operation,publicKey:m.publicKey}).then(result=>{
   if(!active.delete(m.id))return;
   window.postMessage({type:'PASSLI_PASSKEY_RESPONSE_V1',id:m.id,...result},location.origin);
  },()=>{trace('bridge-disconnected');if(active.delete(m.id))window.postMessage({type:'PASSLI_PASSKEY_RESPONSE_V1',id:m.id,error:{name:'NotAllowedError',message:'Passli connection ended. Wait for reconnection, then try again.'}},location.origin);});
 };
 const pending=(m,_sender,reply)=>{if(m?.type==='PASSLI_PASSKEY_BRIDGE_PING_V1'){reply({version:2});return false;}if(m?.type!=='PASSLI_PASSKEY_PENDING_V1')return false;reply({pending:active.has(m.id)});return false;};
 const hide=()=>{for(const id of active)send({type:'PASSLI_PASSKEY_CANCEL_V1',id}).catch(()=>{});active.clear();};
 function retire(){
  if(retired)return;retired=true;
  window.removeEventListener('message',receive,true);window.removeEventListener('pagehide',hide);
  try{runtime.onMessage.removeListener(pending);}catch{}
  for(const id of active)window.postMessage({type:'PASSLI_PASSKEY_RESPONSE_V1',id,error:{name:'AbortError',message:'Passli reconnected. Start a new passkey request.'}},location.origin);
  hide();
 }
 globalThis.__passliPasskeyBridgeV2={alive,retire};
 window.addEventListener('message',receive,true);
 try{runtime.onMessage.addListener(pending);}catch{}
 window.addEventListener('pagehide',hide);
 window.postMessage({type:'PASSLI_PASSKEY_BRIDGE_RESET_V1'},location.origin);
})();
