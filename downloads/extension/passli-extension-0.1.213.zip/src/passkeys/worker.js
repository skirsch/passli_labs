globalThis.PassliPasskeyProvider={install({chrome,selectPairedTab,log=async()=>{},now=Date.now}){
 const jobs=new Map(),endpoint='/api/passkey-provider';
 const diagnosticKey='passliPasskeyDiagnosticsV1';let diagnosticRows=[],diagnosticQueue=Promise.resolve();
 const errorName=e=>['NotSupportedError','SecurityError','DataError','InvalidStateError','ConstraintError','NotAllowedError','AbortError'].includes(e?.name)?e.name:'Error';
 function trace(stage,job={},extra={}){
  const row={at:new Date(now()).toISOString(),stage,...(job.id?{traceId:job.id}:{}),...(job.origin?{origin:job.origin}:{}),...(['create','get'].includes(job.operation)?{operation:job.operation}:{}),...extra};
  console.debug('[Passli passkeys]',row);
  diagnosticQueue=diagnosticQueue.then(async()=>{
   try{
    const store=chrome.storage.session;
    const rows=store?(await store.get(diagnosticKey))[diagnosticKey]||[]:diagnosticRows;
    diagnosticRows=[...rows.filter(r=>Date.parse(r.at)>now()-3600000),row].slice(-150);
    if(store)await store.set({[diagnosticKey]:diagnosticRows});
   }catch{}
   const {at,stage:recordedStage,origin,...details}=row;
   await log({time:at,phase:'passkey:'+recordedStage,origin:origin||'extension',method:row.operation?'webauthn.'+row.operation:'webauthn',params:details});
  }).catch(()=>{});
 }
 const knownExtensions=new Set(['credProps','appidExclude','appid','prf','largeBlob','hmacCreateSecret','credProtect','enforceCredentialProtectionPolicy','minPinLength','uvm','credBlob','getCredBlob']);
 const summary=options=>({extensionNames:[...new Set(Object.keys(options?.extensions||{}).map(k=>knownExtensions.has(k)?k:'other'))].slice(0,20),algorithms:(Array.isArray(options?.pubKeyCredParams)?options.pubKeyCredParams:[]).map(p=>p?.alg).filter(Number.isSafeInteger).slice(0,20),attachment:['platform','cross-platform'].includes(options?.authenticatorSelection?.authenticatorAttachment)?options.authenticatorSelection.authenticatorAttachment:'unspecified'});
 const error=(message,name='NotAllowedError')=>Object.assign(Error(message),{name});
 const uiURL=id=>chrome.runtime.getURL('src/passkeys/provider.html?id='+encodeURIComponent(id));
 const isUI=sender=>sender.id===chrome.runtime.id&&[chrome.runtime.getURL('src/passkeys/manage.html'),...Array.from(jobs.keys(),uiURL)].includes(sender.url);
 const isManager=sender=>sender.id===chrome.runtime.id&&sender.url===chrome.runtime.getURL('src/passkeys/manage.html');
 const binding=sender=>{
  if(sender.id!==chrome.runtime.id||sender.frameId!==0||!Number.isInteger(sender.tab?.id)||!sender.documentId)throw error('Invalid requesting document.','SecurityError');
  const url=new URL(sender.url);if(url.protocol!=='https:'||sender.origin!==url.origin)throw error('A top-level HTTPS document is required.','SecurityError');
  return {tabId:sender.tab.id,documentId:sender.documentId,origin:url.origin};
 };
 async function send(selected,body){
  const result=await chrome.tabs.sendMessage(selected.selectedTab.id,{type:'PASSLI_SIGNED_CLOUD_REQUEST',path:endpoint,payload:{version:1,...body,userId:selected.selectedIdentity.accountId,deviceId:selected.selectedIdentity.deviceId},extensionManagedApproval:false});
  if(!result||!Number.isInteger(result.status))throw error('The signed-in Passli tab disconnected.');
  if(result.status!==200)throw error(result.body?.error||'Passli could not finish the request.',['NotSupportedError','SecurityError','DataError','InvalidStateError','ConstraintError'].includes(result.body?.code)?result.body.code:'NotAllowedError');
  return result.body;
 }
 async function begin(job){
  trace('begin',job);
  await current(job);job.selected=await selectPairedTab({});await current(job);
  const options={...job.publicKey,timeout:Math.max(1,Math.min(job.publicKey.timeout??120000,job.expires-now()))};
  const preview=await send(job.selected,{action:'begin',operation:job.operation,origin:job.origin,publicKey:options});
  job.ceremony=preview.id;job.preview={...preview,requiresPassliLoginConfirmation:job.operation==='create'&&preview.rpId==='passli.app'};job.expires=Math.min(job.expires,preview.expires);
  trace('preview-ready',job,{verificationRequired:preview.verificationRequired===true});
  if(jobs.get(job.id)!==job){void send(job.selected,{action:'cancel',id:preview.id}).catch(()=>{});return;}
  await current(job);
 }
 async function current(job){
  if(jobs.get(job.id)!==job||job.expires<=now())throw error('Passkey request expired.');
  const tab=await chrome.tabs.get(job.tabId);if(new URL(tab.url).origin!==job.origin)throw error('The requesting website changed.');
  const state=await chrome.tabs.sendMessage(job.tabId,{type:'PASSLI_PASSKEY_PENDING_V1',id:job.pageId},{documentId:job.documentId});
  if(!state?.pending||jobs.get(job.id)!==job)throw error('The requesting page is no longer waiting.');
 }
 async function end(job,result){
  if(jobs.get(job.id)!==job)return;
  jobs.delete(job.id);clearTimeout(job.timer);
  trace(result.credential?'completed':result.fallback?'native-fallback':'ended',job,{...(result.error?{errorName:errorName(result.error)}:{})});
  let restoreFocus=false;
  if(result.credential&&job.focusedPassli)try{
   const [active]=await chrome.tabs.query({active:true,lastFocusedWindow:true});
   restoreFocus=active?.id===job.selected.selectedTab.id||active?.url===uiURL(job.id);
  }catch{}
  if(job.windowId)await chrome.windows.remove(job.windowId).catch(()=>{});
  if(restoreFocus)try{
    const tab=await chrome.tabs.get(job.tabId);
    const state=await chrome.tabs.sendMessage(job.tabId,{type:'PASSLI_PASSKEY_PENDING_V1',id:job.pageId},{documentId:job.documentId});
    if(new URL(tab.url).origin===job.origin&&state?.pending){await chrome.tabs.update(job.tabId,{active:true});if(Number.isInteger(tab.windowId))await chrome.windows.update(tab.windowId,{focused:true});}
  }catch{/* Focus restoration must not change a completed credential result. */}
  job.resolve(result);
  if(!result.credential&&job.ceremony)void send(job.selected,{action:'cancel',id:job.ceremony,userInitiated:job.userCancelled===true}).catch(()=>{});
 }
 chrome.windows.onRemoved.addListener(id=>{for(const job of jobs.values())if(job.windowId===id)void end(job,{error:{name:'NotAllowedError',message:'Passkey request cancelled.'}});});
 chrome.tabs.onRemoved.addListener(id=>{for(const job of jobs.values())if(job.tabId===id||job.selected?.selectedTab.id===id)void end(job,{error:{name:'NotAllowedError',message:'A required tab closed.'}});});
 chrome.tabs.onUpdated.addListener((id,change)=>{if(change.status==='loading')for(const job of jobs.values())if(job.tabId===id||job.selected?.selectedTab.id===id)void end(job,{error:{name:'NotAllowedError',message:'A required tab navigated.'}});});
 chrome.runtime.onMessage.addListener((m,sender,reply)=>{
  if(!m?.type?.startsWith('PASSLI_PASSKEY_'))return false;
  (async()=>{
   if(m.type==='PASSLI_PASSKEY_MANAGE_V1'){
    if(!isManager(sender))throw error('Open Passkeys in the extension.','SecurityError');
    if(m.action==='diagnostics'){await diagnosticQueue;const rows=chrome.storage.session?(await chrome.storage.session.get(diagnosticKey))[diagnosticKey]||[]:diagnosticRows;return {entries:rows.filter(r=>Date.parse(r.at)>now()-3600000).slice(-150)};}
    if(m.action==='settings'){if(typeof m.enabled==='boolean')await chrome.storage.local.set({passliPasskeysEnabled:m.enabled});return {enabled:(await chrome.storage.local.get('passliPasskeysEnabled')).passliPasskeysEnabled!==false};}
    if(!['list','rename','delete','history'].includes(m.action))throw error('Unknown management action.');
    const selected=await selectPairedTab({});return send(selected,{action:m.action,credentialId:m.credentialId,name:m.name});
   }
   if(m.type==='PASSLI_PASSKEY_UI_V1'){
    if(!isUI(sender)||sender.url!==uiURL(m.id))throw error('Invalid passkey approval window.','SecurityError');
    const job=jobs.get(m.id);if(!job)throw error('This passkey request is no longer available.');
    await current(job);
    if(m.action==='read')return {request:job.preview};
    if(m.action==='retry'){
     if(!job.preview?.unavailable||job.finishing||job.retrying)throw error('Only an unavailable connection can be retried.');
     trace('retry-started',job);job.retrying=true;try{await begin(job);return {request:job.preview};}catch(e){trace('retry-rejected',job,{errorName:errorName(e)});job.preview.error=e.message;throw e;}finally{job.retrying=false;}
    }
    if(m.action==='fallback'&&job.finishing)throw error('This request is already completing. Cancel or wait for its result.');
    if(m.action==='cancel'||m.action==='fallback'){job.userCancelled=m.action==='cancel';trace(m.action==='cancel'?'user-cancelled':'user-native-fallback',job);await end(job,m.action==='fallback'?{fallback:true}:{error:{name:'NotAllowedError',message:'Passkey request cancelled.'}});return {done:true};}
    if(m.action!=='finish'||job.finishing||!job.ceremony)throw error('This request is unavailable or already completing.');
    if(job.preview.requiresPassliLoginConfirmation&&m.confirmPassliLoginDependency!==true)throw error('Confirm that this passkey requires an existing Passli sign-in before saving.');
    job.finishing=true;trace('finish-started',job);
    try{
     // Existing factor prompts run in the paired Passli tab, whose HTTPS origin
     // can invoke registered security keys; extension origins cannot claim its RP.
     if(job.preview.verificationRequired){trace('verification-required',job);await chrome.tabs.update(job.selected.selectedTab.id,{active:true});job.focusedPassli=true;if(Number.isInteger(job.selected.selectedTab.windowId))await chrome.windows.update(job.selected.selectedTab.windowId,{focused:true});}
     const result=await send(job.selected,{action:'finish',id:job.ceremony,credentialId:m.credentialId});
     await current(job);await end(job,{credential:result.credential});return {done:true};
    }catch(e){trace('finish-rejected',job,{errorName:errorName(e)});job.finishing=false;await end(job,{error:{name:e.name,message:e.message}});throw e;}
   }
   const caller=binding(sender);
   if(m.type==='PASSLI_PASSKEY_TRACE_V1'){
    if(!['adapter-ready','bridge-ready','request-intercepted','native-bypass','request-forwarded','bridge-disconnected'].includes(m.stage))return {};
    const operation=['create','get'].includes(m.operation)?m.operation:undefined;
    const reason=['conditional-mediation','passli-origin'].includes(m.reason)?m.reason:undefined;
    trace('page-'+m.stage,{...caller,operation},{source:'page',...(reason?{reason}:{})});return {};
   }
   if(m.type==='PASSLI_PASSKEY_CANCEL_V1'){for(const job of jobs.values())if(job.pageId===m.id&&job.tabId===caller.tabId&&job.documentId===caller.documentId)await end(job,{error:{name:'AbortError',message:'Passkey request aborted.'}});return {};}
   if(m.type!=='PASSLI_PASSKEY_REQUEST_V1')throw error('Unknown passkey message.');
   trace('request-received',{...caller,operation:m.operation},summary(m.publicKey));
   if((await chrome.storage.local.get('passliPasskeysEnabled')).passliPasskeysEnabled===false){trace('disabled-native-fallback',caller);return {fallback:true};}
   if(jobs.size>=3)throw error('Finish another passkey request first.');
   if(typeof m.id!=='string'||m.id.length>128||!['create','get'].includes(m.operation)||JSON.stringify(m.publicKey).length>32000)throw error('Invalid passkey request.','DataError');
   const id=crypto.randomUUID();
   return await new Promise(resolve=>{
    const job={...caller,id,pageId:m.id,resolve,operation:m.operation,publicKey:m.publicKey,expires:now()+120000};jobs.set(id,job);
    job.timer=setTimeout(()=>void end(job,{error:{name:'NotAllowedError',message:'Passkey request expired.'}}),120000);
    (async()=>{
     try{await begin(job);}catch(e){
      trace('begin-rejected',job,{errorName:errorName(e)});
      if(['NotSupportedError','SecurityError','DataError','InvalidStateError'].includes(e.name))throw e;
      await current(job);job.preview={operation:m.operation,origin:job.origin,credentials:[],unavailable:true,error:e.message};
     }
     if(jobs.get(id)!==job)return;
     await current(job);const window=await chrome.windows.create({url:uiURL(id),type:'popup',width:470,height:560,focused:true});job.windowId=window.id;trace('dialog-opened',job);
    })().catch(e=>void end(job,e.name==='NotSupportedError'?{fallback:true}:{error:{name:e.name,message:e.message}}));
   });
  })().then(reply,e=>{trace('request-rejected',{}, {errorName:errorName(e)});reply({error:{name:e.name||'NotAllowedError',message:e.message||'Passkey request failed.'}});});
  return true;
 });
 return {pending:()=>jobs.size};
}};
