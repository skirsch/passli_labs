(() => {
 const button=document.getElementById('profileButton'),menu=document.getElementById('profileList'),status=document.getElementById('profileStatus');
 let identity='',account,run=0,busy=false;
 const close=()=>{menu.classList.add('hidden');button.setAttribute('aria-expanded','false');};
 async function call(action,roleId){
  const result=await chrome.runtime.sendMessage({type:'PASSLI_EXTENSION_PROFILES',action,...account,...(roleId!==undefined?{roleId}:{})});
  if(result?.error)throw Error(result.error.message);return result;
 }
 function render(data){
  button.textContent='('+(data.currentProfileArchived?'Choose a profile':data.currentProfileName)+')';
  if(data.profiles.length>1)button.textContent+=' ▾';
  button.disabled=false;menu.replaceChildren();
  for(const profile of data.profiles.filter(profile=>profile.id!==data.currentProfileId)){
   const item=document.createElement('button');item.type='button';item.className='signerMenuOption';item.textContent=profile.name;
   item.setAttribute('role','menuitemradio');item.setAttribute('aria-checked',String(profile.id===data.currentProfileId));
   item.disabled=profile.id===data.currentProfileId;
   item.onclick=async()=>{if(busy)return;const token=run;busy=true;button.disabled=true;status.textContent='';close();
    try{const next=await call('select',profile.id);if(token===run)render(next);}catch(e){if(token===run)status.textContent=e.message;}finally{if(token===run){busy=false;button.disabled=false;}}
   };menu.append(item);
  }
  addManagement();
 }
 function addManagement(){
  const manage=document.createElement('button');manage.type='button';manage.className='signerMenuOption';manage.textContent='Manage profiles';manage.setAttribute('role','menuitem');
  manage.onclick=async()=>{close();try{await call('manage');}catch(e){status.textContent=e.message;}};menu.append(manage);
 }
 globalThis.PassliPopupProfiles={async load(next){
  const key=JSON.stringify(next);if(key===identity)return;identity=key;account=next;const token=++run;busy=false;close();menu.replaceChildren();status.textContent='';button.textContent='Loading profiles…';button.disabled=true;
  if(!next.accountId||!next.deviceId){button.textContent='Profiles unavailable';return;}
  try{const data=await call('list');if(token===run)render(data);}catch(e){if(token===run){button.textContent='Profiles unavailable';button.disabled=false;addManagement();status.textContent=e.message;}}
 }};
 button.onclick=()=>{if(button.disabled||busy)return;const open=menu.classList.contains('hidden');menu.classList.toggle('hidden',!open);button.setAttribute('aria-expanded',String(open));};
 document.addEventListener('click',event=>{if(!event.target.closest('.profileMenu'))close();});
 document.addEventListener('keydown',event=>{if(event.key==='Escape'){close();button.focus();}});
 document.getElementById('managePasskeys').onclick=()=>chrome.tabs.create({url:chrome.runtime.getURL('src/passkeys/manage.html')});
})();
