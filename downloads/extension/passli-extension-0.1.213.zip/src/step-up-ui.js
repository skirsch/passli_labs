const id = new URLSearchParams(location.search).get('id');
const status = document.querySelector('#status'), cancel = document.querySelector('#cancel'), phone = document.querySelector('#phone'), retry = document.querySelector('#retry');
const port = chrome.runtime.connect({ name: 'extension-step-up' });
// Keep this active popup's service-worker conversation alive. No network call.
const heartbeat = window.setInterval(() => { try { port.postMessage({ action: 'ping', id }); } catch {} }, 15000);
port.onMessage.addListener(job => {
  if (job.id !== id) return;
  document.querySelector('#origin').textContent = job.origin || '';
  document.querySelector('#details').textContent = job.summary || '';
  const waiting = job.method === 'mobile-face-id' ? 'Approve on your phone using Face ID.' : job.method === 'mobile-face-id-security-key' ? 'Approve on your phone using Face ID and your PIN.' : job.method === 'mobile-face-id-pin-security-key' ? 'Approve on your phone using Face ID, your PIN and the required final factor.' : 'Approve this request on your phone.';
  status.textContent = ({ starting: 'Sending approval to your phone…', 'choose-phone': 'This request needs additional verification. Use your phone to continue.', waiting, completing: 'Phone approved. Completing your request…', success: 'Approved. Returning to the requesting site…', cancelled: 'Request cancelled.', expired: job.error, failed: job.error || 'The request failed.' })[job.state];
  status.dataset.error = String(['failed', 'expired'].includes(job.state));
  retry.hidden = !job.retryable;
  retry.disabled = false;
  phone.hidden = job.state !== 'choose-phone';
  phone.disabled = false;
  cancel.textContent = ['failed', 'cancelled', 'expired'].includes(job.state) ? 'Close' : 'Cancel';
  cancel.disabled = ['completing', 'success'].includes(job.state);
});
phone.addEventListener('click', () => { phone.disabled = true; port.postMessage({ action: 'phone', id }); });
retry.addEventListener('click', () => { retry.disabled = true; port.postMessage({ action: 'retry', id }); });
cancel.addEventListener('click', () => { try { port.postMessage({ action: 'cancel', id }); } catch {} window.close(); });
port.onDisconnect.addListener(() => { window.clearInterval(heartbeat); status.textContent = 'The extension disconnected. Check the request before retrying.'; status.dataset.error = 'true'; phone.hidden = true; retry.hidden = true; cancel.disabled = false; cancel.textContent = 'Close'; });
window.addEventListener('beforeunload', () => window.clearInterval(heartbeat));
port.postMessage({ action: 'open', id });
