const title = document.querySelector("#title");
const origin = document.querySelector("#origin");
const network = document.querySelector("#network");
const requestType = document.querySelector("#requestType");
const requestSubtype = document.querySelector("#requestSubtype");
const riskSection = document.querySelector("#riskSection");
const riskLabel = document.querySelector("#riskLabel");
const riskPercent = document.querySelector("#riskPercent");
const riskFill = document.querySelector("#riskFill");
const riskThumb = document.querySelector("#riskThumb");
const riskSummary = document.querySelector("#riskSummary");
const decodedSection = document.querySelector("#decodedSection");
const decodedFields = document.querySelector("#decodedFields");
const accountLabel = document.querySelector("#accountLabel");
const account = document.querySelector("#account");
const walletListSection = document.querySelector("#walletListSection");
const walletList = document.querySelector("#walletList");
const method = document.querySelector("#method");
const summarySection = document.querySelector("#summarySection");
const summary = document.querySelector("#summary");
const toggleDetailsButton = document.querySelector("#toggleDetails");
const viewDetailsButton = document.querySelector("#viewDetails");
const payload = document.querySelector("#payload");
const approveButton = document.querySelector("#approve");
const rejectButton = document.querySelector("#reject");
const statusText = document.querySelector("#status");
const warning = document.querySelector("#warning");
const actions = document.querySelector(".actions");
const extensionVersion = document.querySelector("#extensionVersion");

const id = new URLSearchParams(window.location.search).get("id");
let currentRequest = null;
let approvalStatusPort = null;
let bridgeFinalReceived = false;
let walletConnectStatusPort = null;
let walletConnectStatusHeartbeat = null;

extensionVersion.textContent = chrome.runtime.getManifest().version || "unknown";

function format(value) {
  if (typeof value === "string") return value;
  return JSON.stringify(value, null, 2);
}

function setStatus(message, variant = "neutral") {
  statusText.className = `status status--${variant}`;
  statusText.textContent = "";
  if (variant === "error") {
    const label = document.createElement("strong");
    label.className = "statusLabel";
    label.textContent = "Error:";
    const text = document.createElement("span");
    text.className = "statusMessage";
    text.textContent = ` ${message}`;
    statusText.append(label, text);
    return;
  }
  statusText.textContent = message;
}

function renderDecodedFields(fields) {
  decodedFields.innerHTML = "";
  if (!Array.isArray(fields) || !fields.length) {
    decodedSection.style.display = "none";
    return;
  }

  decodedSection.style.display = "block";
  for (const field of fields) {
    const term = document.createElement("dt");
    term.textContent = field.label || "Field";
    const description = document.createElement("dd");
    description.textContent = field.value === undefined || field.value === null
      ? ""
      : String(field.value);
    decodedFields.append(term, description);
  }
}

function renderRisk(risk) {
  const score = Math.max(0, Math.min(100, Number(risk && risk.level !== undefined ? risk.level : 40)));
  const tone = risk && risk.tone ? String(risk.tone) : "medium";
  riskSection.className = `riskSection riskTone${tone.charAt(0).toUpperCase()}${tone.slice(1)}`;
  riskLabel.textContent = risk && risk.label ? risk.label : "Review";
  riskPercent.textContent = `${Math.round(score)}%`;
  riskFill.style.width = `${score}%`;
  riskThumb.style.left = `${score}%`;
  riskSummary.textContent = risk && risk.summary
    ? risk.summary
    : "Review the request details before approving.";
}

function addressLabelForMethod(method) {
  return method === "eth_requestAccounts" || method === "wallet_requestPermissions"
    ? "Default address"
    : "Requested signer";
}

function isConnectMethod(method) {
  return method === "eth_requestAccounts" || method === "wallet_requestPermissions";
}

function shortAddress(address) {
  const value = String(address || "");
  return value.length > 14 ? `${value.slice(0, 8)}...${value.slice(-6)}` : value;
}

function selectedWalletAddresses() {
  return Array.from(walletList.querySelectorAll("input[type='checkbox']:checked"))
    .map((input) => input.value)
    .filter(Boolean);
}

function updateApproveState() {
  if (!walletListSection.hidden) {
    approveButton.disabled = selectedWalletAddresses().length === 0;
  }
}

function renderWalletChoices(request) {
  walletList.innerHTML = "";
  const wallets = Array.isArray(request.availableWallets) ? request.availableWallets : [];
  if (!isConnectMethod(request.method) || !wallets.length) {
    walletListSection.hidden = true;
    return;
  }

  walletListSection.hidden = false;
  for (const wallet of wallets) {
    const label = document.createElement("label");
    label.className = "walletChoice";

    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.value = wallet.selectionKey || wallet.address || "";
    checkbox.checked = wallet.selected !== false;
    checkbox.addEventListener("change", updateApproveState);

    const details = document.createElement("span");
    const title = document.createElement("span");
    title.className = "walletChoiceTitle";
    title.textContent = wallet.label || wallet.type || "Wallet";
    const meta = document.createElement("span");
    meta.className = "walletChoiceMeta";
    meta.textContent = `${shortAddress(wallet.address)} ${wallet.signerType ? `- ${wallet.signerType}` : ""}`;
    details.append(title, meta);

    label.append(checkbox, details);
    walletList.append(label);
  }
  updateApproveState();
}

async function send(action, extra = {}) {
  return chrome.runtime.sendMessage({
    type: "HYPERLIQUID_DEMO_APPROVAL",
    action,
    id,
    ...extra
  });
}

async function load() {
  const response = await send("get");
  if (!response || response.error) {
    setStatus(response && response.error ? response.error.message : "Request not found.", "error");
    approveButton.disabled = true;
    rejectButton.disabled = true;
    return;
  }

  const request = response.result;
  currentRequest = request;
  const analysis = request.analysis || {};
  title.textContent = request.title;
  origin.textContent = request.origin;
  network.textContent = analysis.network || "Not chain-specific";
  requestType.textContent = analysis.requestType || "Request";
  requestSubtype.textContent = analysis.subtype || request.method || "";
  renderRisk(analysis.risk);
  renderDecodedFields(analysis.fields);
  accountLabel.textContent = addressLabelForMethod(request.method);
  account.textContent = request.address;
  renderWalletChoices(request);
  method.textContent = request.method;
  if (request.summary) {
    summary.textContent = request.summary;
    summarySection.style.display = "block";
  } else {
    summarySection.style.display = "none";
  }
  payload.textContent = format(request.params);
  payload.style.display = "none";

  if (request.noticeOnly && request.mode === "vault-locked") {
    viewDetailsButton.style.display = "none";
    approveButton.textContent = "Open passli.app";
    rejectButton.textContent = "Dismiss";
    warning.textContent = "No signature was produced. Unlock Passli, then retry the action in the dApp.";
    setStatus("Vault locked. Passli needs the vault unlocked before it can sign this request.", "error");
    return;
  }

  if (request.noticeOnly) {
    viewDetailsButton.style.display = "none";
    approveButton.textContent = "Re-enable Account";
    rejectButton.textContent = "Dismiss";
    warning.textContent = "This is not an approval request. Re-enable the account from the Passli extension with a provisioned recovery/admin device.";
    setStatus("Account disabled for new orders and outbound fund movement. Cancel and risk-reducing actions remain available.", "error");
    return;
  }

  if (request.mode === "walletconnect-status") {
    approveButton.style.display = "none";
    viewDetailsButton.style.display = "none";
    rejectButton.textContent = "Cancel";
    actions.classList.add("statusOnly");
    warning.textContent = "Review and approve this request in your WalletConnect wallet.";
    setStatus("Waiting for WalletConnect signature...", "neutral");
    keepWalletConnectStatusPortOpen();
  }
}

toggleDetailsButton.addEventListener("click", () => {
  const showing = payload.style.display !== "none";
  payload.style.display = showing ? "none" : "block";
  toggleDetailsButton.textContent = showing
    ? "Show actual request details"
    : "Hide actual request details";
});

viewDetailsButton.addEventListener("click", async () => {
  const response = await send("details");
  if (response && response.error) {
    setStatus(response.error.message, "error");
    return;
  }
  setStatus("Opened full details on passli.app.", "success");
});

function keepWalletConnectStatusPortOpen() {
  if (walletConnectStatusPort) return;
  walletConnectStatusPort = chrome.runtime.connect({ name: "walletconnect-signing" });
  walletConnectStatusPort.onMessage.addListener((message) => {
    if (message && message.action === "signed") {
      setStatus("Signature received.", "success");
    }
  });
  walletConnectStatusPort.postMessage({ action: "open", id });
  walletConnectStatusHeartbeat = window.setInterval(() => {
    try {
      walletConnectStatusPort.postMessage({ action: "ping", id, time: Date.now() });
    } catch {
      stopWalletConnectStatusPort();
    }
  }, 15000);
}

function stopWalletConnectStatusPort() {
  stopApprovalStatusPort();
  if (walletConnectStatusHeartbeat !== null) {
    window.clearInterval(walletConnectStatusHeartbeat);
    walletConnectStatusHeartbeat = null;
  }
  if (walletConnectStatusPort) {
    try {
      walletConnectStatusPort.disconnect();
    } catch {
      // The port may already be gone.
    }
    walletConnectStatusPort = null;
  }
}

function keepApprovalStatusPortOpen() {
  if (approvalStatusPort) return;
  approvalStatusPort = chrome.runtime.connect({ name: "approval-status" });
  approvalStatusPort.onMessage.addListener((message) => {
    if (!message || message.action !== "bridgeResult") return;
    renderBridgeResult(message.result);
  });
  approvalStatusPort.postMessage({ action: "open", id });
}

function stopApprovalStatusPort() {
  if (!approvalStatusPort) return;
  try {
    approvalStatusPort.disconnect();
  } catch {
    // The port may already be gone.
  }
  approvalStatusPort = null;
}

function renderBridgeResult(result) {
  bridgeFinalReceived = true;
  stopApprovalStatusPort();

  if (result && result.status === "approved") {
    setStatus("Completed.", "success");
    window.setTimeout(() => {
      window.close();
    }, 500);
    return;
  }

  setStatus(result && result.error && result.error.message
    ? result.error.message
    : "Passli request failed.", "error");
  warning.textContent = "The request was not completed. Review the error before closing this window.";
  rejectButton.textContent = "Close";
  rejectButton.disabled = false;
  approveButton.disabled = true;
}

approveButton.addEventListener("click", async () => {
  if (currentRequest && currentRequest.mode === "reenable-complete") {
    window.close();
    return;
  }
  const action = currentRequest && currentRequest.mode === "vault-locked"
    ? "openPassli"
    : currentRequest && currentRequest.noticeOnly
      ? "reenable"
      : "approve";
  approveButton.disabled = true;
  rejectButton.disabled = false;
  rejectButton.textContent = action === "reenable" ? "Dismiss" : "Cancel";
  if (action === "reenable") {
    setStatus("Asking recovery wallet to sign re-enable request...", "neutral");
  } else if (action === "openPassli") {
    setStatus("Opening passli.app...", "neutral");
  }
  const response = await send(action, {
    approval: action === "reenable" ? currentRequest : undefined,
    selectedWalletAddresses: selectedWalletAddresses()
  });
  if (response && response.error) {
    setStatus(response.error.message, "error");
    approveButton.disabled = false;
    rejectButton.disabled = false;
    return;
  }
  if (action === "openPassli") {
    setStatus("Opened passli.app. Unlock the vault there, then retry in the dApp.", "success");
    window.setTimeout(() => {
      window.close();
    }, 500);
    return;
  }
  if (action === "reenable") {
    currentRequest = { mode: "reenable-complete" };
    approveButton.textContent = "OK";
    approveButton.disabled = false;
    rejectButton.style.display = "none";
    actions.classList.add("statusOnly");
    warning.classList.add("successNotice");
    warning.textContent = "Account successfully re-enabled.";
    setStatus("Account re-enabled. The cloud signer and extension both accepted the recovery authorization.", "success");
    return;
  }
  if (response && response.result && response.result.pendingBridge) {
    if (currentRequest && currentRequest.signerType === "externalAuthority") {
      const walletLabel = currentRequest.authorityWalletLabel || "your wallet";
      setStatus(`Approved. Waiting for ${walletLabel} signature...`, "neutral");
      warning.textContent = `Approve this request in ${walletLabel}. You can cancel this wait if the wallet prompt does not appear.`;
    } else {
      setStatus("Approved. Waiting for passli.app to finish...", "neutral");
      warning.textContent = "You can cancel this wait if passli.app is restarting or does not respond.";
    }
    keepApprovalStatusPortOpen();
    return;
  }
  setStatus("Approved.", "success");
  window.setTimeout(() => {
    window.close();
  }, 500);
});

rejectButton.addEventListener("click", async () => {
  approveButton.disabled = true;
  rejectButton.disabled = true;
  stopWalletConnectStatusPort();
  if (bridgeFinalReceived) {
    window.close();
    return;
  }
  await send("reject");
  window.close();
});

window.addEventListener("beforeunload", stopWalletConnectStatusPort);

load();
