const pairingID=new URL(location.href).searchParams.get('pairing');
async function request(action){const response=await chrome.runtime.sendMessage({type:'PASSLI_CUSTODY_CONFIRM',pairingID,action});if(response.error)throw Error(response.error);return response.result;}
async function refresh(){try{const result=await request('status');document.querySelector('#destination').textContent=result.destination;document.querySelector('#account').textContent=result.account||'Waiting for your phone…';document.querySelector('#confirm').disabled=!result.account;}catch(e){document.querySelector('#error').textContent=e.message;}}
document.querySelector('#refresh').onclick=refresh;
document.querySelector('#confirm').onclick=async()=>{try{await request('confirm');document.body.replaceChildren(Object.assign(document.createElement('p'),{textContent:'Passkeys restored. You may close this window.'}));}catch(e){document.querySelector('#error').textContent=e.message;}};
chrome.runtime.onMessage.addListener(message=>{if(message?.type==='PASSLI_CUSTODY_READY'&&message.pairingID===pairingID)void refresh();});
void refresh();
