(() => {
 if(window.top!==window)return;
 const mark=()=>document.documentElement?.setAttribute('data-passli-passkey-custody','1');mark();document.addEventListener('DOMContentLoaded',mark,{once:true});
 window.addEventListener('message',event=>{
  if(event.source!==window||event.origin!==location.origin||event.data?.type!=='PASSLI_PASSKEY_CUSTODY_REQUEST_V1')return;
  const {id,action,payload}=event.data;if(typeof id!=='string'||!['prepare','receive','available'].includes(action))return;
  chrome.runtime.sendMessage({type:'PASSLI_THRESHOLD_CUSTODY_V1',action,payload},response=>{
   const result=chrome.runtime.lastError?{error:'The Passli extension disconnected.'}:response;
   window.postMessage({type:'PASSLI_PASSKEY_CUSTODY_RESPONSE_V1',id,...result},location.origin);
  });
 });
})();
