// Restore isolated bridges in existing pages after an extension reload.
// The MAIN-world WebAuthn adapter remains installed; never wrap its native fallback twice.
globalThis.PassliPasskeyReconnect={async install({chrome,log=async()=>{}}){
 if((await chrome.storage.local.get('passliPasskeysEnabled')).passliPasskeysEnabled!==true)return;
 const tabs=(await chrome.tabs.query({})).filter(tab=>{
  try{const url=new URL(tab.url);return Number.isInteger(tab.id)&&!tab.discarded&&url.protocol==='https:'&&url.hostname!=='passli.app'&&!url.hostname.endsWith('.passli.app');}catch{return false;}
 }).sort((a,b)=>Number(Boolean(b.active))-Number(Boolean(a.active)));
 async function connect(tab){
  try{
   const ready=await chrome.tabs.sendMessage(tab.id,{type:'PASSLI_PASSKEY_BRIDGE_PING_V1'},{frameId:0});
   if(ready?.version===2)return;
  }catch{/* Old or invalidated content scripts have no live receiver. */}
  try{
   await chrome.scripting.executeScript({target:{tabId:tab.id,frameIds:[0]},files:['src/passkeys/content.js']});
   const ready=await chrome.tabs.sendMessage(tab.id,{type:'PASSLI_PASSKEY_BRIDGE_PING_V1'},{frameId:0});
   if(ready?.version!==2)throw Error('Bridge did not reconnect.');
   await log({phase:'passkey:page-reconnected',origin:new URL(tab.url).origin,method:'webauthn'});
  }catch{await log({phase:'passkey:page-reconnect-failed',origin:new URL(tab.url).origin,method:'webauthn'}).catch(()=>{});}
 }
 // Limit work on browsers with many open tabs; discarded pages inject on their next load.
 for(let index=0;index<tabs.length;index+=4)await Promise.all(tabs.slice(index,index+4).map(connect));
}};
