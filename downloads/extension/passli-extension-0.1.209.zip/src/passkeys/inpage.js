(() => {
 if (!globalThis.isSecureContext || window.top !== window || !navigator.credentials || !globalThis.PublicKeyCredential) return;
 if(globalThis.__passliPasskeyAdapterV1)return;
 globalThis.__passliPasskeyAdapterV1=true;
 const native = { create: navigator.credentials.create.bind(navigator.credentials), get: navigator.credentials.get.bind(navigator.credentials) };
 const waiting = new Map();
 const trace=(stage,operation,reason)=>{console.debug('[Passli passkeys]',{stage,operation,reason});window.postMessage({type:'PASSLI_PASSKEY_TRACE_V1',stage,operation,reason},location.origin);};
 trace('adapter-ready');
 const encode = value => {
  const bytes = new Uint8Array(value instanceof ArrayBuffer ? value : value.buffer, value.byteOffset || 0, value.byteLength);
  let s = ''; for (const b of bytes) s += String.fromCharCode(b);
  return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
 };
 const decode = value => Uint8Array.from(atob(value.replace(/-/g, '+').replace(/_/g, '/') + '='.repeat((4-value.length%4)%4)), c => c.charCodeAt(0)).buffer;
 const pack = value => value instanceof ArrayBuffer || ArrayBuffer.isView(value) ? encode(value) : Array.isArray(value) ? value.map(pack) : value && typeof value === 'object' ? Object.fromEntries(Object.entries(value).map(([k,v])=>[k,pack(v)])) : value;
 function credential(wire) {
  const creating = !!wire.response.attestationObject;
  const response = Object.create((creating ? AuthenticatorAttestationResponse : AuthenticatorAssertionResponse).prototype);
  const fields = creating ? ['clientDataJSON','attestationObject'] : ['clientDataJSON','authenticatorData','signature','userHandle'];
  for (const key of fields) Object.defineProperty(response,key,{enumerable:true,value:wire.response[key] == null ? null : decode(wire.response[key])});
  if (creating) Object.defineProperties(response,{
   getTransports:{value:()=>[],writable:true,configurable:true}, getPublicKey:{value:()=>decode(wire.response.publicKey),writable:true,configurable:true},
   getPublicKeyAlgorithm:{value:()=>wire.response.publicKeyAlgorithm,writable:true,configurable:true}, getAuthenticatorData:{value:()=>decode(wire.response.authenticatorData),writable:true,configurable:true}
  });
  const result=Object.create(PublicKeyCredential.prototype);
  for(const [key,value] of Object.entries({id:wire.id,rawId:decode(wire.rawId),type:'public-key',authenticatorAttachment:null,response}))Object.defineProperty(result,key,{value,enumerable:true});
  Object.defineProperties(result,{getClientExtensionResults:{value:()=>structuredClone(wire.clientExtensionResults||{}),writable:true,configurable:true},toJSON:{value:()=>structuredClone({id:wire.id,rawId:wire.rawId,type:'public-key',authenticatorAttachment:null,response:wire.response,clientExtensionResults:wire.clientExtensionResults||{}}),writable:true,configurable:true}});
  return result;
 }
 window.addEventListener('message',event=>{
  if(event.source===window&&event.origin===location.origin&&event.data?.type==='PASSLI_PASSKEY_BRIDGE_RESET_V1'){
   for(const [id,respond]of [...waiting])respond({id,error:{name:'AbortError',message:'Passli reconnected. Start a new passkey request.'}});
   return;
  }
  if(event.source!==window||event.origin!==location.origin||event.data?.type!=='PASSLI_PASSKEY_RESPONSE_V1')return;
  waiting.get(event.data.id)?.(event.data);
 });
 for(const operation of ['create','get'])navigator.credentials[operation]=function(options){
  if(!options?.publicKey)return native[operation](options);
  if(options.mediation==='conditional' || location.hostname==='passli.app' || location.hostname.endsWith('.passli.app')){trace('native-bypass',operation,options.mediation==='conditional'?'conditional-mediation':'passli-origin');return native[operation](options);}
  trace('request-intercepted',operation);
  if(options.signal?.aborted)return Promise.reject(options.signal.reason||new DOMException('Request aborted.','AbortError'));
  const id=crypto.randomUUID();
  return new Promise((resolve,reject)=>{
   let done=false;
   const cleanup=()=>{waiting.delete(id);clearTimeout(timer);options.signal?.removeEventListener('abort',abort);window.removeEventListener('pagehide',abort);};
   const abort=()=>{if(done)return;done=true;cleanup();window.postMessage({type:'PASSLI_PASSKEY_CANCEL_V1',id},location.origin);reject(options.signal?.reason||new DOMException('Request aborted.','AbortError'));};
   const timer=setTimeout(()=>{if(done)return;done=true;cleanup();window.postMessage({type:'PASSLI_PASSKEY_CANCEL_V1',id},location.origin);reject(new DOMException('Passkey request expired.','NotAllowedError'));},Math.min(120000,Number.isFinite(options.publicKey.timeout)?Math.max(1,options.publicKey.timeout):120000));
   waiting.set(id,message=>{
    if(done)return;done=true;cleanup();
    if(message.fallback){Promise.resolve().then(()=>native[operation](options)).then(resolve,reject);return;}
    if(message.error){reject(new DOMException(message.error.message,message.error.name||'NotAllowedError'));return;}
    try{resolve(credential(message.credential));}catch{reject(new DOMException('Invalid provider response.','UnknownError'));}
   });
   options.signal?.addEventListener('abort',abort,{once:true});window.addEventListener('pagehide',abort,{once:true});
   window.postMessage({type:'PASSLI_PASSKEY_REQUEST_V1',id,operation,publicKey:pack(options.publicKey)},location.origin);
  });
 };
})();
